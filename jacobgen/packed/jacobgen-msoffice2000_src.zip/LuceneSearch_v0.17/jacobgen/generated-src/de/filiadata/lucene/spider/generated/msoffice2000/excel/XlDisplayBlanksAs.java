/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDisplayBlanksAs {

	public static final int xlInterpolated = 3;
	public static final int xlNotPlotted = 1;
	public static final int xlZero = 2;
}
