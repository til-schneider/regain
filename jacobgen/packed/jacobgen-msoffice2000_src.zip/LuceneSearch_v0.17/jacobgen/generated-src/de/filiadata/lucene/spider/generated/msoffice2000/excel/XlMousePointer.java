/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlMousePointer {

	public static final int xlIBeam = 3;
	public static final int xlDefault = -4143;
	public static final int xlNorthwestArrow = 1;
	public static final int xlWait = 2;
}
