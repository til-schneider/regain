/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCommandUnderlines {

	public static final int xlCommandUnderlinesAutomatic = -4105;
	public static final int xlCommandUnderlinesOff = -4146;
	public static final int xlCommandUnderlinesOn = 1;
}
