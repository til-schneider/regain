/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _QueryTable extends Dispatch {

	public static final String componentName = "Excel._QueryTable";

	public _QueryTable() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _QueryTable(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _QueryTable(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getFieldNames() {
		return Dispatch.get(this, "FieldNames").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setFieldNames(boolean lastParam) {
		Dispatch.call(this, "FieldNames", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRowNumbers() {
		return Dispatch.get(this, "RowNumbers").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRowNumbers(boolean lastParam) {
		Dispatch.call(this, "RowNumbers", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getFillAdjacentFormulas() {
		return Dispatch.get(this, "FillAdjacentFormulas").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setFillAdjacentFormulas(boolean lastParam) {
		Dispatch.call(this, "FillAdjacentFormulas", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasAutoFormat() {
		return Dispatch.get(this, "HasAutoFormat").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasAutoFormat(boolean lastParam) {
		Dispatch.call(this, "HasAutoFormat", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRefreshOnFileOpen() {
		return Dispatch.get(this, "RefreshOnFileOpen").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRefreshOnFileOpen(boolean lastParam) {
		Dispatch.call(this, "RefreshOnFileOpen", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRefreshing() {
		return Dispatch.get(this, "Refreshing").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getFetchedRowOverflow() {
		return Dispatch.get(this, "FetchedRowOverflow").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getBackgroundQuery() {
		return Dispatch.get(this, "BackgroundQuery").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setBackgroundQuery(boolean lastParam) {
		Dispatch.call(this, "BackgroundQuery", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void cancelRefresh() {
		Dispatch.call(this, "CancelRefresh");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRefreshStyle() {
		return Dispatch.get(this, "RefreshStyle").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setRefreshStyle(int lastParam) {
		Dispatch.call(this, "RefreshStyle", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableRefresh() {
		return Dispatch.get(this, "EnableRefresh").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableRefresh(boolean lastParam) {
		Dispatch.call(this, "EnableRefresh", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSavePassword() {
		return Dispatch.get(this, "SavePassword").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSavePassword(boolean lastParam) {
		Dispatch.call(this, "SavePassword", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDestination() {
		return new Range(Dispatch.get(this, "Destination").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getConnection() {
		return Dispatch.get(this, "Connection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setConnection(Variant lastParam) {
		Dispatch.call(this, "Connection", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSql() {
		return Dispatch.get(this, "Sql");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setSql(Variant lastParam) {
		Dispatch.call(this, "Sql", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPostText() {
		return Dispatch.get(this, "PostText").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setPostText(String lastParam) {
		Dispatch.call(this, "PostText", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getResultRange() {
		return new Range(Dispatch.get(this, "ResultRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean refresh(Variant lastParam) {
		return Dispatch.call(this, "Refresh", lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean refresh() {
		return Dispatch.call(this, "Refresh").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Parameters
	 */
	public Parameters getParameters() {
		return new Parameters(Dispatch.get(this, "Parameters").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getRecordset() {
		return Dispatch.get(this, "Recordset");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void setRecordset(Object lastParam) {
		Dispatch.call(this, "Recordset", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSaveData() {
		return Dispatch.get(this, "SaveData").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSaveData(boolean lastParam) {
		Dispatch.call(this, "SaveData", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTablesOnlyFromHTML() {
		return Dispatch.get(this, "TablesOnlyFromHTML").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTablesOnlyFromHTML(boolean lastParam) {
		Dispatch.call(this, "TablesOnlyFromHTML", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableEditing() {
		return Dispatch.get(this, "EnableEditing").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableEditing(boolean lastParam) {
		Dispatch.call(this, "EnableEditing", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getTextFilePlatform() {
		return Dispatch.get(this, "TextFilePlatform").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setTextFilePlatform(int lastParam) {
		Dispatch.call(this, "TextFilePlatform", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getTextFileStartRow() {
		return Dispatch.get(this, "TextFileStartRow").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setTextFileStartRow(int lastParam) {
		Dispatch.call(this, "TextFileStartRow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getTextFileParseType() {
		return Dispatch.get(this, "TextFileParseType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setTextFileParseType(int lastParam) {
		Dispatch.call(this, "TextFileParseType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getTextFileTextQualifier() {
		return Dispatch.get(this, "TextFileTextQualifier").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setTextFileTextQualifier(int lastParam) {
		Dispatch.call(this, "TextFileTextQualifier", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFileConsecutiveDelimiter() {
		return Dispatch.get(this, "TextFileConsecutiveDelimiter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFileConsecutiveDelimiter(boolean lastParam) {
		Dispatch.call(this, "TextFileConsecutiveDelimiter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFileTabDelimiter() {
		return Dispatch.get(this, "TextFileTabDelimiter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFileTabDelimiter(boolean lastParam) {
		Dispatch.call(this, "TextFileTabDelimiter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFileSemicolonDelimiter() {
		return Dispatch.get(this, "TextFileSemicolonDelimiter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFileSemicolonDelimiter(boolean lastParam) {
		Dispatch.call(this, "TextFileSemicolonDelimiter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFileCommaDelimiter() {
		return Dispatch.get(this, "TextFileCommaDelimiter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFileCommaDelimiter(boolean lastParam) {
		Dispatch.call(this, "TextFileCommaDelimiter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFileSpaceDelimiter() {
		return Dispatch.get(this, "TextFileSpaceDelimiter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFileSpaceDelimiter(boolean lastParam) {
		Dispatch.call(this, "TextFileSpaceDelimiter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTextFileOtherDelimiter() {
		return Dispatch.get(this, "TextFileOtherDelimiter").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTextFileOtherDelimiter(String lastParam) {
		Dispatch.call(this, "TextFileOtherDelimiter", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getTextFileColumnDataTypes() {
		return Dispatch.get(this, "TextFileColumnDataTypes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setTextFileColumnDataTypes(Variant lastParam) {
		Dispatch.call(this, "TextFileColumnDataTypes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getTextFileFixedColumnWidths() {
		return Dispatch.get(this, "TextFileFixedColumnWidths");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setTextFileFixedColumnWidths(Variant lastParam) {
		Dispatch.call(this, "TextFileFixedColumnWidths", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPreserveColumnInfo() {
		return Dispatch.get(this, "PreserveColumnInfo").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPreserveColumnInfo(boolean lastParam) {
		Dispatch.call(this, "PreserveColumnInfo", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPreserveFormatting() {
		return Dispatch.get(this, "PreserveFormatting").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPreserveFormatting(boolean lastParam) {
		Dispatch.call(this, "PreserveFormatting", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAdjustColumnWidth() {
		return Dispatch.get(this, "AdjustColumnWidth").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAdjustColumnWidth(boolean lastParam) {
		Dispatch.call(this, "AdjustColumnWidth", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getCommandText() {
		return Dispatch.get(this, "CommandText");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setCommandText(Variant lastParam) {
		Dispatch.call(this, "CommandText", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCommandType() {
		return Dispatch.get(this, "CommandType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCommandType(int lastParam) {
		Dispatch.call(this, "CommandType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTextFilePromptOnRefresh() {
		return Dispatch.get(this, "TextFilePromptOnRefresh").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTextFilePromptOnRefresh(boolean lastParam) {
		Dispatch.call(this, "TextFilePromptOnRefresh", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getQueryType() {
		return Dispatch.get(this, "QueryType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMaintainConnection() {
		return Dispatch.get(this, "MaintainConnection").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setMaintainConnection(boolean lastParam) {
		Dispatch.call(this, "MaintainConnection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTextFileDecimalSeparator() {
		return Dispatch.get(this, "TextFileDecimalSeparator").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTextFileDecimalSeparator(String lastParam) {
		Dispatch.call(this, "TextFileDecimalSeparator", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTextFileThousandsSeparator() {
		return Dispatch.get(this, "TextFileThousandsSeparator").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTextFileThousandsSeparator(String lastParam) {
		Dispatch.call(this, "TextFileThousandsSeparator", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRefreshPeriod() {
		return Dispatch.get(this, "RefreshPeriod").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setRefreshPeriod(int lastParam) {
		Dispatch.call(this, "RefreshPeriod", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resetTimer() {
		Dispatch.call(this, "ResetTimer");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getWebSelectionType() {
		return Dispatch.get(this, "WebSelectionType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setWebSelectionType(int lastParam) {
		Dispatch.call(this, "WebSelectionType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getWebFormatting() {
		return Dispatch.get(this, "WebFormatting").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setWebFormatting(int lastParam) {
		Dispatch.call(this, "WebFormatting", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getWebTables() {
		return Dispatch.get(this, "WebTables").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setWebTables(String lastParam) {
		Dispatch.call(this, "WebTables", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWebPreFormattedTextToColumns() {
		return Dispatch.get(this, "WebPreFormattedTextToColumns").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setWebPreFormattedTextToColumns(boolean lastParam) {
		Dispatch.call(this, "WebPreFormattedTextToColumns", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWebSingleBlockTextImport() {
		return Dispatch.get(this, "WebSingleBlockTextImport").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setWebSingleBlockTextImport(boolean lastParam) {
		Dispatch.call(this, "WebSingleBlockTextImport", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWebDisableDateRecognition() {
		return Dispatch.get(this, "WebDisableDateRecognition").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setWebDisableDateRecognition(boolean lastParam) {
		Dispatch.call(this, "WebDisableDateRecognition", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWebConsecutiveDelimitersAsOne() {
		return Dispatch.get(this, "WebConsecutiveDelimitersAsOne").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setWebConsecutiveDelimitersAsOne(boolean lastParam) {
		Dispatch.call(this, "WebConsecutiveDelimitersAsOne", new Variant(lastParam));
	}

}
