/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpNumberedBulletStyle {

	public static final int ppBulletStyleMixed = -2;
	public static final int ppBulletAlphaLCPeriod = 0;
	public static final int ppBulletAlphaUCPeriod = 1;
	public static final int ppBulletArabicParenRight = 2;
	public static final int ppBulletArabicPeriod = 3;
	public static final int ppBulletRomanLCParenBoth = 4;
	public static final int ppBulletRomanLCParenRight = 5;
	public static final int ppBulletRomanLCPeriod = 6;
	public static final int ppBulletRomanUCPeriod = 7;
	public static final int ppBulletAlphaLCParenBoth = 8;
	public static final int ppBulletAlphaLCParenRight = 9;
	public static final int ppBulletAlphaUCParenBoth = 10;
	public static final int ppBulletAlphaUCParenRight = 11;
	public static final int ppBulletArabicParenBoth = 12;
	public static final int ppBulletArabicPlain = 13;
	public static final int ppBulletRomanUCParenBoth = 14;
	public static final int ppBulletRomanUCParenRight = 15;
	public static final int ppBulletSimpChinPlain = 16;
	public static final int ppBulletSimpChinPeriod = 17;
	public static final int ppBulletCircleNumDBPlain = 18;
	public static final int ppBulletCircleNumWDWhitePlain = 19;
	public static final int ppBulletCircleNumWDBlackPlain = 20;
	public static final int ppBulletTradChinPlain = 21;
	public static final int ppBulletTradChinPeriod = 22;
	public static final int ppBulletArabicAlphaDash = 23;
	public static final int ppBulletArabicAbjadDash = 24;
	public static final int ppBulletHebrewAlphaDash = 25;
	public static final int ppBulletKanjiKoreanPlain = 26;
	public static final int ppBulletKanjiKoreanPeriod = 27;
	public static final int ppBulletArabicDBPlain = 28;
	public static final int ppBulletArabicDBPeriod = 29;
}
