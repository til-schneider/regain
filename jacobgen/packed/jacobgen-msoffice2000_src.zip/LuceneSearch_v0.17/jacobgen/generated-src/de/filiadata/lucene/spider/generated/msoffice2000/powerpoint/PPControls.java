/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class PPControls extends Dispatch {

	public static final String componentName = "PowerPoint.PPControls";

	public PPControls() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PPControls(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PPControls(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant _Index(int lastParam) {
		return Dispatch.call(this, "_Index", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PPControl
	 */
	public PPControl item(Variant lastParam) {
		return new PPControl(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPPushButton
	 */
	public PPPushButton addPushButton(float left, float top, float width, float lastParam) {
		return new PPPushButton(Dispatch.call(this, "AddPushButton", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPToggleButton
	 */
	public PPToggleButton addToggleButton(float left, float top, float width, float lastParam) {
		return new PPToggleButton(Dispatch.call(this, "AddToggleButton", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPBitmapButton
	 */
	public PPBitmapButton addBitmapButton(float left, float top, float width, float lastParam) {
		return new PPBitmapButton(Dispatch.call(this, "AddBitmapButton", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPListBox
	 */
	public PPListBox addListBox(float left, float top, float width, float lastParam) {
		return new PPListBox(Dispatch.call(this, "AddListBox", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPCheckBox
	 */
	public PPCheckBox addCheckBox(float left, float top, float width, float lastParam) {
		return new PPCheckBox(Dispatch.call(this, "AddCheckBox", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPRadioCluster
	 */
	public PPRadioCluster addRadioCluster(float left, float top, float width, float lastParam) {
		return new PPRadioCluster(Dispatch.call(this, "AddRadioCluster", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPStaticText
	 */
	public PPStaticText addStaticText(float left, float top, float width, float lastParam) {
		return new PPStaticText(Dispatch.call(this, "AddStaticText", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PPEditText
	 */
	public PPEditText addEditText(float left, float top, float width, float height, Variant lastParam) {
		return new PPEditText(Dispatch.call(this, "AddEditText", new Variant(left), new Variant(top), new Variant(width), new Variant(height), lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @return the result is of type PPEditText
	 */
	public PPEditText addEditText(float left, float top, float width, float height) {
		return new PPEditText(Dispatch.call(this, "AddEditText", new Variant(left), new Variant(top), new Variant(width), new Variant(height)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPIcon
	 */
	public PPIcon addIcon(float left, float top, float width, float lastParam) {
		return new PPIcon(Dispatch.call(this, "AddIcon", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPBitmap
	 */
	public PPBitmap addBitmap(float left, float top, float width, float lastParam) {
		return new PPBitmap(Dispatch.call(this, "AddBitmap", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPSpinner
	 */
	public PPSpinner addSpinner(float left, float top, float width, float lastParam) {
		return new PPSpinner(Dispatch.call(this, "AddSpinner", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param style an input-parameter of type int
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPScrollBar
	 */
	public PPScrollBar addScrollBar(int style, float left, float top, float width, float lastParam) {
		return new PPScrollBar(Dispatch.call(this, "AddScrollBar", new Variant(style), new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPGroupBox
	 */
	public PPGroupBox addGroupBox(float left, float top, float width, float lastParam) {
		return new PPGroupBox(Dispatch.call(this, "AddGroupBox", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPDropDown
	 */
	public PPDropDown addDropDown(float left, float top, float width, float lastParam) {
		return new PPDropDown(Dispatch.call(this, "AddDropDown", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPDropDownEdit
	 */
	public PPDropDownEdit addDropDownEdit(float left, float top, float width, float lastParam) {
		return new PPDropDownEdit(Dispatch.call(this, "AddDropDownEdit", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPSlideMiniature
	 */
	public PPSlideMiniature addMiniature(float left, float top, float width, float lastParam) {
		return new PPSlideMiniature(Dispatch.call(this, "AddMiniature", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type PPFrame
	 */
	public PPFrame addFrame(float left, float top, float width, float lastParam) {
		return new PPFrame(Dispatch.call(this, "AddFrame", new Variant(left), new Variant(top), new Variant(width), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getVisible() {
		return Dispatch.get(this, "Visible").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setVisible(int lastParam) {
		Dispatch.call(this, "Visible", new Variant(lastParam));
	}

}
