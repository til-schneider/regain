/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpShapeFormat {

	public static final int ppShapeFormatGIF = 0;
	public static final int ppShapeFormatJPG = 1;
	public static final int ppShapeFormatPNG = 2;
	public static final int ppShapeFormatBMP = 3;
	public static final int ppShapeFormatWMF = 4;
}
