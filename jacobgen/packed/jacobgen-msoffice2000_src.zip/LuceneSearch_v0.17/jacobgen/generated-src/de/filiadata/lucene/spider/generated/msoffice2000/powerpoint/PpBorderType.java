/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpBorderType {

	public static final int ppBorderTop = 1;
	public static final int ppBorderLeft = 2;
	public static final int ppBorderBottom = 3;
	public static final int ppBorderRight = 4;
	public static final int ppBorderDiagonalDown = 5;
	public static final int ppBorderDiagonalUp = 6;
}
