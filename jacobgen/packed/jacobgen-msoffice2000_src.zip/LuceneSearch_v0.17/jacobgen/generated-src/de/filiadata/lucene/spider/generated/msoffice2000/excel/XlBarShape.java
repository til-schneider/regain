/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlBarShape {

	public static final int xlBox = 0;
	public static final int xlPyramidToPoint = 1;
	public static final int xlPyramidToMax = 2;
	public static final int xlCylinder = 3;
	public static final int xlConeToPoint = 4;
	public static final int xlConeToMax = 5;
}
