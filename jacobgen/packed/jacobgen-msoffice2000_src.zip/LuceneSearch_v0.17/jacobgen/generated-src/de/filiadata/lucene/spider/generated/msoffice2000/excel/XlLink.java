/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLink {

	public static final int xlExcelLinks = 1;
	public static final int xlOLELinks = 2;
	public static final int xlPublishers = 5;
	public static final int xlSubscribers = 6;
}
