/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCommentDisplayMode {

	public static final int xlNoIndicator = 0;
	public static final int xlCommentIndicatorOnly = -1;
	public static final int xlCommentAndIndicator = 1;
}
