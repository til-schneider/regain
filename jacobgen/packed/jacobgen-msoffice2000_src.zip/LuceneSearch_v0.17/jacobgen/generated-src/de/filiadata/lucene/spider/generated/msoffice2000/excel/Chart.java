/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Chart extends _Chart {

	public static final String componentName = "Excel.Chart";

	public Chart() {
		super(componentName);
	}

	public Chart(Dispatch d) {
		super(d);
	}
}
