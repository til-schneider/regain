/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlChartPicturePlacement {

	public static final int xlSides = 1;
	public static final int xlEnd = 2;
	public static final int xlEndSides = 3;
	public static final int xlFront = 4;
	public static final int xlFrontSides = 5;
	public static final int xlFrontEnd = 6;
	public static final int xlAllFaces = 7;
}
