/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSummaryReportType {

	public static final int xlSummaryPivotTable = -4148;
	public static final int xlStandardSummary = 1;
}
