/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class ChartEvents extends Dispatch {

	public static final String componentName = "Excel.ChartEvents";

	public ChartEvents() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ChartEvents(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ChartEvents(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void deactivate() {
		Dispatch.call(this, "Deactivate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resize() {
		Dispatch.call(this, "Resize");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type int
	 * @param shift an input-parameter of type int
	 * @param x an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void mouseDown(int button, int shift, int x, int lastParam) {
		Dispatch.call(this, "MouseDown", new Variant(button), new Variant(shift), new Variant(x), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type int
	 * @param shift an input-parameter of type int
	 * @param x an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void mouseUp(int button, int shift, int x, int lastParam) {
		Dispatch.call(this, "MouseUp", new Variant(button), new Variant(shift), new Variant(x), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type int
	 * @param shift an input-parameter of type int
	 * @param x an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void mouseMove(int button, int shift, int x, int lastParam) {
		Dispatch.call(this, "MouseMove", new Variant(button), new Variant(shift), new Variant(x), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeRightClick(boolean lastParam) {
		Dispatch.call(this, "BeforeRightClick", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dragPlot() {
		Dispatch.call(this, "DragPlot");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dragOver() {
		Dispatch.call(this, "DragOver");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param elementID an input-parameter of type int
	 * @param arg1 an input-parameter of type int
	 * @param arg2 an input-parameter of type int
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeDoubleClick(int elementID, int arg1, int arg2, boolean lastParam) {
		Dispatch.call(this, "BeforeDoubleClick", new Variant(elementID), new Variant(arg1), new Variant(arg2), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param elementID an input-parameter of type int
	 * @param arg1 an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void select(int elementID, int arg1, int lastParam) {
		Dispatch.call(this, "Select", new Variant(elementID), new Variant(arg1), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param seriesIndex an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void seriesChange(int seriesIndex, int lastParam) {
		Dispatch.call(this, "SeriesChange", new Variant(seriesIndex), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculate() {
		Dispatch.call(this, "Calculate");
	}

}
