/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Pane extends Dispatch {

	public static final String componentName = "Excel.Pane";

	public Pane() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Pane(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Pane(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean activate() {
		return Dispatch.call(this, "Activate").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIndex() {
		return Dispatch.get(this, "Index").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @param toRight an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant largeScroll(Variant down, Variant up, Variant toRight, Variant lastParam) {
		return Dispatch.call(this, "LargeScroll", down, up, toRight, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @param toRight an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant largeScroll(Variant down, Variant up, Variant toRight) {
		return Dispatch.call(this, "LargeScroll", down, up, toRight);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant largeScroll(Variant down, Variant up) {
		return Dispatch.call(this, "LargeScroll", down, up);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant largeScroll(Variant down) {
		return Dispatch.call(this, "LargeScroll", down);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant largeScroll() {
		return Dispatch.call(this, "LargeScroll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getScrollColumn() {
		return Dispatch.get(this, "ScrollColumn").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setScrollColumn(int lastParam) {
		Dispatch.call(this, "ScrollColumn", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getScrollRow() {
		return Dispatch.get(this, "ScrollRow").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setScrollRow(int lastParam) {
		Dispatch.call(this, "ScrollRow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @param toRight an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant smallScroll(Variant down, Variant up, Variant toRight, Variant lastParam) {
		return Dispatch.call(this, "SmallScroll", down, up, toRight, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @param toRight an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant smallScroll(Variant down, Variant up, Variant toRight) {
		return Dispatch.call(this, "SmallScroll", down, up, toRight);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @param up an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant smallScroll(Variant down, Variant up) {
		return Dispatch.call(this, "SmallScroll", down, up);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant smallScroll(Variant down) {
		return Dispatch.call(this, "SmallScroll", down);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant smallScroll() {
		return Dispatch.call(this, "SmallScroll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getVisibleRange() {
		return new Range(Dispatch.get(this, "VisibleRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type int
	 * @param top an input-parameter of type int
	 * @param width an input-parameter of type int
	 * @param height an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 */
	public void scrollIntoView(int left, int top, int width, int height, Variant lastParam) {
		Dispatch.call(this, "ScrollIntoView", new Variant(left), new Variant(top), new Variant(width), new Variant(height), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type int
	 * @param top an input-parameter of type int
	 * @param width an input-parameter of type int
	 * @param height an input-parameter of type int
	 */
	public void scrollIntoView(int left, int top, int width, int height) {
		Dispatch.call(this, "ScrollIntoView", new Variant(left), new Variant(top), new Variant(width), new Variant(height));
	}

}
