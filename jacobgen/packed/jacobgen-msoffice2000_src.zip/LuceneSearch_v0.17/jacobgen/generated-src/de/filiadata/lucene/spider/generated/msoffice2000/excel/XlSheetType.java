/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSheetType {

	public static final int xlChart = -4109;
	public static final int xlDialogSheet = -4116;
	public static final int xlExcel4IntlMacroSheet = 4;
	public static final int xlExcel4MacroSheet = 3;
	public static final int xlWorksheet = -4167;
}
