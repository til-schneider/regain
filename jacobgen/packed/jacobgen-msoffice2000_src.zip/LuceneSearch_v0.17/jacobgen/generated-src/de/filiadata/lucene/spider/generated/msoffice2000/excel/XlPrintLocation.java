/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPrintLocation {

	public static final int xlPrintSheetEnd = 1;
	public static final int xlPrintInPlace = 16;
	public static final int xlPrintNoComments = -4142;
}
