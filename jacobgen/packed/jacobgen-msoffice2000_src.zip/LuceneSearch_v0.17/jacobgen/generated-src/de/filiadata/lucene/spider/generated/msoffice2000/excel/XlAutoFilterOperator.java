/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlAutoFilterOperator {

	public static final int xlAnd = 1;
	public static final int xlBottom10Items = 4;
	public static final int xlBottom10Percent = 6;
	public static final int xlOr = 2;
	public static final int xlTop10Items = 3;
	public static final int xlTop10Percent = 5;
}
