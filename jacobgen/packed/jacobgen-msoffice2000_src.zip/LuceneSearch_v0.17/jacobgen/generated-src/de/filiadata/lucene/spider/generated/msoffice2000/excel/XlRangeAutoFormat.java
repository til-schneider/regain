/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlRangeAutoFormat {

	public static final int xlRangeAutoFormat3DEffects1 = 13;
	public static final int xlRangeAutoFormat3DEffects2 = 14;
	public static final int xlRangeAutoFormatAccounting1 = 4;
	public static final int xlRangeAutoFormatAccounting2 = 5;
	public static final int xlRangeAutoFormatAccounting3 = 6;
	public static final int xlRangeAutoFormatAccounting4 = 17;
	public static final int xlRangeAutoFormatClassic1 = 1;
	public static final int xlRangeAutoFormatClassic2 = 2;
	public static final int xlRangeAutoFormatClassic3 = 3;
	public static final int xlRangeAutoFormatColor1 = 7;
	public static final int xlRangeAutoFormatColor2 = 8;
	public static final int xlRangeAutoFormatColor3 = 9;
	public static final int xlRangeAutoFormatList1 = 10;
	public static final int xlRangeAutoFormatList2 = 11;
	public static final int xlRangeAutoFormatList3 = 12;
	public static final int xlRangeAutoFormatLocalFormat1 = 15;
	public static final int xlRangeAutoFormatLocalFormat2 = 16;
	public static final int xlRangeAutoFormatLocalFormat3 = 19;
	public static final int xlRangeAutoFormatLocalFormat4 = 20;
	public static final int xlRangeAutoFormatReport1 = 21;
	public static final int xlRangeAutoFormatReport2 = 22;
	public static final int xlRangeAutoFormatReport3 = 23;
	public static final int xlRangeAutoFormatReport4 = 24;
	public static final int xlRangeAutoFormatReport5 = 25;
	public static final int xlRangeAutoFormatReport6 = 26;
	public static final int xlRangeAutoFormatReport7 = 27;
	public static final int xlRangeAutoFormatReport8 = 28;
	public static final int xlRangeAutoFormatReport9 = 29;
	public static final int xlRangeAutoFormatReport10 = 30;
	public static final int xlRangeAutoFormatClassicPivotTable = 31;
	public static final int xlRangeAutoFormatTable1 = 32;
	public static final int xlRangeAutoFormatTable2 = 33;
	public static final int xlRangeAutoFormatTable3 = 34;
	public static final int xlRangeAutoFormatTable4 = 35;
	public static final int xlRangeAutoFormatTable5 = 36;
	public static final int xlRangeAutoFormatTable6 = 37;
	public static final int xlRangeAutoFormatTable7 = 38;
	public static final int xlRangeAutoFormatTable8 = 39;
	public static final int xlRangeAutoFormatTable9 = 40;
	public static final int xlRangeAutoFormatTable10 = 41;
	public static final int xlRangeAutoFormatPTNone = 42;
	public static final int xlRangeAutoFormatNone = -4142;
	public static final int xlRangeAutoFormatSimple = -4154;
}
