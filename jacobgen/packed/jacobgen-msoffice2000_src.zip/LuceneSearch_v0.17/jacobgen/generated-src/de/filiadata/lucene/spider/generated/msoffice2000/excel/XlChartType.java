/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlChartType {

	public static final int xlColumnClustered = 51;
	public static final int xlColumnStacked = 52;
	public static final int xlColumnStacked100 = 53;
	public static final int xl3DColumnClustered = 54;
	public static final int xl3DColumnStacked = 55;
	public static final int xl3DColumnStacked100 = 56;
	public static final int xlBarClustered = 57;
	public static final int xlBarStacked = 58;
	public static final int xlBarStacked100 = 59;
	public static final int xl3DBarClustered = 60;
	public static final int xl3DBarStacked = 61;
	public static final int xl3DBarStacked100 = 62;
	public static final int xlLineStacked = 63;
	public static final int xlLineStacked100 = 64;
	public static final int xlLineMarkers = 65;
	public static final int xlLineMarkersStacked = 66;
	public static final int xlLineMarkersStacked100 = 67;
	public static final int xlPieOfPie = 68;
	public static final int xlPieExploded = 69;
	public static final int xl3DPieExploded = 70;
	public static final int xlBarOfPie = 71;
	public static final int xlXYScatterSmooth = 72;
	public static final int xlXYScatterSmoothNoMarkers = 73;
	public static final int xlXYScatterLines = 74;
	public static final int xlXYScatterLinesNoMarkers = 75;
	public static final int xlAreaStacked = 76;
	public static final int xlAreaStacked100 = 77;
	public static final int xl3DAreaStacked = 78;
	public static final int xl3DAreaStacked100 = 79;
	public static final int xlDoughnutExploded = 80;
	public static final int xlRadarMarkers = 81;
	public static final int xlRadarFilled = 82;
	public static final int xlSurface = 83;
	public static final int xlSurfaceWireframe = 84;
	public static final int xlSurfaceTopView = 85;
	public static final int xlSurfaceTopViewWireframe = 86;
	public static final int xlBubble = 15;
	public static final int xlBubble3DEffect = 87;
	public static final int xlStockHLC = 88;
	public static final int xlStockOHLC = 89;
	public static final int xlStockVHLC = 90;
	public static final int xlStockVOHLC = 91;
	public static final int xlCylinderColClustered = 92;
	public static final int xlCylinderColStacked = 93;
	public static final int xlCylinderColStacked100 = 94;
	public static final int xlCylinderBarClustered = 95;
	public static final int xlCylinderBarStacked = 96;
	public static final int xlCylinderBarStacked100 = 97;
	public static final int xlCylinderCol = 98;
	public static final int xlConeColClustered = 99;
	public static final int xlConeColStacked = 100;
	public static final int xlConeColStacked100 = 101;
	public static final int xlConeBarClustered = 102;
	public static final int xlConeBarStacked = 103;
	public static final int xlConeBarStacked100 = 104;
	public static final int xlConeCol = 105;
	public static final int xlPyramidColClustered = 106;
	public static final int xlPyramidColStacked = 107;
	public static final int xlPyramidColStacked100 = 108;
	public static final int xlPyramidBarClustered = 109;
	public static final int xlPyramidBarStacked = 110;
	public static final int xlPyramidBarStacked100 = 111;
	public static final int xlPyramidCol = 112;
	public static final int xl3DColumn = -4100;
	public static final int xlLine = 4;
	public static final int xl3DLine = -4101;
	public static final int xl3DPie = -4102;
	public static final int xlPie = 5;
	public static final int xlXYScatter = -4169;
	public static final int xl3DArea = -4098;
	public static final int xlArea = 1;
	public static final int xlDoughnut = -4120;
	public static final int xlRadar = -4151;
}
