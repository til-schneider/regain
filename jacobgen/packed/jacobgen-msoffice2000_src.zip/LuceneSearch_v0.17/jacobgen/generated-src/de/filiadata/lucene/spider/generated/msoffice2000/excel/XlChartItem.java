/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlChartItem {

	public static final int xlDataLabel = 0;
	public static final int xlChartArea = 2;
	public static final int xlSeries = 3;
	public static final int xlChartTitle = 4;
	public static final int xlWalls = 5;
	public static final int xlCorners = 6;
	public static final int xlDataTable = 7;
	public static final int xlTrendline = 8;
	public static final int xlErrorBars = 9;
	public static final int xlXErrorBars = 10;
	public static final int xlYErrorBars = 11;
	public static final int xlLegendEntry = 12;
	public static final int xlLegendKey = 13;
	public static final int xlShape = 14;
	public static final int xlMajorGridlines = 15;
	public static final int xlMinorGridlines = 16;
	public static final int xlAxisTitle = 17;
	public static final int xlUpBars = 18;
	public static final int xlPlotArea = 19;
	public static final int xlDownBars = 20;
	public static final int xlAxis = 21;
	public static final int xlSeriesLines = 22;
	public static final int xlFloor = 23;
	public static final int xlLegend = 24;
	public static final int xlHiLoLines = 25;
	public static final int xlDropLines = 26;
	public static final int xlRadarAxisLabels = 27;
	public static final int xlNothing = 28;
	public static final int xlLeaderLines = 29;
	public static final int xlDisplayUnitLabel = 30;
	public static final int xlPivotChartFieldButton = 31;
	public static final int xlPivotChartDropZone = 32;
}
