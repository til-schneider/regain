/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPivotFieldDataType {

	public static final int xlDate = 2;
	public static final int xlNumber = -4145;
	public static final int xlText = -4158;
}
