/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class PPDialogs extends Dispatch {

	public static final String componentName = "PowerPoint.PPDialogs";

	public PPDialogs() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PPDialogs(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PPDialogs(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant _Index(int lastParam) {
		return Dispatch.call(this, "_Index", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PPDialog
	 */
	public PPDialog item(Variant lastParam) {
		return new PPDialog(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @param position an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addDialog(float left, float top, float width, float height, int modal, Variant parentWindow, int position, int lastParam) {
		return new PPDialog(Dispatch.call(this, "AddDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow, new Variant(position), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @param position an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addDialog(float left, float top, float width, float height, int modal, Variant parentWindow, int position) {
		return new PPDialog(Dispatch.call(this, "AddDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow, new Variant(position)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @return the result is of type PPDialog
	 */
	public PPDialog addDialog(float left, float top, float width, float height, int modal, Variant parentWindow) {
		return new PPDialog(Dispatch.call(this, "AddDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addDialog(float left, float top, float width, float height, int modal) {
		return new PPDialog(Dispatch.call(this, "AddDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @return the result is of type PPDialog
	 */
	public PPDialog addDialog(float left, float top, float width, float height) {
		return new PPDialog(Dispatch.call(this, "AddDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @param position an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addTabDialog(float left, float top, float width, float height, int modal, Variant parentWindow, int position, int lastParam) {
		return new PPDialog(Dispatch.call(this, "AddTabDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow, new Variant(position), new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @param position an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addTabDialog(float left, float top, float width, float height, int modal, Variant parentWindow, int position) {
		return new PPDialog(Dispatch.call(this, "AddTabDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow, new Variant(position)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @return the result is of type PPDialog
	 */
	public PPDialog addTabDialog(float left, float top, float width, float height, int modal, Variant parentWindow) {
		return new PPDialog(Dispatch.call(this, "AddTabDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal), parentWindow).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param modal an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog addTabDialog(float left, float top, float width, float height, int modal) {
		return new PPDialog(Dispatch.call(this, "AddTabDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(modal)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @return the result is of type PPDialog
	 */
	public PPDialog addTabDialog(float left, float top, float width, float height) {
		return new PPDialog(Dispatch.call(this, "AddTabDialog", new Variant(left), new Variant(top), new Variant(width), new Variant(height)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param resourceDLL an input-parameter of type String
	 * @param nResID an input-parameter of type int
	 * @param bModal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog loadDialog(String resourceDLL, int nResID, int bModal, Variant parentWindow, int lastParam) {
		return new PPDialog(Dispatch.call(this, "LoadDialog", resourceDLL, new Variant(nResID), new Variant(bModal), parentWindow, new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param resourceDLL an input-parameter of type String
	 * @param nResID an input-parameter of type int
	 * @param bModal an input-parameter of type int
	 * @param parentWindow an input-parameter of type Variant
	 * @return the result is of type PPDialog
	 */
	public PPDialog loadDialog(String resourceDLL, int nResID, int bModal, Variant parentWindow) {
		return new PPDialog(Dispatch.call(this, "LoadDialog", resourceDLL, new Variant(nResID), new Variant(bModal), parentWindow).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param resourceDLL an input-parameter of type String
	 * @param nResID an input-parameter of type int
	 * @param bModal an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog loadDialog(String resourceDLL, int nResID, int bModal) {
		return new PPDialog(Dispatch.call(this, "LoadDialog", resourceDLL, new Variant(nResID), new Variant(bModal)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param resourceDLL an input-parameter of type String
	 * @param nResID an input-parameter of type int
	 * @return the result is of type PPDialog
	 */
	public PPDialog loadDialog(String resourceDLL, int nResID) {
		return new PPDialog(Dispatch.call(this, "LoadDialog", resourceDLL, new Variant(nResID)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PPAlert
	 */
	public PPAlert addAlert() {
		return new PPAlert(Dispatch.call(this, "AddAlert").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Tags
	 */
	public Tags getTags() {
		return new Tags(Dispatch.get(this, "Tags").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type String
	 * @param type an input-parameter of type int
	 * @param icon an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type int
	 */
	public int runCharacterAlert(String text, int type, int icon, Variant lastParam) {
		return Dispatch.call(this, "RunCharacterAlert", text, new Variant(type), new Variant(icon), lastParam).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type String
	 * @param type an input-parameter of type int
	 * @param icon an input-parameter of type int
	 * @return the result is of type int
	 */
	public int runCharacterAlert(String text, int type, int icon) {
		return Dispatch.call(this, "RunCharacterAlert", text, new Variant(type), new Variant(icon)).toInt();
	}

}
