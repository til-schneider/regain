/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFormatConditionOperator {

	public static final int xlBetween = 1;
	public static final int xlNotBetween = 2;
	public static final int xlEqual = 3;
	public static final int xlNotEqual = 4;
	public static final int xlGreater = 5;
	public static final int xlLess = 6;
	public static final int xlGreaterEqual = 7;
	public static final int xlLessEqual = 8;
}
