/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface xlDisplayDrawingObjects {

	public static final int xlDisplayShapes = -4104;
	public static final int xlHide = 3;
	public static final int xlPlaceholders = 2;
}
