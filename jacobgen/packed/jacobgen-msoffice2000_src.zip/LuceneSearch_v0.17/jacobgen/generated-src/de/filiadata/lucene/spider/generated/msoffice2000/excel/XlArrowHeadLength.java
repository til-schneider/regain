/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlArrowHeadLength {

	public static final int xlArrowHeadLengthLong = 3;
	public static final int xlArrowHeadLengthMedium = -4138;
	public static final int xlArrowHeadLengthShort = 1;
}
