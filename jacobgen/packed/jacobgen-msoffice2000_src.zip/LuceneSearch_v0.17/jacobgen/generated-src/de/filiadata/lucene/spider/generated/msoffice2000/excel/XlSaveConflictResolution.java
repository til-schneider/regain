/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSaveConflictResolution {

	public static final int xlLocalSessionChanges = 2;
	public static final int xlOtherSessionChanges = 3;
	public static final int xlUserResolution = 1;
}
