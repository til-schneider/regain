/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpAfterEffect {

	public static final int ppAfterEffectMixed = -2;
	public static final int ppAfterEffectNothing = 0;
	public static final int ppAfterEffectHide = 1;
	public static final int ppAfterEffectDim = 2;
	public static final int ppAfterEffectHideOnClick = 3;
}
