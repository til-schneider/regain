/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCalculation {

	public static final int xlCalculationAutomatic = -4105;
	public static final int xlCalculationManual = -4135;
	public static final int xlCalculationSemiautomatic = 2;
}
