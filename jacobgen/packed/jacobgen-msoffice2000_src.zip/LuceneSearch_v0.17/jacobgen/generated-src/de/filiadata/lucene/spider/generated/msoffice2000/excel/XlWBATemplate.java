/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlWBATemplate {

	public static final int xlWBATChart = -4109;
	public static final int xlWBATExcel4IntlMacroSheet = 4;
	public static final int xlWBATExcel4MacroSheet = 3;
	public static final int xlWBATWorksheet = -4167;
}
