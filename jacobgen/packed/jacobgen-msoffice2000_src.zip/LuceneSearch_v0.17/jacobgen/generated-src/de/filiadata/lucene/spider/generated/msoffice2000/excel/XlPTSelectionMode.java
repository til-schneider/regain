/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPTSelectionMode {

	public static final int xlLabelOnly = 1;
	public static final int xlDataAndLabel = 0;
	public static final int xlDataOnly = 2;
	public static final int xlOrigin = 3;
	public static final int xlButton = 15;
	public static final int xlBlanks = 4;
	public static final int xlFirstRow = 256;
}
