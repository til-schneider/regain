/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Mailer extends Dispatch {

	public static final String componentName = "Excel.Mailer";

	public Mailer() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Mailer(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Mailer(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getBCCRecipients() {
		return Dispatch.get(this, "BCCRecipients");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setBCCRecipients(Variant lastParam) {
		Dispatch.call(this, "BCCRecipients", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getCCRecipients() {
		return Dispatch.get(this, "CCRecipients");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setCCRecipients(Variant lastParam) {
		Dispatch.call(this, "CCRecipients", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getEnclosures() {
		return Dispatch.get(this, "Enclosures");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setEnclosures(Variant lastParam) {
		Dispatch.call(this, "Enclosures", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getReceived() {
		return Dispatch.get(this, "Received").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type java.util.Date
	 */
	public java.util.Date getSendDateTime() {
		return comDateToJavaDate(Dispatch.get(this, "SendDateTime").toDate());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getSender() {
		return Dispatch.get(this, "Sender").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getSubject() {
		return Dispatch.get(this, "Subject").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setSubject(String lastParam) {
		Dispatch.call(this, "Subject", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getToRecipients() {
		return Dispatch.get(this, "ToRecipients");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setToRecipients(Variant lastParam) {
		Dispatch.call(this, "ToRecipients", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getWhichAddress() {
		return Dispatch.get(this, "WhichAddress");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setWhichAddress(Variant lastParam) {
		Dispatch.call(this, "WhichAddress", lastParam);
	}

	static long zoneOffset	= java.util.Calendar.getInstance().get(java.util.Calendar.ZONE_OFFSET);

	static java.util.Date comDateToJavaDate(double comDate) {
		comDate = comDate - 25569D;
		long millis = Math.round(86400000L * comDate) - zoneOffset;

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(new java.util.Date(millis));
		millis -= cal.get(cal.DST_OFFSET);

		return new java.util.Date(millis);
	}

	static double javaDateToComDate(java.util.Date javaDate) {

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(javaDate);
		long gmtOffset = (cal.get(cal.ZONE_OFFSET) + cal.get(cal.DST_OFFSET));

		long millis = javaDate.getTime() + gmtOffset;
		return 25569D+millis/86400000D;
	}

}
