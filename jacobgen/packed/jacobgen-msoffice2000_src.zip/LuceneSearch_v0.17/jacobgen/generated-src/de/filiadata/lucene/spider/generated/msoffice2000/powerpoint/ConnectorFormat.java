/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class ConnectorFormat extends Dispatch {

	public static final String componentName = "PowerPoint.ConnectorFormat";

	public ConnectorFormat() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ConnectorFormat(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ConnectorFormat(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getApplication() {
		return Dispatch.get(this, "Application");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param connectedShape an input-parameter of type Shape
	 * @param lastParam an input-parameter of type int
	 */
	public void beginConnect(Shape connectedShape, int lastParam) {
		Dispatch.call(this, "BeginConnect", connectedShape, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void beginDisconnect() {
		Dispatch.call(this, "BeginDisconnect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param connectedShape an input-parameter of type Shape
	 * @param lastParam an input-parameter of type int
	 */
	public void endConnect(Shape connectedShape, int lastParam) {
		Dispatch.call(this, "EndConnect", connectedShape, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void endDisconnect() {
		Dispatch.call(this, "EndDisconnect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getBeginConnected() {
		return Dispatch.get(this, "BeginConnected").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Shape
	 */
	public Shape getBeginConnectedShape() {
		return new Shape(Dispatch.get(this, "BeginConnectedShape").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getBeginConnectionSite() {
		return Dispatch.get(this, "BeginConnectionSite").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getEndConnected() {
		return Dispatch.get(this, "EndConnected").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Shape
	 */
	public Shape getEndConnectedShape() {
		return new Shape(Dispatch.get(this, "EndConnectedShape").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getEndConnectionSite() {
		return Dispatch.get(this, "EndConnectionSite").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getType() {
		return Dispatch.get(this, "Type").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setType(int lastParam) {
		Dispatch.call(this, "Type", new Variant(lastParam));
	}

}
