/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class DocumentWindow extends Dispatch {

	public static final String componentName = "PowerPoint.DocumentWindow";

	public DocumentWindow() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public DocumentWindow(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public DocumentWindow(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Selection
	 */
	public Selection getSelection() {
		return new Selection(Dispatch.get(this, "Selection").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type View
	 */
	public View getView() {
		return new View(Dispatch.get(this, "View").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Presentation
	 */
	public Presentation getPresentation() {
		return new Presentation(Dispatch.get(this, "Presentation").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getViewType() {
		return Dispatch.get(this, "ViewType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setViewType(int lastParam) {
		Dispatch.call(this, "ViewType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getBlackAndWhite() {
		return Dispatch.get(this, "BlackAndWhite").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setBlackAndWhite(int lastParam) {
		Dispatch.call(this, "BlackAndWhite", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getActive() {
		return Dispatch.get(this, "Active").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getWindowState() {
		return Dispatch.get(this, "WindowState").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setWindowState(int lastParam) {
		Dispatch.call(this, "WindowState", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCaption() {
		return Dispatch.get(this, "Caption").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type float
	 */
	public float getLeft() {
		return Dispatch.get(this, "Left").toFloat();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 */
	public void setLeft(float lastParam) {
		Dispatch.call(this, "Left", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type float
	 */
	public float getTop() {
		return Dispatch.get(this, "Top").toFloat();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 */
	public void setTop(float lastParam) {
		Dispatch.call(this, "Top", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type float
	 */
	public float getWidth() {
		return Dispatch.get(this, "Width").toFloat();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 */
	public void setWidth(float lastParam) {
		Dispatch.call(this, "Width", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type float
	 */
	public float getHeight() {
		return Dispatch.get(this, "Height").toFloat();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 */
	public void setHeight(float lastParam) {
		Dispatch.call(this, "Height", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void fitToPage() {
		Dispatch.call(this, "FitToPage");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 * @param toRight an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void largeScroll(int down, int up, int toRight, int lastParam) {
		Dispatch.call(this, "LargeScroll", new Variant(down), new Variant(up), new Variant(toRight), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 * @param toRight an input-parameter of type int
	 */
	public void largeScroll(int down, int up, int toRight) {
		Dispatch.call(this, "LargeScroll", new Variant(down), new Variant(up), new Variant(toRight));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 */
	public void largeScroll(int down, int up) {
		Dispatch.call(this, "LargeScroll", new Variant(down), new Variant(up));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 */
	public void largeScroll(int down) {
		Dispatch.call(this, "LargeScroll", new Variant(down));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void largeScroll() {
		Dispatch.call(this, "LargeScroll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 * @param toRight an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void smallScroll(int down, int up, int toRight, int lastParam) {
		Dispatch.call(this, "SmallScroll", new Variant(down), new Variant(up), new Variant(toRight), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 * @param toRight an input-parameter of type int
	 */
	public void smallScroll(int down, int up, int toRight) {
		Dispatch.call(this, "SmallScroll", new Variant(down), new Variant(up), new Variant(toRight));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 * @param up an input-parameter of type int
	 */
	public void smallScroll(int down, int up) {
		Dispatch.call(this, "SmallScroll", new Variant(down), new Variant(up));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param down an input-parameter of type int
	 */
	public void smallScroll(int down) {
		Dispatch.call(this, "SmallScroll", new Variant(down));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void smallScroll() {
		Dispatch.call(this, "SmallScroll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type DocumentWindow
	 */
	public DocumentWindow newWindow() {
		return new DocumentWindow(Dispatch.call(this, "NewWindow").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void close() {
		Dispatch.call(this, "Close");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getHWND() {
		return Dispatch.get(this, "HWND").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Pane
	 */
	public Pane getActivePane() {
		return new Pane(Dispatch.get(this, "ActivePane").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Panes
	 */
	public Panes getPanes() {
		return new Panes(Dispatch.get(this, "Panes").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getSplitVertical() {
		return Dispatch.get(this, "SplitVertical").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setSplitVertical(int lastParam) {
		Dispatch.call(this, "SplitVertical", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getSplitHorizontal() {
		return Dispatch.get(this, "SplitHorizontal").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setSplitHorizontal(int lastParam) {
		Dispatch.call(this, "SplitHorizontal", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param x an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Object
	 */
	public Object rangeFromPoint(int x, int lastParam) {
		return Dispatch.call(this, "RangeFromPoint", new Variant(x), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type int
	 */
	public int pointsToScreenPixelsX(float lastParam) {
		return Dispatch.call(this, "PointsToScreenPixelsX", new Variant(lastParam)).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type float
	 * @return the result is of type int
	 */
	public int pointsToScreenPixelsY(float lastParam) {
		return Dispatch.call(this, "PointsToScreenPixelsY", new Variant(lastParam)).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 * @param lastParam an input-parameter of type int
	 */
	public void scrollIntoView(float left, float top, float width, float height, int lastParam) {
		Dispatch.call(this, "ScrollIntoView", new Variant(left), new Variant(top), new Variant(width), new Variant(height), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param left an input-parameter of type float
	 * @param top an input-parameter of type float
	 * @param width an input-parameter of type float
	 * @param height an input-parameter of type float
	 */
	public void scrollIntoView(float left, float top, float width, float height) {
		Dispatch.call(this, "ScrollIntoView", new Variant(left), new Variant(top), new Variant(width), new Variant(height));
	}

}
