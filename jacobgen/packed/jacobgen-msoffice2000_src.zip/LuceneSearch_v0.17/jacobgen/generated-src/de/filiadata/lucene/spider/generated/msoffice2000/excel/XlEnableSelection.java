/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlEnableSelection {

	public static final int xlNoRestrictions = 0;
	public static final int xlUnlockedCells = 1;
	public static final int xlNoSelection = -4142;
}
