/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class PivotLayout extends Dispatch {

	public static final String componentName = "Excel.PivotLayout";

	public PivotLayout() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PivotLayout(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PivotLayout(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getColumnFields(Variant lastParam) {
		return Dispatch.call(this, "ColumnFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getColumnFields() {
		return Dispatch.get(this, "ColumnFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getDataFields(Variant lastParam) {
		return Dispatch.call(this, "DataFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getDataFields() {
		return Dispatch.get(this, "DataFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getPageFields(Variant lastParam) {
		return Dispatch.call(this, "PageFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPageFields() {
		return Dispatch.get(this, "PageFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getRowFields(Variant lastParam) {
		return Dispatch.call(this, "RowFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getRowFields() {
		return Dispatch.get(this, "RowFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getHiddenFields(Variant lastParam) {
		return Dispatch.call(this, "HiddenFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getHiddenFields() {
		return Dispatch.get(this, "HiddenFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getVisibleFields(Variant lastParam) {
		return Dispatch.call(this, "VisibleFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getVisibleFields() {
		return Dispatch.get(this, "VisibleFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getPivotFields(Variant lastParam) {
		return Dispatch.call(this, "PivotFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPivotFields() {
		return Dispatch.get(this, "PivotFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type CubeFields
	 */
	public CubeFields getCubeFields() {
		return new CubeFields(Dispatch.get(this, "CubeFields").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotCache
	 */
	public PivotCache getPivotCache() {
		return new PivotCache(Dispatch.get(this, "PivotCache").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotTable
	 */
	public PivotTable getPivotTable() {
		return new PivotTable(Dispatch.get(this, "PivotTable").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getInnerDetail() {
		return Dispatch.get(this, "InnerDetail").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setInnerDetail(String lastParam) {
		Dispatch.call(this, "InnerDetail", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 * @param pageFields an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void addFields(Variant rowFields, Variant columnFields, Variant pageFields, Variant lastParam) {
		Dispatch.call(this, "AddFields", rowFields, columnFields, pageFields, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 * @param pageFields an input-parameter of type Variant
	 */
	public void addFields(Variant rowFields, Variant columnFields, Variant pageFields) {
		Dispatch.call(this, "AddFields", rowFields, columnFields, pageFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 */
	public void addFields(Variant rowFields, Variant columnFields) {
		Dispatch.call(this, "AddFields", rowFields, columnFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 */
	public void addFields(Variant rowFields) {
		Dispatch.call(this, "AddFields", rowFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void addFields() {
		Dispatch.call(this, "AddFields");
	}

}
