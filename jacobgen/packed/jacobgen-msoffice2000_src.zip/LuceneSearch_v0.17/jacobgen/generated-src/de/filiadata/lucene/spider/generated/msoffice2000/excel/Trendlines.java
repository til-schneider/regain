/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Trendlines extends Dispatch {

	public static final String componentName = "Excel.Trendlines";

	public Trendlines() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Trendlines(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Trendlines(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @param backward an input-parameter of type Variant
	 * @param intercept an input-parameter of type Variant
	 * @param displayEquation an input-parameter of type Variant
	 * @param displayRSquared an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward, Variant backward, Variant intercept, Variant displayEquation, Variant displayRSquared, Variant lastParam) {
		return new Trendline(Dispatch.callN(this, "Add", new Object[] { new Variant(type), order, period, forward, backward, intercept, displayEquation, displayRSquared, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @param backward an input-parameter of type Variant
	 * @param intercept an input-parameter of type Variant
	 * @param displayEquation an input-parameter of type Variant
	 * @param displayRSquared an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward, Variant backward, Variant intercept, Variant displayEquation, Variant displayRSquared) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period, forward, backward, intercept, displayEquation, displayRSquared).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @param backward an input-parameter of type Variant
	 * @param intercept an input-parameter of type Variant
	 * @param displayEquation an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward, Variant backward, Variant intercept, Variant displayEquation) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period, forward, backward, intercept, displayEquation).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @param backward an input-parameter of type Variant
	 * @param intercept an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward, Variant backward, Variant intercept) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period, forward, backward, intercept).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @param backward an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward, Variant backward) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period, forward, backward).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @param forward an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period, Variant forward) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period, forward).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @param period an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order, Variant period) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order, period).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param order an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type, Variant order) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type), order).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @return the result is of type Trendline
	 */
	public Trendline add(int type) {
		return new Trendline(Dispatch.call(this, "Add", new Variant(type)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Trendline
	 */
	public Trendline add() {
		return new Trendline(Dispatch.call(this, "Add").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Trendline
	 */
	public Trendline item(Variant lastParam) {
		return new Trendline(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Trendline
	 */
	public Trendline item() {
		return new Trendline(Dispatch.call(this, "Item").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _NewEnum() {
		return Dispatch.call(this, "_NewEnum");
	}

}
