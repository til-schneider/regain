/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPageBreak {

	public static final int xlPageBreakAutomatic = -4105;
	public static final int xlPageBreakManual = -4135;
	public static final int xlPageBreakNone = -4142;
}
