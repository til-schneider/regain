/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class FileDialog extends Dispatch {

	public static final String componentName = "PowerPoint.FileDialog";

	public FileDialog() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public FileDialog(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public FileDialog(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type FileDialogExtensionList
	 */
	public FileDialogExtensionList getExtensions() {
		return new FileDialogExtensionList(Dispatch.get(this, "Extensions").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getDefaultDirectoryRegKey() {
		return Dispatch.get(this, "DefaultDirectoryRegKey").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setDefaultDirectoryRegKey(String lastParam) {
		Dispatch.call(this, "DefaultDirectoryRegKey", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getDialogTitle() {
		return Dispatch.get(this, "DialogTitle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setDialogTitle(String lastParam) {
		Dispatch.call(this, "DialogTitle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getActionButtonName() {
		return Dispatch.get(this, "ActionButtonName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setActionButtonName(String lastParam) {
		Dispatch.call(this, "ActionButtonName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIsMultiSelect() {
		return Dispatch.get(this, "IsMultiSelect").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setIsMultiSelect(int lastParam) {
		Dispatch.call(this, "IsMultiSelect", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIsPrintEnabled() {
		return Dispatch.get(this, "IsPrintEnabled").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setIsPrintEnabled(int lastParam) {
		Dispatch.call(this, "IsPrintEnabled", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIsReadOnlyEnabled() {
		return Dispatch.get(this, "IsReadOnlyEnabled").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setIsReadOnlyEnabled(int lastParam) {
		Dispatch.call(this, "IsReadOnlyEnabled", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDirectoriesOnly() {
		return Dispatch.get(this, "DirectoriesOnly").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDirectoriesOnly(int lastParam) {
		Dispatch.call(this, "DirectoriesOnly", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getInitialView() {
		return Dispatch.get(this, "InitialView").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setInitialView(int lastParam) {
		Dispatch.call(this, "InitialView", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void launch(Variant lastParam) {
		Dispatch.call(this, "Launch", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void launch() {
		Dispatch.call(this, "Launch");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnAction() {
		return Dispatch.get(this, "OnAction").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnAction(String lastParam) {
		Dispatch.call(this, "OnAction", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type FileDialogFileList
	 */
	public FileDialogFileList getFiles() {
		return new FileDialogFileList(Dispatch.get(this, "Files").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getUseODMADlgs() {
		return Dispatch.get(this, "UseODMADlgs").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setUseODMADlgs(int lastParam) {
		Dispatch.call(this, "UseODMADlgs", new Variant(lastParam));
	}

}
