/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Charts extends Dispatch {

	public static final String componentName = "Excel.Charts";

	public Charts() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Charts(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Charts(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Chart
	 */
	public Chart add(Variant before, Variant after, Variant lastParam) {
		return new Chart(Dispatch.call(this, "Add", before, after, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @return the result is of type Chart
	 */
	public Chart add(Variant before, Variant after) {
		return new Chart(Dispatch.call(this, "Add", before, after).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @return the result is of type Chart
	 */
	public Chart add(Variant before) {
		return new Chart(Dispatch.call(this, "Add", before).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Chart
	 */
	public Chart add() {
		return new Chart(Dispatch.call(this, "Add").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void copy(Variant before, Variant lastParam) {
		Dispatch.call(this, "Copy", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void copy(Variant before) {
		Dispatch.call(this, "Copy", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copy() {
		Dispatch.call(this, "Copy");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _Dummy7() {
		Dispatch.call(this, "_Dummy7");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getItem(Variant lastParam) {
		return Dispatch.call(this, "Item", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void move(Variant before, Variant lastParam) {
		Dispatch.call(this, "Move", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void move(Variant before) {
		Dispatch.call(this, "Move", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void move() {
		Dispatch.call(this, "Move");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to) {
		Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from) {
		Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _PrintOut() {
		Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printPreview(Variant lastParam) {
		Dispatch.call(this, "PrintPreview", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printPreview() {
		Dispatch.call(this, "PrintPreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void select(Variant lastParam) {
		Dispatch.call(this, "Select", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void select() {
		Dispatch.call(this, "Select");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type HPageBreaks
	 */
	public HPageBreaks getHPageBreaks() {
		return new HPageBreaks(Dispatch.get(this, "HPageBreaks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type VPageBreaks
	 */
	public VPageBreaks getVPageBreaks() {
		return new VPageBreaks(Dispatch.get(this, "VPageBreaks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getVisible() {
		return Dispatch.get(this, "Visible");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setVisible(Variant lastParam) {
		Dispatch.call(this, "Visible", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object get_Default(Variant lastParam) {
		return Dispatch.call(this, "_Default", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate, Variant lastParam) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to) {
		Dispatch.call(this, "PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void printOut(Variant from) {
		Dispatch.call(this, "PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printOut() {
		Dispatch.call(this, "PrintOut");
	}

}
