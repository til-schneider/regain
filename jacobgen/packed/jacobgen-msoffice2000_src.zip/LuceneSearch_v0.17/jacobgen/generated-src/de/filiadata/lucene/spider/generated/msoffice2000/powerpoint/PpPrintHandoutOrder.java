/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpPrintHandoutOrder {

	public static final int ppPrintHandoutVerticalFirst = 1;
	public static final int ppPrintHandoutHorizontalFirst = 2;
}
