/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpFileDialogView {

	public static final int ppFileDialogViewDetails = 1;
	public static final int ppFileDialogViewPreview = 2;
	public static final int ppFileDialogViewProperties = 3;
	public static final int ppFileDialogViewList = 4;
}
