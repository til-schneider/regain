/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlVAlign {

	public static final int xlVAlignBottom = -4107;
	public static final int xlVAlignCenter = -4108;
	public static final int xlVAlignDistributed = -4117;
	public static final int xlVAlignJustify = -4130;
	public static final int xlVAlignTop = -4160;
}
