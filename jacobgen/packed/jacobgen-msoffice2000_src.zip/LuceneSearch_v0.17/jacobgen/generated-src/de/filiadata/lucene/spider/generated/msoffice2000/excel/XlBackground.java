/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlBackground {

	public static final int xlBackgroundAutomatic = -4105;
	public static final int xlBackgroundOpaque = 3;
	public static final int xlBackgroundTransparent = 2;
}
