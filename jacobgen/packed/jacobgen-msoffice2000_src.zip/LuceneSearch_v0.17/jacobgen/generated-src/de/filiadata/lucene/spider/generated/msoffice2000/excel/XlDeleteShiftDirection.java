/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDeleteShiftDirection {

	public static final int xlShiftToLeft = -4159;
	public static final int xlShiftUp = -4162;
}
