/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class OLEObject extends _OLEObject {

	public static final String componentName = "Excel.OLEObject";

	public OLEObject() {
		super(componentName);
	}

	public OLEObject(Dispatch d) {
		super(d);
	}
}
