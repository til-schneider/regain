/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class WorkbookEvents extends Dispatch {

	public static final String componentName = "Excel.WorkbookEvents";

	public WorkbookEvents() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public WorkbookEvents(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public WorkbookEvents(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void open() {
		Dispatch.call(this, "Open");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void deactivate() {
		Dispatch.call(this, "Deactivate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeClose(boolean lastParam) {
		Dispatch.call(this, "BeforeClose", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param saveAsUI an input-parameter of type boolean
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeSave(boolean saveAsUI, boolean lastParam) {
		Dispatch.call(this, "BeforeSave", new Variant(saveAsUI), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforePrint(boolean lastParam) {
		Dispatch.call(this, "BeforePrint", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void newSheet(Object lastParam) {
		Dispatch.call(this, "NewSheet", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void addinInstall() {
		Dispatch.call(this, "AddinInstall");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void addinUninstall() {
		Dispatch.call(this, "AddinUninstall");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowResize(Window lastParam) {
		Dispatch.call(this, "WindowResize", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowActivate(Window lastParam) {
		Dispatch.call(this, "WindowActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowDeactivate(Window lastParam) {
		Dispatch.call(this, "WindowDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Range
	 */
	public void sheetSelectionChange(Object sh, Range lastParam) {
		Dispatch.call(this, "SheetSelectionChange", sh, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void sheetBeforeDoubleClick(Object sh, Range target, boolean lastParam) {
		Dispatch.call(this, "SheetBeforeDoubleClick", sh, target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void sheetBeforeRightClick(Object sh, Range target, boolean lastParam) {
		Dispatch.call(this, "SheetBeforeRightClick", sh, target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetActivate(Object lastParam) {
		Dispatch.call(this, "SheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetDeactivate(Object lastParam) {
		Dispatch.call(this, "SheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetCalculate(Object lastParam) {
		Dispatch.call(this, "SheetCalculate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Range
	 */
	public void sheetChange(Object sh, Range lastParam) {
		Dispatch.call(this, "SheetChange", sh, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Hyperlink
	 */
	public void sheetFollowHyperlink(Object sh, Hyperlink lastParam) {
		Dispatch.call(this, "SheetFollowHyperlink", sh, lastParam);
	}

}
