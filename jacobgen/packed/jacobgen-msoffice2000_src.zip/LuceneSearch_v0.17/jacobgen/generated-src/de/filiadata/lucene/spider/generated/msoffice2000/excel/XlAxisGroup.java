/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlAxisGroup {

	public static final int xlPrimary = 1;
	public static final int xlSecondary = 2;
}
