/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPasteType {

	public static final int xlPasteAll = -4104;
	public static final int xlPasteAllExceptBorders = 7;
	public static final int xlPasteFormats = -4122;
	public static final int xlPasteFormulas = -4123;
	public static final int xlPasteComments = -4144;
	public static final int xlPasteValues = -4163;
}
