/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlToolbarProtection {

	public static final int xlNoButtonChanges = 1;
	public static final int xlNoChanges = 4;
	public static final int xlNoDockingChanges = 3;
	public static final int xlToolbarProtectionNone = -4143;
	public static final int xlNoShapeChanges = 2;
}
