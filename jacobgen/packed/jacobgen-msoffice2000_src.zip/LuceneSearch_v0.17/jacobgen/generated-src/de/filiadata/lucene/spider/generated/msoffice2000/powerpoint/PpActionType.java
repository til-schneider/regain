/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpActionType {

	public static final int ppActionMixed = -2;
	public static final int ppActionNone = 0;
	public static final int ppActionNextSlide = 1;
	public static final int ppActionPreviousSlide = 2;
	public static final int ppActionFirstSlide = 3;
	public static final int ppActionLastSlide = 4;
	public static final int ppActionLastSlideViewed = 5;
	public static final int ppActionEndShow = 6;
	public static final int ppActionHyperlink = 7;
	public static final int ppActionRunMacro = 8;
	public static final int ppActionRunProgram = 9;
	public static final int ppActionNamedSlideShow = 10;
	public static final int ppActionOLEVerb = 11;
	public static final int ppActionPlay = 12;
}
