/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPhoneticCharacterType {

	public static final int xlKatakanaHalf = 0;
	public static final int xlKatakana = 1;
	public static final int xlHiragana = 2;
	public static final int xlNoConversion = 3;
}
