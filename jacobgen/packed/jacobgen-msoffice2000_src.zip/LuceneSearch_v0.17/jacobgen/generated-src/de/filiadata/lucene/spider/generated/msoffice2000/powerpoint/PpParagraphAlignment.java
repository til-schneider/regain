/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpParagraphAlignment {

	public static final int ppAlignmentMixed = -2;
	public static final int ppAlignLeft = 1;
	public static final int ppAlignCenter = 2;
	public static final int ppAlignRight = 3;
	public static final int ppAlignJustify = 4;
	public static final int ppAlignDistribute = 5;
}
