/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPlatform {

	public static final int xlMacintosh = 1;
	public static final int xlMSDOS = 3;
	public static final int xlWindows = 2;
}
