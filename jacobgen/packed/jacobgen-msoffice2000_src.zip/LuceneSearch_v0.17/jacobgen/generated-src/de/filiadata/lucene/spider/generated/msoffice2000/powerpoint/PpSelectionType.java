/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpSelectionType {

	public static final int ppSelectionNone = 0;
	public static final int ppSelectionSlides = 1;
	public static final int ppSelectionShapes = 2;
	public static final int ppSelectionText = 3;
}
