/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLookAt {

	public static final int xlPart = 2;
	public static final int xlWhole = 1;
}
