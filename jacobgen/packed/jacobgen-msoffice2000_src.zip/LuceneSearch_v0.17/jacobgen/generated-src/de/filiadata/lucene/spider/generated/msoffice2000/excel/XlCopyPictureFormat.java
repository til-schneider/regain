/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCopyPictureFormat {

	public static final int xlBitmap = 2;
	public static final int xlPicture = -4147;
}
