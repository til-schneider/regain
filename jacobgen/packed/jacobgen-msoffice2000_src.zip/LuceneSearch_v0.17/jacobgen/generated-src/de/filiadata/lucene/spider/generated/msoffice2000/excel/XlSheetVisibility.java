/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSheetVisibility {

	public static final int xlSheetVisible = -1;
	public static final int xlSheetHidden = 0;
	public static final int xlSheetVeryHidden = 2;
}
