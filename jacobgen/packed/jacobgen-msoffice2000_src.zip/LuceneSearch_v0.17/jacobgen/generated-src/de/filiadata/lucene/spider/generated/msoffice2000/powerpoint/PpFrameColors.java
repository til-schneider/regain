/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpFrameColors {

	public static final int ppFrameColorsBrowserColors = 1;
	public static final int ppFrameColorsPresentationSchemeTextColor = 2;
	public static final int ppFrameColorsPresentationSchemeAccentColor = 3;
	public static final int ppFrameColorsWhiteTextOnBlack = 4;
	public static final int ppFrameColorsBlackTextOnWhite = 5;
}
