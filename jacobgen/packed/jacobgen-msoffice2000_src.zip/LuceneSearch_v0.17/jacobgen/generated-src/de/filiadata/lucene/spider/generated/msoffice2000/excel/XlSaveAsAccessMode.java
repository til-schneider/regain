/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSaveAsAccessMode {

	public static final int xlExclusive = 3;
	public static final int xlNoChange = 1;
	public static final int xlShared = 2;
}
