/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpPlaceholderType {

	public static final int ppPlaceholderMixed = -2;
	public static final int ppPlaceholderTitle = 1;
	public static final int ppPlaceholderBody = 2;
	public static final int ppPlaceholderCenterTitle = 3;
	public static final int ppPlaceholderSubtitle = 4;
	public static final int ppPlaceholderVerticalTitle = 5;
	public static final int ppPlaceholderVerticalBody = 6;
	public static final int ppPlaceholderObject = 7;
	public static final int ppPlaceholderChart = 8;
	public static final int ppPlaceholderBitmap = 9;
	public static final int ppPlaceholderMediaClip = 10;
	public static final int ppPlaceholderOrgChart = 11;
	public static final int ppPlaceholderTable = 12;
	public static final int ppPlaceholderSlideNumber = 13;
	public static final int ppPlaceholderHeader = 14;
	public static final int ppPlaceholderFooter = 15;
	public static final int ppPlaceholderDate = 16;
}
