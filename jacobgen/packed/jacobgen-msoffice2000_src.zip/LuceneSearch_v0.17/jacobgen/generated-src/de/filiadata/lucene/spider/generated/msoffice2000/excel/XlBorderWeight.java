/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlBorderWeight {

	public static final int xlHairline = 1;
	public static final int xlMedium = -4138;
	public static final int xlThick = 4;
	public static final int xlThin = 2;
}
