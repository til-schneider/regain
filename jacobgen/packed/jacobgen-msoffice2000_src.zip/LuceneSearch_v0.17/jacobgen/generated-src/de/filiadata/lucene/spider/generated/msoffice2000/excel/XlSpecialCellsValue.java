/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSpecialCellsValue {

	public static final int xlErrors = 16;
	public static final int xlLogical = 4;
	public static final int xlNumbers = 1;
	public static final int xlTextValues = 2;
}
