/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlArrowHeadStyle {

	public static final int xlArrowHeadStyleClosed = 3;
	public static final int xlArrowHeadStyleDoubleClosed = 5;
	public static final int xlArrowHeadStyleDoubleOpen = 4;
	public static final int xlArrowHeadStyleNone = -4142;
	public static final int xlArrowHeadStyleOpen = 2;
}
