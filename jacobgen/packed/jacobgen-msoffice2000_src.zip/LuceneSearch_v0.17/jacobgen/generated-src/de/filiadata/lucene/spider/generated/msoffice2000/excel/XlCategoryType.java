/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCategoryType {

	public static final int xlCategoryScale = 2;
	public static final int xlTimeScale = 3;
	public static final int xlAutomaticScale = -4105;
}
