/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface xlPivotFormatType {

	public static final int xlReport1 = 0;
	public static final int xlReport2 = 1;
	public static final int xlReport3 = 2;
	public static final int xlReport4 = 3;
	public static final int xlReport5 = 4;
	public static final int xlReport6 = 5;
	public static final int xlReport7 = 6;
	public static final int xlReport8 = 7;
	public static final int xlReport9 = 8;
	public static final int xlReport10 = 9;
	public static final int xlTable1 = 10;
	public static final int xlTable2 = 11;
	public static final int xlTable3 = 12;
	public static final int xlTable4 = 13;
	public static final int xlTable5 = 14;
	public static final int xlTable6 = 15;
	public static final int xlTable7 = 16;
	public static final int xlTable8 = 17;
	public static final int xlTable9 = 18;
	public static final int xlTable10 = 19;
	public static final int xlPTClassic = 20;
	public static final int xlPTNone = 21;
}
