/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlApplicationInternational {

	public static final int xl24HourClock = 33;
	public static final int xl4DigitYears = 43;
	public static final int xlAlternateArraySeparator = 16;
	public static final int xlColumnSeparator = 14;
	public static final int xlCountryCode = 1;
	public static final int xlCountrySetting = 2;
	public static final int xlCurrencyBefore = 37;
	public static final int xlCurrencyCode = 25;
	public static final int xlCurrencyDigits = 27;
	public static final int xlCurrencyLeadingZeros = 40;
	public static final int xlCurrencyMinusSign = 38;
	public static final int xlCurrencyNegative = 28;
	public static final int xlCurrencySpaceBefore = 36;
	public static final int xlCurrencyTrailingZeros = 39;
	public static final int xlDateOrder = 32;
	public static final int xlDateSeparator = 17;
	public static final int xlDayCode = 21;
	public static final int xlDayLeadingZero = 42;
	public static final int xlDecimalSeparator = 3;
	public static final int xlGeneralFormatName = 26;
	public static final int xlHourCode = 22;
	public static final int xlLeftBrace = 12;
	public static final int xlLeftBracket = 10;
	public static final int xlListSeparator = 5;
	public static final int xlLowerCaseColumnLetter = 9;
	public static final int xlLowerCaseRowLetter = 8;
	public static final int xlMDY = 44;
	public static final int xlMetric = 35;
	public static final int xlMinuteCode = 23;
	public static final int xlMonthCode = 20;
	public static final int xlMonthLeadingZero = 41;
	public static final int xlMonthNameChars = 30;
	public static final int xlNoncurrencyDigits = 29;
	public static final int xlNonEnglishFunctions = 34;
	public static final int xlRightBrace = 13;
	public static final int xlRightBracket = 11;
	public static final int xlRowSeparator = 15;
	public static final int xlSecondCode = 24;
	public static final int xlThousandsSeparator = 4;
	public static final int xlTimeLeadingZero = 45;
	public static final int xlTimeSeparator = 18;
	public static final int xlUpperCaseColumnLetter = 7;
	public static final int xlUpperCaseRowLetter = 6;
	public static final int xlWeekdayNameChars = 31;
	public static final int xlYearCode = 19;
}
