/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSummaryColumn {

	public static final int xlSummaryOnLeft = -4131;
	public static final int xlSummaryOnRight = -4152;
}
