/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Workbooks extends Dispatch {

	public static final String componentName = "Excel.Workbooks";

	public Workbooks() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Workbooks(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Workbooks(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook add(Variant lastParam) {
		return new Workbook(Dispatch.call(this, "Add", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook add() {
		return new Workbook(Dispatch.call(this, "Add").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void close() {
		Dispatch.call(this, "Close");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook getItem(Variant lastParam) {
		return new Workbook(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @param delimiter an input-parameter of type Variant
	 * @param editable an input-parameter of type Variant
	 * @param notify an input-parameter of type Variant
	 * @param converter an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin, Variant delimiter, Variant editable, Variant notify, Variant converter, Variant lastParam) {
		return new Workbook(Dispatch.callN(this, "Open", new Object[] { filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin, delimiter, editable, notify, converter, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @param delimiter an input-parameter of type Variant
	 * @param editable an input-parameter of type Variant
	 * @param notify an input-parameter of type Variant
	 * @param converter an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin, Variant delimiter, Variant editable, Variant notify, Variant converter) {
		return new Workbook(Dispatch.callN(this, "Open", new Object[] { filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin, delimiter, editable, notify, converter}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @param delimiter an input-parameter of type Variant
	 * @param editable an input-parameter of type Variant
	 * @param notify an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin, Variant delimiter, Variant editable, Variant notify) {
		return new Workbook(Dispatch.callN(this, "Open", new Object[] { filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin, delimiter, editable, notify}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @param delimiter an input-parameter of type Variant
	 * @param editable an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin, Variant delimiter, Variant editable) {
		return new Workbook(Dispatch.callN(this, "Open", new Object[] { filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin, delimiter, editable}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @param delimiter an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin, Variant delimiter) {
		return new Workbook(Dispatch.callN(this, "Open", new Object[] { filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin, delimiter}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @param origin an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended, Variant origin) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended, origin).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param ignoreReadOnlyRecommended an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword, Variant ignoreReadOnlyRecommended) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly, format, password, writeResPassword, ignoreReadOnlyRecommended).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password, Variant writeResPassword) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly, format, password, writeResPassword).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format, Variant password) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly, format, password).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly, Variant format) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly, format).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @param readOnly an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks, Variant readOnly) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks, readOnly).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param updateLinks an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename, Variant updateLinks) {
		return new Workbook(Dispatch.call(this, "Open", filename, updateLinks).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @return the result is of type Workbook
	 */
	public Workbook open(String filename) {
		return new Workbook(Dispatch.call(this, "Open", filename).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant lastParam) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma) {
		Dispatch.callN(this, "_OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow, dataType, new Variant(textQualifier));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow, Variant dataType) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow, dataType);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin, Variant startRow) {
		Dispatch.call(this, "_OpenText", filename, origin, startRow);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 */
	public void _OpenText(String filename, Variant origin) {
		Dispatch.call(this, "_OpenText", filename, origin);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 */
	public void _OpenText(String filename) {
		Dispatch.call(this, "_OpenText", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Workbook
	 */
	public Workbook get_Default(Variant lastParam) {
		return new Workbook(Dispatch.call(this, "_Default", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param textVisualLayout an input-parameter of type Variant
	 * @param decimalSeparator an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant textVisualLayout, Variant decimalSeparator, Variant lastParam) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, textVisualLayout, decimalSeparator, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param textVisualLayout an input-parameter of type Variant
	 * @param decimalSeparator an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant textVisualLayout, Variant decimalSeparator) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, textVisualLayout, decimalSeparator});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param textVisualLayout an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant textVisualLayout) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, textVisualLayout});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma) {
		Dispatch.callN(this, "OpenText", new Object[] { filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon) {
		Dispatch.call(this, "OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab, semicolon);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab) {
		Dispatch.call(this, "OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter, tab);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier, Variant consecutiveDelimiter) {
		Dispatch.call(this, "OpenText", filename, origin, startRow, dataType, new Variant(textQualifier), consecutiveDelimiter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 * @param textQualifier an input-parameter of type int
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType, int textQualifier) {
		Dispatch.call(this, "OpenText", filename, origin, startRow, dataType, new Variant(textQualifier));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 * @param dataType an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow, Variant dataType) {
		Dispatch.call(this, "OpenText", filename, origin, startRow, dataType);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 * @param startRow an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin, Variant startRow) {
		Dispatch.call(this, "OpenText", filename, origin, startRow);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param origin an input-parameter of type Variant
	 */
	public void openText(String filename, Variant origin) {
		Dispatch.call(this, "OpenText", filename, origin);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 */
	public void openText(String filename) {
		Dispatch.call(this, "OpenText", filename);
	}

}
