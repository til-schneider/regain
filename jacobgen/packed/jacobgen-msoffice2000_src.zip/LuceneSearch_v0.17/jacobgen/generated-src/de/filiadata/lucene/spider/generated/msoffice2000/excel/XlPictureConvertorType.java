/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPictureConvertorType {

	public static final int xlBMP = 1;
	public static final int xlCGM = 7;
	public static final int xlDRW = 4;
	public static final int xlDXF = 5;
	public static final int xlEPS = 8;
	public static final int xlHGL = 6;
	public static final int xlPCT = 13;
	public static final int xlPCX = 10;
	public static final int xlPIC = 11;
	public static final int xlPLT = 12;
	public static final int xlTIF = 9;
	public static final int xlWMF = 2;
	public static final int xlWPG = 3;
}
