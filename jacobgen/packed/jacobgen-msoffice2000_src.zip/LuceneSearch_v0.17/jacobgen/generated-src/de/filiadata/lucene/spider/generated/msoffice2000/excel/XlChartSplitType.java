/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlChartSplitType {

	public static final int xlSplitByPosition = 1;
	public static final int xlSplitByPercentValue = 3;
	public static final int xlSplitByCustomSplit = 4;
	public static final int xlSplitByValue = 2;
}
