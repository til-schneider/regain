/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlTickLabelOrientation {

	public static final int xlTickLabelOrientationAutomatic = -4105;
	public static final int xlTickLabelOrientationDownward = -4170;
	public static final int xlTickLabelOrientationHorizontal = -4128;
	public static final int xlTickLabelOrientationUpward = -4171;
	public static final int xlTickLabelOrientationVertical = -4166;
}
