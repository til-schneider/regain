/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlErrorBarType {

	public static final int xlErrorBarTypeCustom = -4114;
	public static final int xlErrorBarTypeFixedValue = 1;
	public static final int xlErrorBarTypePercent = 2;
	public static final int xlErrorBarTypeStDev = -4155;
	public static final int xlErrorBarTypeStError = 4;
}
