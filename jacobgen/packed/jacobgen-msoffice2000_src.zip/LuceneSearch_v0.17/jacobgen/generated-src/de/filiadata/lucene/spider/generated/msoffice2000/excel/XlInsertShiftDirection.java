/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlInsertShiftDirection {

	public static final int xlShiftDown = -4121;
	public static final int xlShiftToRight = -4161;
}
