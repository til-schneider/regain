/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlTextQualifier {

	public static final int xlTextQualifierDoubleQuote = 1;
	public static final int xlTextQualifierNone = -4142;
	public static final int xlTextQualifierSingleQuote = 2;
}
