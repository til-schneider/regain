/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPaperSize {

	public static final int xlPaper10x14 = 16;
	public static final int xlPaper11x17 = 17;
	public static final int xlPaperA3 = 8;
	public static final int xlPaperA4 = 9;
	public static final int xlPaperA4Small = 10;
	public static final int xlPaperA5 = 11;
	public static final int xlPaperB4 = 12;
	public static final int xlPaperB5 = 13;
	public static final int xlPaperCsheet = 24;
	public static final int xlPaperDsheet = 25;
	public static final int xlPaperEnvelope10 = 20;
	public static final int xlPaperEnvelope11 = 21;
	public static final int xlPaperEnvelope12 = 22;
	public static final int xlPaperEnvelope14 = 23;
	public static final int xlPaperEnvelope9 = 19;
	public static final int xlPaperEnvelopeB4 = 33;
	public static final int xlPaperEnvelopeB5 = 34;
	public static final int xlPaperEnvelopeB6 = 35;
	public static final int xlPaperEnvelopeC3 = 29;
	public static final int xlPaperEnvelopeC4 = 30;
	public static final int xlPaperEnvelopeC5 = 28;
	public static final int xlPaperEnvelopeC6 = 31;
	public static final int xlPaperEnvelopeC65 = 32;
	public static final int xlPaperEnvelopeDL = 27;
	public static final int xlPaperEnvelopeItaly = 36;
	public static final int xlPaperEnvelopeMonarch = 37;
	public static final int xlPaperEnvelopePersonal = 38;
	public static final int xlPaperEsheet = 26;
	public static final int xlPaperExecutive = 7;
	public static final int xlPaperFanfoldLegalGerman = 41;
	public static final int xlPaperFanfoldStdGerman = 40;
	public static final int xlPaperFanfoldUS = 39;
	public static final int xlPaperFolio = 14;
	public static final int xlPaperLedger = 4;
	public static final int xlPaperLegal = 5;
	public static final int xlPaperLetter = 1;
	public static final int xlPaperLetterSmall = 2;
	public static final int xlPaperNote = 18;
	public static final int xlPaperQuarto = 15;
	public static final int xlPaperStatement = 6;
	public static final int xlPaperTabloid = 3;
	public static final int xlPaperUser = 256;
}
