/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPivotFieldOrientation {

	public static final int xlColumnField = 2;
	public static final int xlDataField = 4;
	public static final int xlHidden = 0;
	public static final int xlPageField = 3;
	public static final int xlRowField = 1;
}
