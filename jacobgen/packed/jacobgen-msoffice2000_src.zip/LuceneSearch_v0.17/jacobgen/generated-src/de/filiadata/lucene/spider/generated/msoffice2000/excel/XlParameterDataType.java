/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlParameterDataType {

	public static final int xlParamTypeUnknown = 0;
	public static final int xlParamTypeChar = 1;
	public static final int xlParamTypeNumeric = 2;
	public static final int xlParamTypeDecimal = 3;
	public static final int xlParamTypeInteger = 4;
	public static final int xlParamTypeSmallInt = 5;
	public static final int xlParamTypeFloat = 6;
	public static final int xlParamTypeReal = 7;
	public static final int xlParamTypeDouble = 8;
	public static final int xlParamTypeVarChar = 12;
	public static final int xlParamTypeDate = 9;
	public static final int xlParamTypeTime = 10;
	public static final int xlParamTypeTimestamp = 11;
	public static final int xlParamTypeLongVarChar = -1;
	public static final int xlParamTypeBinary = -2;
	public static final int xlParamTypeVarBinary = -3;
	public static final int xlParamTypeLongVarBinary = -4;
	public static final int xlParamTypeBigInt = -5;
	public static final int xlParamTypeTinyInt = -6;
	public static final int xlParamTypeBit = -7;
	public static final int xlParamTypeWChar = -8;
}
