/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Validation extends Dispatch {

	public static final String componentName = "Excel.Validation";

	public Validation() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Validation(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Validation(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void add(int type, Variant alertStyle, Variant operator, Variant formula1, Variant lastParam) {
		Dispatch.call(this, "Add", new Variant(type), alertStyle, operator, formula1, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 */
	public void add(int type, Variant alertStyle, Variant operator, Variant formula1) {
		Dispatch.call(this, "Add", new Variant(type), alertStyle, operator, formula1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 */
	public void add(int type, Variant alertStyle, Variant operator) {
		Dispatch.call(this, "Add", new Variant(type), alertStyle, operator);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param alertStyle an input-parameter of type Variant
	 */
	public void add(int type, Variant alertStyle) {
		Dispatch.call(this, "Add", new Variant(type), alertStyle);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 */
	public void add(int type) {
		Dispatch.call(this, "Add", new Variant(type));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getAlertStyle() {
		return Dispatch.get(this, "AlertStyle").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getIgnoreBlank() {
		return Dispatch.get(this, "IgnoreBlank").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setIgnoreBlank(boolean lastParam) {
		Dispatch.call(this, "IgnoreBlank", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIMEMode() {
		return Dispatch.get(this, "IMEMode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setIMEMode(int lastParam) {
		Dispatch.call(this, "IMEMode", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getInCellDropdown() {
		return Dispatch.get(this, "InCellDropdown").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setInCellDropdown(boolean lastParam) {
		Dispatch.call(this, "InCellDropdown", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getErrorMessage() {
		return Dispatch.get(this, "ErrorMessage").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setErrorMessage(String lastParam) {
		Dispatch.call(this, "ErrorMessage", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getErrorTitle() {
		return Dispatch.get(this, "ErrorTitle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setErrorTitle(String lastParam) {
		Dispatch.call(this, "ErrorTitle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getInputMessage() {
		return Dispatch.get(this, "InputMessage").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setInputMessage(String lastParam) {
		Dispatch.call(this, "InputMessage", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getInputTitle() {
		return Dispatch.get(this, "InputTitle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setInputTitle(String lastParam) {
		Dispatch.call(this, "InputTitle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getFormula1() {
		return Dispatch.get(this, "Formula1").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getFormula2() {
		return Dispatch.get(this, "Formula2").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void modify(Variant type, Variant alertStyle, Variant operator, Variant formula1, Variant lastParam) {
		Dispatch.call(this, "Modify", type, alertStyle, operator, formula1, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 */
	public void modify(Variant type, Variant alertStyle, Variant operator, Variant formula1) {
		Dispatch.call(this, "Modify", type, alertStyle, operator, formula1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @param alertStyle an input-parameter of type Variant
	 * @param operator an input-parameter of type Variant
	 */
	public void modify(Variant type, Variant alertStyle, Variant operator) {
		Dispatch.call(this, "Modify", type, alertStyle, operator);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @param alertStyle an input-parameter of type Variant
	 */
	public void modify(Variant type, Variant alertStyle) {
		Dispatch.call(this, "Modify", type, alertStyle);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 */
	public void modify(Variant type) {
		Dispatch.call(this, "Modify", type);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void modify() {
		Dispatch.call(this, "Modify");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getOperator() {
		return Dispatch.get(this, "Operator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowError() {
		return Dispatch.get(this, "ShowError").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowError(boolean lastParam) {
		Dispatch.call(this, "ShowError", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowInput() {
		return Dispatch.get(this, "ShowInput").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowInput(boolean lastParam) {
		Dispatch.call(this, "ShowInput", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getType() {
		return Dispatch.get(this, "Type").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getValue() {
		return Dispatch.get(this, "Value").toBoolean();
	}

}
