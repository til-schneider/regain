/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpChangeCase {

	public static final int ppCaseSentence = 1;
	public static final int ppCaseLower = 2;
	public static final int ppCaseUpper = 3;
	public static final int ppCaseTitle = 4;
	public static final int ppCaseToggle = 5;
}
