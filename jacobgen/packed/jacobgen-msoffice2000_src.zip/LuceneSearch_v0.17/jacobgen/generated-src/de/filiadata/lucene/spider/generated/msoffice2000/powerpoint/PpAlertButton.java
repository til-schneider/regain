/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpAlertButton {

	public static final int ppAlertButtonCLOSE = 0;
	public static final int ppAlertButtonSNOOZE = 1;
	public static final int ppAlertButtonSEARCH = 2;
	public static final int ppAlertButtonIGNORE = 3;
	public static final int ppAlertButtonABORT = 4;
	public static final int ppAlertButtonRETRY = 5;
	public static final int ppAlertButtonNEXT = 6;
	public static final int ppAlertButtonBACK = 7;
	public static final int ppAlertButtonNO = 8;
	public static final int ppAlertButtonYES = 9;
	public static final int ppAlertButtonCANCEL = 10;
	public static final int ppAlertButtonOK = 11;
	public static final int ppAlertButtonNULL = 12;
}
