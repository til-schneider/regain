/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCellType {

	public static final int xlCellTypeBlanks = 4;
	public static final int xlCellTypeConstants = 2;
	public static final int xlCellTypeFormulas = -4123;
	public static final int xlCellTypeLastCell = 11;
	public static final int xlCellTypeComments = -4144;
	public static final int xlCellTypeVisible = 12;
	public static final int xlCellTypeAllFormatConditions = -4172;
	public static final int xlCellTypeSameFormatConditions = -4173;
	public static final int xlCellTypeAllValidation = -4174;
	public static final int xlCellTypeSameValidation = -4175;
}
