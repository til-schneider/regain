/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlRoutingSlipStatus {

	public static final int xlNotYetRouted = 0;
	public static final int xlRoutingComplete = 2;
	public static final int xlRoutingInProgress = 1;
}
