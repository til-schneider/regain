/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class PivotTables extends Dispatch {

	public static final String componentName = "Excel.PivotTables";

	public PivotTables() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PivotTables(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PivotTables(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable item(Variant lastParam) {
		return new PivotTable(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _NewEnum() {
		return Dispatch.call(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param pivotCache an input-parameter of type PivotCache
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable add(PivotCache pivotCache, Variant tableDestination, Variant tableName, Variant lastParam) {
		return new PivotTable(Dispatch.call(this, "Add", pivotCache, tableDestination, tableName, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param pivotCache an input-parameter of type PivotCache
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable add(PivotCache pivotCache, Variant tableDestination, Variant tableName) {
		return new PivotTable(Dispatch.call(this, "Add", pivotCache, tableDestination, tableName).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param pivotCache an input-parameter of type PivotCache
	 * @param tableDestination an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable add(PivotCache pivotCache, Variant tableDestination) {
		return new PivotTable(Dispatch.call(this, "Add", pivotCache, tableDestination).toDispatch());
	}

}
