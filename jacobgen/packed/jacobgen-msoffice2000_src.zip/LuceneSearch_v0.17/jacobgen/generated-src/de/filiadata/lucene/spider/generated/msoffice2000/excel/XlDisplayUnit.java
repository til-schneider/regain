/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDisplayUnit {

	public static final int xlHundreds = -2;
	public static final int xlThousands = -3;
	public static final int xlTenThousands = -4;
	public static final int xlHundredThousands = -5;
	public static final int xlMillions = -6;
	public static final int xlTenMillions = -7;
	public static final int xlHundredMillions = -8;
	public static final int xlThousandMillions = -9;
	public static final int xlMillionMillions = -10;
}
