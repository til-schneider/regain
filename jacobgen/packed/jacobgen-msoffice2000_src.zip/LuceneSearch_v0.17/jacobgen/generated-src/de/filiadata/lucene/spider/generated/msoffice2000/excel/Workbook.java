/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Workbook extends _Workbook {

	public static final String componentName = "Excel.Workbook";

	public Workbook() {
		super(componentName);
	}

	public Workbook(Dispatch d) {
		super(d);
	}
}
