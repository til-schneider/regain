/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlClipboardFormat {

	public static final int xlClipboardFormatBIFF = 8;
	public static final int xlClipboardFormatBIFF2 = 18;
	public static final int xlClipboardFormatBIFF3 = 20;
	public static final int xlClipboardFormatBIFF4 = 30;
	public static final int xlClipboardFormatBinary = 15;
	public static final int xlClipboardFormatBitmap = 9;
	public static final int xlClipboardFormatCGM = 13;
	public static final int xlClipboardFormatCSV = 5;
	public static final int xlClipboardFormatDIF = 4;
	public static final int xlClipboardFormatDspText = 12;
	public static final int xlClipboardFormatEmbeddedObject = 21;
	public static final int xlClipboardFormatEmbedSource = 22;
	public static final int xlClipboardFormatLink = 11;
	public static final int xlClipboardFormatLinkSource = 23;
	public static final int xlClipboardFormatLinkSourceDesc = 32;
	public static final int xlClipboardFormatMovie = 24;
	public static final int xlClipboardFormatNative = 14;
	public static final int xlClipboardFormatObjectDesc = 31;
	public static final int xlClipboardFormatObjectLink = 19;
	public static final int xlClipboardFormatOwnerLink = 17;
	public static final int xlClipboardFormatPICT = 2;
	public static final int xlClipboardFormatPrintPICT = 3;
	public static final int xlClipboardFormatRTF = 7;
	public static final int xlClipboardFormatScreenPICT = 29;
	public static final int xlClipboardFormatStandardFont = 28;
	public static final int xlClipboardFormatStandardScale = 27;
	public static final int xlClipboardFormatSYLK = 6;
	public static final int xlClipboardFormatTable = 16;
	public static final int xlClipboardFormatText = 0;
	public static final int xlClipboardFormatToolFace = 25;
	public static final int xlClipboardFormatToolFacePICT = 26;
	public static final int xlClipboardFormatVALU = 1;
	public static final int xlClipboardFormatWK1 = 10;
}
