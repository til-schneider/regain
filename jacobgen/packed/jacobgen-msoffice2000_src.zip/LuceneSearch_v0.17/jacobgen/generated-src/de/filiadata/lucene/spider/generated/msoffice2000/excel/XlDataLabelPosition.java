/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDataLabelPosition {

	public static final int xlLabelPositionCenter = -4108;
	public static final int xlLabelPositionAbove = 0;
	public static final int xlLabelPositionBelow = 1;
	public static final int xlLabelPositionLeft = -4131;
	public static final int xlLabelPositionRight = -4152;
	public static final int xlLabelPositionOutsideEnd = 2;
	public static final int xlLabelPositionInsideEnd = 3;
	public static final int xlLabelPositionInsideBase = 4;
	public static final int xlLabelPositionBestFit = 5;
	public static final int xlLabelPositionMixed = 6;
	public static final int xlLabelPositionCustom = 7;
}
