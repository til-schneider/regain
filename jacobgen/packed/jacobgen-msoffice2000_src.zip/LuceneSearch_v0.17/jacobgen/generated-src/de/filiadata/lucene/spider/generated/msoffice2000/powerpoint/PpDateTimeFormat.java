/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpDateTimeFormat {

	public static final int ppDateTimeFormatMixed = -2;
	public static final int ppDateTimeMdyy = 1;
	public static final int ppDateTimeddddMMMMddyyyy = 2;
	public static final int ppDateTimedMMMMyyyy = 3;
	public static final int ppDateTimeMMMMdyyyy = 4;
	public static final int ppDateTimedMMMyy = 5;
	public static final int ppDateTimeMMMMyy = 6;
	public static final int ppDateTimeMMyy = 7;
	public static final int ppDateTimeMMddyyHmm = 8;
	public static final int ppDateTimeMMddyyhmmAMPM = 9;
	public static final int ppDateTimeHmm = 10;
	public static final int ppDateTimeHmmss = 11;
	public static final int ppDateTimehmmAMPM = 12;
	public static final int ppDateTimehmmssAMPM = 13;
}
