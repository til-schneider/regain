/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlSourceType {

	public static final int xlSourceSheet = 1;
	public static final int xlSourcePrintArea = 2;
	public static final int xlSourceAutoFilter = 3;
	public static final int xlSourceRange = 4;
	public static final int xlSourceChart = 5;
	public static final int xlSourcePivotTable = 6;
	public static final int xlSourceQuery = 7;
}
