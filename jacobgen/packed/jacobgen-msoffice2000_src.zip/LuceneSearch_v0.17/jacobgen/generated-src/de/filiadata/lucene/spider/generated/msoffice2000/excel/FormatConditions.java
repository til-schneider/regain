/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class FormatConditions extends Dispatch {

	public static final String componentName = "Excel.FormatConditions";

	public FormatConditions() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public FormatConditions(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public FormatConditions(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition item(Variant lastParam) {
		return new FormatCondition(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition add(int type, Variant operator, Variant formula1, Variant lastParam) {
		return new FormatCondition(Dispatch.call(this, "Add", new Variant(type), operator, formula1, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param operator an input-parameter of type Variant
	 * @param formula1 an input-parameter of type Variant
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition add(int type, Variant operator, Variant formula1) {
		return new FormatCondition(Dispatch.call(this, "Add", new Variant(type), operator, formula1).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param operator an input-parameter of type Variant
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition add(int type, Variant operator) {
		return new FormatCondition(Dispatch.call(this, "Add", new Variant(type), operator).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition add(int type) {
		return new FormatCondition(Dispatch.call(this, "Add", new Variant(type)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type FormatCondition
	 */
	public FormatCondition get_Default(Variant lastParam) {
		return new FormatCondition(Dispatch.call(this, "_Default", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

}
