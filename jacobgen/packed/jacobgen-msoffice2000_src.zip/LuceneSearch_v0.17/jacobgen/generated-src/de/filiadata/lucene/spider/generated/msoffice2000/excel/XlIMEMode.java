/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlIMEMode {

	public static final int xlIMEModeNoControl = 0;
	public static final int xlIMEModeOn = 1;
	public static final int xlIMEModeOff = 2;
	public static final int xlIMEModeDisable = 3;
	public static final int xlIMEModeHiragana = 4;
	public static final int xlIMEModeKatakana = 5;
	public static final int xlIMEModeKatakanaHalf = 6;
	public static final int xlIMEModeAlphaFull = 7;
	public static final int xlIMEModeAlpha = 8;
	public static final int xlIMEModeHangulFull = 9;
	public static final int xlIMEModeHangul = 10;
}
