/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpPrintOutputType {

	public static final int ppPrintOutputSlides = 1;
	public static final int ppPrintOutputTwoSlideHandouts = 2;
	public static final int ppPrintOutputThreeSlideHandouts = 3;
	public static final int ppPrintOutputSixSlideHandouts = 4;
	public static final int ppPrintOutputNotesPages = 5;
	public static final int ppPrintOutputOutline = 6;
	public static final int ppPrintOutputBuildSlides = 7;
	public static final int ppPrintOutputFourSlideHandouts = 8;
	public static final int ppPrintOutputNineSlideHandouts = 9;
}
