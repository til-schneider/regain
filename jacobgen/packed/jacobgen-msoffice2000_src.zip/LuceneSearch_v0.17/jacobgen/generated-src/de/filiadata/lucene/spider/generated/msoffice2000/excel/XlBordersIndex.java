/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlBordersIndex {

	public static final int xlInsideHorizontal = 12;
	public static final int xlInsideVertical = 11;
	public static final int xlDiagonalDown = 5;
	public static final int xlDiagonalUp = 6;
	public static final int xlEdgeBottom = 9;
	public static final int xlEdgeLeft = 7;
	public static final int xlEdgeRight = 10;
	public static final int xlEdgeTop = 8;
}
