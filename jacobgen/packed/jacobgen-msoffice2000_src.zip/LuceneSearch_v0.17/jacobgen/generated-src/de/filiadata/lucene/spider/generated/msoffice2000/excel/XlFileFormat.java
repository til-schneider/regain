/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFileFormat {

	public static final int xlAddIn = 18;
	public static final int xlCSV = 6;
	public static final int xlCSVMac = 22;
	public static final int xlCSVMSDOS = 24;
	public static final int xlCSVWindows = 23;
	public static final int xlDBF2 = 7;
	public static final int xlDBF3 = 8;
	public static final int xlDBF4 = 11;
	public static final int xlDIF = 9;
	public static final int xlExcel2 = 16;
	public static final int xlExcel2FarEast = 27;
	public static final int xlExcel3 = 29;
	public static final int xlExcel4 = 33;
	public static final int xlExcel5 = 39;
	public static final int xlExcel7 = 39;
	public static final int xlExcel9795 = 43;
	public static final int xlExcel4Workbook = 35;
	public static final int xlIntlAddIn = 26;
	public static final int xlIntlMacro = 25;
	public static final int xlWorkbookNormal = -4143;
	public static final int xlSYLK = 2;
	public static final int xlTemplate = 17;
	public static final int xlCurrentPlatformText = -4158;
	public static final int xlTextMac = 19;
	public static final int xlTextMSDOS = 21;
	public static final int xlTextPrinter = 36;
	public static final int xlTextWindows = 20;
	public static final int xlWJ2WD1 = 14;
	public static final int xlWK1 = 5;
	public static final int xlWK1ALL = 31;
	public static final int xlWK1FMT = 30;
	public static final int xlWK3 = 15;
	public static final int xlWK4 = 38;
	public static final int xlWK3FM3 = 32;
	public static final int xlWKS = 4;
	public static final int xlWorks2FarEast = 28;
	public static final int xlWQ1 = 34;
	public static final int xlWJ3 = 40;
	public static final int xlWJ3FJ3 = 41;
	public static final int xlUnicodeText = 42;
	public static final int xlHtml = 44;
}
