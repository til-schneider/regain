/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _Global extends Dispatch {

	public static final String componentName = "Excel._Global";

	public _Global() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _Global(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _Global(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getParent() {
		return new Application(Dispatch.get(this, "Parent").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getActiveCell() {
		return new Range(Dispatch.get(this, "ActiveCell").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Chart
	 */
	public Chart getActiveChart() {
		return new Chart(Dispatch.get(this, "ActiveChart").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type DialogSheet
	 */
	public DialogSheet getActiveDialog() {
		return new DialogSheet(Dispatch.get(this, "ActiveDialog").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type MenuBar
	 */
	public MenuBar getActiveMenuBar() {
		return new MenuBar(Dispatch.get(this, "ActiveMenuBar").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getActivePrinter() {
		return Dispatch.get(this, "ActivePrinter").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setActivePrinter(String lastParam) {
		Dispatch.call(this, "ActivePrinter", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getActiveSheet() {
		return Dispatch.get(this, "ActiveSheet");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Window
	 */
	public Window getActiveWindow() {
		return new Window(Dispatch.get(this, "ActiveWindow").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook getActiveWorkbook() {
		return new Workbook(Dispatch.get(this, "ActiveWorkbook").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type AddIns
	 */
	public AddIns getAddIns() {
		return new AddIns(Dispatch.get(this, "AddIns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.Assistant
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.Assistant getAssistant() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.Assistant(Dispatch.get(this, "Assistant").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculate() {
		Dispatch.call(this, "Calculate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCells() {
		return new Range(Dispatch.get(this, "Cells").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getCharts() {
		return new Sheets(Dispatch.get(this, "Charts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getColumns() {
		return new Range(Dispatch.get(this, "Columns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.CommandBars
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.CommandBars getCommandBars() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.CommandBars(Dispatch.get(this, "CommandBars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDDEAppReturnCode() {
		return Dispatch.get(this, "DDEAppReturnCode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param lastParam an input-parameter of type String
	 */
	public void dDEExecute(int channel, String lastParam) {
		Dispatch.call(this, "DDEExecute", new Variant(channel), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param app an input-parameter of type String
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type int
	 */
	public int dDEInitiate(String app, String lastParam) {
		return Dispatch.call(this, "DDEInitiate", app, lastParam).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param item an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void dDEPoke(int channel, Variant item, Variant lastParam) {
		Dispatch.call(this, "DDEPoke", new Variant(channel), item, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant dDERequest(int channel, String lastParam) {
		return Dispatch.call(this, "DDERequest", new Variant(channel), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void dDETerminate(int lastParam) {
		Dispatch.call(this, "DDETerminate", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getDialogSheets() {
		return new Sheets(Dispatch.get(this, "DialogSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant evaluate(Variant lastParam) {
		return Dispatch.call(this, "Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Evaluate(Variant lastParam) {
		return Dispatch.call(this, "_Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant executeExcel4Macro(String lastParam) {
		return Dispatch.call(this, "ExecuteExcel4Macro", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6, arg7).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type MenuBars
	 */
	public MenuBars getMenuBars() {
		return new MenuBars(Dispatch.get(this, "MenuBars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Modules
	 */
	public Modules getModules() {
		return new Modules(Dispatch.get(this, "Modules").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Names
	 */
	public Names getNames() {
		return new Names(Dispatch.get(this, "Names").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1, Variant lastParam) {
		return new Range(Dispatch.call(this, "Range", cell1, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1) {
		return new Range(Dispatch.call(this, "Range", cell1).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getRows() {
		return new Range(Dispatch.get(this, "Rows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2) {
		return Dispatch.call(this, "Run", macro, arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1) {
		return Dispatch.call(this, "Run", macro, arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro) {
		return Dispatch.call(this, "Run", macro);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant run() {
		return Dispatch.call(this, "Run");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1) {
		return Dispatch.call(this, "_Run2", macro, arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro) {
		return Dispatch.call(this, "_Run2", macro);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _Run2() {
		return Dispatch.call(this, "_Run2");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getSelection() {
		return Dispatch.get(this, "Selection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param keys an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void sendKeys(Variant keys, Variant lastParam) {
		Dispatch.call(this, "SendKeys", keys, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param keys an input-parameter of type Variant
	 */
	public void sendKeys(Variant keys) {
		Dispatch.call(this, "SendKeys", keys);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getSheets() {
		return new Sheets(Dispatch.get(this, "Sheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Menu
	 */
	public Menu getShortcutMenus(int lastParam) {
		return new Menu(Dispatch.call(this, "ShortcutMenus", new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook getThisWorkbook() {
		return new Workbook(Dispatch.get(this, "ThisWorkbook").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Toolbars
	 */
	public Toolbars getToolbars() {
		return new Toolbars(Dispatch.get(this, "Toolbars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6, arg7).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Windows
	 */
	public Windows getWindows() {
		return new Windows(Dispatch.get(this, "Windows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbooks
	 */
	public Workbooks getWorkbooks() {
		return new Workbooks(Dispatch.get(this, "Workbooks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type WorksheetFunction
	 */
	public WorksheetFunction getWorksheetFunction() {
		return new WorksheetFunction(Dispatch.get(this, "WorksheetFunction").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getWorksheets() {
		return new Sheets(Dispatch.get(this, "Worksheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4IntlMacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4IntlMacroSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4MacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4MacroSheets").toDispatch());
	}

}
