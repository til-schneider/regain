/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFormatConditionType {

	public static final int xlCellValue = 1;
	public static final int xlExpression = 2;
}
