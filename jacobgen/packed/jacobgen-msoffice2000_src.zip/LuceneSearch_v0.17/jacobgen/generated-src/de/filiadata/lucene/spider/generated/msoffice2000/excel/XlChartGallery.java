/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlChartGallery {

	public static final int xlBuiltIn = 21;
	public static final int xlUserDefined = 22;
	public static final int xlAnyGallery = 23;
}
