/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpPrintRangeType {

	public static final int ppPrintAll = 1;
	public static final int ppPrintSelection = 2;
	public static final int ppPrintCurrent = 3;
	public static final int ppPrintSlideRange = 4;
	public static final int ppPrintNamedSlideShow = 5;
}
