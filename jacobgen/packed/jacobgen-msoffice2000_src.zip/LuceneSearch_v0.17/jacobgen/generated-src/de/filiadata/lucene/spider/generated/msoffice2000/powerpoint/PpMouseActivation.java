/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpMouseActivation {

	public static final int ppMouseClick = 1;
	public static final int ppMouseOver = 2;
}
