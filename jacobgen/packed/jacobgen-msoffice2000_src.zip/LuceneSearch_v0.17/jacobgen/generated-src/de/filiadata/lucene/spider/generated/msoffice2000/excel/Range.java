/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Range extends Dispatch {

	public static final String componentName = "Excel.Range";

	public Range() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Range(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Range(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant activate() {
		return Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getAddIndent() {
		return Dispatch.get(this, "AddIndent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setAddIndent(Variant lastParam) {
		Dispatch.call(this, "AddIndent", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @param external an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddress(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle, Variant external, Variant lastParam) {
		return Dispatch.call(this, "Address", rowAbsolute, columnAbsolute, new Variant(referenceStyle), external, lastParam).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @param external an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddress(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle, Variant external) {
		return Dispatch.call(this, "Address", rowAbsolute, columnAbsolute, new Variant(referenceStyle), external).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @return the result is of type String
	 */
	public String getAddress(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle) {
		return Dispatch.call(this, "Address", rowAbsolute, columnAbsolute, new Variant(referenceStyle)).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddress(Variant rowAbsolute, Variant columnAbsolute) {
		return Dispatch.call(this, "Address", rowAbsolute, columnAbsolute).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddress(Variant rowAbsolute) {
		return Dispatch.call(this, "Address", rowAbsolute).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getAddress() {
		return Dispatch.get(this, "Address").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @param external an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddressLocal(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle, Variant external, Variant lastParam) {
		return Dispatch.call(this, "AddressLocal", rowAbsolute, columnAbsolute, new Variant(referenceStyle), external, lastParam).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @param external an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddressLocal(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle, Variant external) {
		return Dispatch.call(this, "AddressLocal", rowAbsolute, columnAbsolute, new Variant(referenceStyle), external).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @param referenceStyle an input-parameter of type int
	 * @return the result is of type String
	 */
	public String getAddressLocal(Variant rowAbsolute, Variant columnAbsolute, int referenceStyle) {
		return Dispatch.call(this, "AddressLocal", rowAbsolute, columnAbsolute, new Variant(referenceStyle)).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @param columnAbsolute an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddressLocal(Variant rowAbsolute, Variant columnAbsolute) {
		return Dispatch.call(this, "AddressLocal", rowAbsolute, columnAbsolute).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowAbsolute an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getAddressLocal(Variant rowAbsolute) {
		return Dispatch.call(this, "AddressLocal", rowAbsolute).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getAddressLocal() {
		return Dispatch.get(this, "AddressLocal").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param action an input-parameter of type int
	 * @param criteriaRange an input-parameter of type Variant
	 * @param copyToRange an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant advancedFilter(int action, Variant criteriaRange, Variant copyToRange, Variant lastParam) {
		return Dispatch.call(this, "AdvancedFilter", new Variant(action), criteriaRange, copyToRange, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param action an input-parameter of type int
	 * @param criteriaRange an input-parameter of type Variant
	 * @param copyToRange an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant advancedFilter(int action, Variant criteriaRange, Variant copyToRange) {
		return Dispatch.call(this, "AdvancedFilter", new Variant(action), criteriaRange, copyToRange);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param action an input-parameter of type int
	 * @param criteriaRange an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant advancedFilter(int action, Variant criteriaRange) {
		return Dispatch.call(this, "AdvancedFilter", new Variant(action), criteriaRange);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param action an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant advancedFilter(int action) {
		return Dispatch.call(this, "AdvancedFilter", new Variant(action));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @param useRowColumnNames an input-parameter of type Variant
	 * @param omitColumn an input-parameter of type Variant
	 * @param omitRow an input-parameter of type Variant
	 * @param order an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute, Variant useRowColumnNames, Variant omitColumn, Variant omitRow, int order, Variant lastParam) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute, useRowColumnNames, omitColumn, omitRow, new Variant(order), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @param useRowColumnNames an input-parameter of type Variant
	 * @param omitColumn an input-parameter of type Variant
	 * @param omitRow an input-parameter of type Variant
	 * @param order an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute, Variant useRowColumnNames, Variant omitColumn, Variant omitRow, int order) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute, useRowColumnNames, omitColumn, omitRow, new Variant(order));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @param useRowColumnNames an input-parameter of type Variant
	 * @param omitColumn an input-parameter of type Variant
	 * @param omitRow an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute, Variant useRowColumnNames, Variant omitColumn, Variant omitRow) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute, useRowColumnNames, omitColumn, omitRow);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @param useRowColumnNames an input-parameter of type Variant
	 * @param omitColumn an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute, Variant useRowColumnNames, Variant omitColumn) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute, useRowColumnNames, omitColumn);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @param useRowColumnNames an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute, Variant useRowColumnNames) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute, useRowColumnNames);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @param ignoreRelativeAbsolute an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names, Variant ignoreRelativeAbsolute) {
		return Dispatch.call(this, "ApplyNames", names, ignoreRelativeAbsolute);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param names an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant applyNames(Variant names) {
		return Dispatch.call(this, "ApplyNames", names);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant applyNames() {
		return Dispatch.call(this, "ApplyNames");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant applyOutlineStyles() {
		return Dispatch.call(this, "ApplyOutlineStyles");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Areas
	 */
	public Areas getAreas() {
		return new Areas(Dispatch.get(this, "Areas").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type String
	 */
	public String autoComplete(String lastParam) {
		return Dispatch.call(this, "AutoComplete", lastParam).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Range
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant autoFill(Range destination, int lastParam) {
		return Dispatch.call(this, "AutoFill", destination, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Range
	 * @return the result is of type Variant
	 */
	public Variant autoFill(Range destination) {
		return Dispatch.call(this, "AutoFill", destination);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param field an input-parameter of type Variant
	 * @param criteria1 an input-parameter of type Variant
	 * @param operator an input-parameter of type int
	 * @param criteria2 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFilter(Variant field, Variant criteria1, int operator, Variant criteria2, Variant lastParam) {
		return Dispatch.call(this, "AutoFilter", field, criteria1, new Variant(operator), criteria2, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param field an input-parameter of type Variant
	 * @param criteria1 an input-parameter of type Variant
	 * @param operator an input-parameter of type int
	 * @param criteria2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFilter(Variant field, Variant criteria1, int operator, Variant criteria2) {
		return Dispatch.call(this, "AutoFilter", field, criteria1, new Variant(operator), criteria2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param field an input-parameter of type Variant
	 * @param criteria1 an input-parameter of type Variant
	 * @param operator an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant autoFilter(Variant field, Variant criteria1, int operator) {
		return Dispatch.call(this, "AutoFilter", field, criteria1, new Variant(operator));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param field an input-parameter of type Variant
	 * @param criteria1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFilter(Variant field, Variant criteria1) {
		return Dispatch.call(this, "AutoFilter", field, criteria1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param field an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFilter(Variant field) {
		return Dispatch.call(this, "AutoFilter", field);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant autoFilter() {
		return Dispatch.call(this, "AutoFilter");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant autoFit() {
		return Dispatch.call(this, "AutoFit");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @param font an input-parameter of type Variant
	 * @param alignment an input-parameter of type Variant
	 * @param border an input-parameter of type Variant
	 * @param pattern an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number, Variant font, Variant alignment, Variant border, Variant pattern, Variant lastParam) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number, font, alignment, border, pattern, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @param font an input-parameter of type Variant
	 * @param alignment an input-parameter of type Variant
	 * @param border an input-parameter of type Variant
	 * @param pattern an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number, Variant font, Variant alignment, Variant border, Variant pattern) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number, font, alignment, border, pattern);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @param font an input-parameter of type Variant
	 * @param alignment an input-parameter of type Variant
	 * @param border an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number, Variant font, Variant alignment, Variant border) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number, font, alignment, border);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @param font an input-parameter of type Variant
	 * @param alignment an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number, Variant font, Variant alignment) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number, font, alignment);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @param font an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number, Variant font) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number, font);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @param number an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format, Variant number) {
		return Dispatch.call(this, "AutoFormat", new Variant(format), number);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant autoFormat(int format) {
		return Dispatch.call(this, "AutoFormat", new Variant(format));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant autoFormat() {
		return Dispatch.call(this, "AutoFormat");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant autoOutline() {
		return Dispatch.call(this, "AutoOutline");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lineStyle an input-parameter of type Variant
	 * @param weight an input-parameter of type int
	 * @param colorIndex an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant borderAround(Variant lineStyle, int weight, int colorIndex, Variant lastParam) {
		return Dispatch.call(this, "BorderAround", lineStyle, new Variant(weight), new Variant(colorIndex), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lineStyle an input-parameter of type Variant
	 * @param weight an input-parameter of type int
	 * @param colorIndex an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant borderAround(Variant lineStyle, int weight, int colorIndex) {
		return Dispatch.call(this, "BorderAround", lineStyle, new Variant(weight), new Variant(colorIndex));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lineStyle an input-parameter of type Variant
	 * @param weight an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant borderAround(Variant lineStyle, int weight) {
		return Dispatch.call(this, "BorderAround", lineStyle, new Variant(weight));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lineStyle an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant borderAround(Variant lineStyle) {
		return Dispatch.call(this, "BorderAround", lineStyle);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant borderAround() {
		return Dispatch.call(this, "BorderAround");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Borders
	 */
	public Borders getBorders() {
		return new Borders(Dispatch.get(this, "Borders").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant calculate() {
		return Dispatch.call(this, "Calculate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCells() {
		return new Range(Dispatch.get(this, "Cells").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Characters
	 */
	public Characters getCharacters(Variant start, Variant lastParam) {
		return new Characters(Dispatch.call(this, "Characters", start, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @return the result is of type Characters
	 */
	public Characters getCharacters(Variant start) {
		return new Characters(Dispatch.call(this, "Characters", start).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Characters
	 */
	public Characters getCharacters() {
		return new Characters(Dispatch.get(this, "Characters").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant lastParam) {
		return Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest) {
		return Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant checkSpelling(Variant customDictionary, Variant ignoreUppercase) {
		return Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant checkSpelling(Variant customDictionary) {
		return Dispatch.call(this, "CheckSpelling", customDictionary);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant checkSpelling() {
		return Dispatch.call(this, "CheckSpelling");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant clear() {
		return Dispatch.call(this, "Clear");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant clearContents() {
		return Dispatch.call(this, "ClearContents");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant clearFormats() {
		return Dispatch.call(this, "ClearFormats");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant clearNotes() {
		return Dispatch.call(this, "ClearNotes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant clearOutline() {
		return Dispatch.call(this, "ClearOutline");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getColumn() {
		return Dispatch.get(this, "Column").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range columnDifferences(Variant lastParam) {
		return new Range(Dispatch.call(this, "ColumnDifferences", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getColumns() {
		return new Range(Dispatch.get(this, "Columns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getColumnWidth() {
		return Dispatch.get(this, "ColumnWidth");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setColumnWidth(Variant lastParam) {
		Dispatch.call(this, "ColumnWidth", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sources an input-parameter of type Variant
	 * @param function an input-parameter of type Variant
	 * @param topRow an input-parameter of type Variant
	 * @param leftColumn an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant consolidate(Variant sources, Variant function, Variant topRow, Variant leftColumn, Variant lastParam) {
		return Dispatch.call(this, "Consolidate", sources, function, topRow, leftColumn, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sources an input-parameter of type Variant
	 * @param function an input-parameter of type Variant
	 * @param topRow an input-parameter of type Variant
	 * @param leftColumn an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant consolidate(Variant sources, Variant function, Variant topRow, Variant leftColumn) {
		return Dispatch.call(this, "Consolidate", sources, function, topRow, leftColumn);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sources an input-parameter of type Variant
	 * @param function an input-parameter of type Variant
	 * @param topRow an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant consolidate(Variant sources, Variant function, Variant topRow) {
		return Dispatch.call(this, "Consolidate", sources, function, topRow);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sources an input-parameter of type Variant
	 * @param function an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant consolidate(Variant sources, Variant function) {
		return Dispatch.call(this, "Consolidate", sources, function);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sources an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant consolidate(Variant sources) {
		return Dispatch.call(this, "Consolidate", sources);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant consolidate() {
		return Dispatch.call(this, "Consolidate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant copy(Variant lastParam) {
		return Dispatch.call(this, "Copy", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant copy() {
		return Dispatch.call(this, "Copy");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param data an input-parameter of type Variant
	 * @param maxRows an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type int
	 */
	public int copyFromRecordset(Variant data, Variant maxRows, Variant lastParam) {
		return Dispatch.call(this, "CopyFromRecordset", data, maxRows, lastParam).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param data an input-parameter of type Variant
	 * @param maxRows an input-parameter of type Variant
	 * @return the result is of type int
	 */
	public int copyFromRecordset(Variant data, Variant maxRows) {
		return Dispatch.call(this, "CopyFromRecordset", data, maxRows).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param data an input-parameter of type Variant
	 * @return the result is of type int
	 */
	public int copyFromRecordset(Variant data) {
		return Dispatch.call(this, "CopyFromRecordset", data).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param appearance an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant copyPicture(int appearance, int lastParam) {
		return Dispatch.call(this, "CopyPicture", new Variant(appearance), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param appearance an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant copyPicture(int appearance) {
		return Dispatch.call(this, "CopyPicture", new Variant(appearance));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant copyPicture() {
		return Dispatch.call(this, "CopyPicture");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param top an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param bottom an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createNames(Variant top, Variant left, Variant bottom, Variant lastParam) {
		return Dispatch.call(this, "CreateNames", top, left, bottom, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param top an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param bottom an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createNames(Variant top, Variant left, Variant bottom) {
		return Dispatch.call(this, "CreateNames", top, left, bottom);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param top an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createNames(Variant top, Variant left) {
		return Dispatch.call(this, "CreateNames", top, left);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param top an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createNames(Variant top) {
		return Dispatch.call(this, "CreateNames", top);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant createNames() {
		return Dispatch.call(this, "CreateNames");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 * @param containsRTF an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition, int appearance, Variant containsPICT, Variant containsBIFF, Variant containsRTF, Variant lastParam) {
		return Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), containsPICT, containsBIFF, containsRTF, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 * @param containsRTF an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition, int appearance, Variant containsPICT, Variant containsBIFF, Variant containsRTF) {
		return Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), containsPICT, containsBIFF, containsRTF);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition, int appearance, Variant containsPICT, Variant containsBIFF) {
		return Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), containsPICT, containsBIFF);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition, int appearance, Variant containsPICT) {
		return Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), containsPICT);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition, int appearance) {
		return Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createPublisher(Variant edition) {
		return Dispatch.call(this, "CreatePublisher", edition);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant createPublisher() {
		return Dispatch.call(this, "CreatePublisher");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCurrentArray() {
		return new Range(Dispatch.get(this, "CurrentArray").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCurrentRegion() {
		return new Range(Dispatch.get(this, "CurrentRegion").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant cut(Variant lastParam) {
		return Dispatch.call(this, "Cut", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant cut() {
		return Dispatch.call(this, "Cut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @param type an input-parameter of type int
	 * @param date an input-parameter of type int
	 * @param step an input-parameter of type Variant
	 * @param stop an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol, int type, int date, Variant step, Variant stop, Variant lastParam) {
		return Dispatch.call(this, "DataSeries", rowcol, new Variant(type), new Variant(date), step, stop, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @param type an input-parameter of type int
	 * @param date an input-parameter of type int
	 * @param step an input-parameter of type Variant
	 * @param stop an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol, int type, int date, Variant step, Variant stop) {
		return Dispatch.call(this, "DataSeries", rowcol, new Variant(type), new Variant(date), step, stop);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @param type an input-parameter of type int
	 * @param date an input-parameter of type int
	 * @param step an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol, int type, int date, Variant step) {
		return Dispatch.call(this, "DataSeries", rowcol, new Variant(type), new Variant(date), step);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @param type an input-parameter of type int
	 * @param date an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol, int type, int date) {
		return Dispatch.call(this, "DataSeries", rowcol, new Variant(type), new Variant(date));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @param type an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol, int type) {
		return Dispatch.call(this, "DataSeries", rowcol, new Variant(type));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowcol an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant dataSeries(Variant rowcol) {
		return Dispatch.call(this, "DataSeries", rowcol);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant dataSeries() {
		return Dispatch.call(this, "DataSeries");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant get_Default(Variant rowIndex, Variant lastParam) {
		return Dispatch.call(this, "_Default", rowIndex, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant get_Default(Variant rowIndex) {
		return Dispatch.call(this, "_Default", rowIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_Default() {
		return Dispatch.get(this, "_Default");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @param columnIndex an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void set_Default(Variant rowIndex, Variant columnIndex, Variant lastParam) {
		Dispatch.call(this, "_Default", rowIndex, columnIndex, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 */
	public void set_Default(Variant rowIndex) {
		Dispatch.call(this, "_Default", rowIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void set_Default() {
		Dispatch.call(this, "_Default");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant delete(Variant lastParam) {
		return Dispatch.call(this, "Delete", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant delete() {
		return Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDependents() {
		return new Range(Dispatch.get(this, "Dependents").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant dialogBox() {
		return Dispatch.call(this, "DialogBox");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDirectDependents() {
		return new Range(Dispatch.get(this, "DirectDependents").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDirectPrecedents() {
		return new Range(Dispatch.get(this, "DirectPrecedents").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @param name an input-parameter of type Variant
	 * @param reference an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param chartSize an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option, Variant name, Variant reference, int appearance, int chartSize, Variant lastParam) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option), name, reference, new Variant(appearance), new Variant(chartSize), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @param name an input-parameter of type Variant
	 * @param reference an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param chartSize an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option, Variant name, Variant reference, int appearance, int chartSize) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option), name, reference, new Variant(appearance), new Variant(chartSize));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @param name an input-parameter of type Variant
	 * @param reference an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option, Variant name, Variant reference, int appearance) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option), name, reference, new Variant(appearance));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @param name an input-parameter of type Variant
	 * @param reference an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option, Variant name, Variant reference) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option), name, reference);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @param name an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option, Variant name) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option), name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param option an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant editionOptions(int type, int option) {
		return Dispatch.call(this, "EditionOptions", new Variant(type), new Variant(option));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Range
	 */
	public Range getEnd(int lastParam) {
		return new Range(Dispatch.call(this, "End", new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getEntireColumn() {
		return new Range(Dispatch.get(this, "EntireColumn").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getEntireRow() {
		return new Range(Dispatch.get(this, "EntireRow").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant fillDown() {
		return Dispatch.call(this, "FillDown");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant fillLeft() {
		return Dispatch.call(this, "FillLeft");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant fillRight() {
		return Dispatch.call(this, "FillRight");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant fillUp() {
		return Dispatch.call(this, "FillUp");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @param searchDirection an input-parameter of type int
	 * @param matchCase an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn, Variant lookAt, Variant searchOrder, int searchDirection, Variant matchCase, Variant lastParam) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn, lookAt, searchOrder, new Variant(searchDirection), matchCase, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @param searchDirection an input-parameter of type int
	 * @param matchCase an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn, Variant lookAt, Variant searchOrder, int searchDirection, Variant matchCase) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn, lookAt, searchOrder, new Variant(searchDirection), matchCase).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @param searchDirection an input-parameter of type int
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn, Variant lookAt, Variant searchOrder, int searchDirection) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn, lookAt, searchOrder, new Variant(searchDirection)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn, Variant lookAt, Variant searchOrder) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn, lookAt, searchOrder).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn, Variant lookAt) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn, lookAt).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @param lookIn an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after, Variant lookIn) {
		return new Range(Dispatch.call(this, "Find", what, after, lookIn).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param after an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what, Variant after) {
		return new Range(Dispatch.call(this, "Find", what, after).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range find(Variant what) {
		return new Range(Dispatch.call(this, "Find", what).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range findNext(Variant lastParam) {
		return new Range(Dispatch.call(this, "FindNext", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range findNext() {
		return new Range(Dispatch.call(this, "FindNext").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range findPrevious(Variant lastParam) {
		return new Range(Dispatch.call(this, "FindPrevious", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range findPrevious() {
		return new Range(Dispatch.call(this, "FindPrevious").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Font
	 */
	public Font getFont() {
		return new Font(Dispatch.get(this, "Font").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormula() {
		return Dispatch.get(this, "Formula");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormula(Variant lastParam) {
		Dispatch.call(this, "Formula", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormulaArray() {
		return Dispatch.get(this, "FormulaArray");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormulaArray(Variant lastParam) {
		Dispatch.call(this, "FormulaArray", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getFormulaLabel() {
		return Dispatch.get(this, "FormulaLabel").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setFormulaLabel(int lastParam) {
		Dispatch.call(this, "FormulaLabel", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormulaHidden() {
		return Dispatch.get(this, "FormulaHidden");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormulaHidden(Variant lastParam) {
		Dispatch.call(this, "FormulaHidden", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormulaLocal() {
		return Dispatch.get(this, "FormulaLocal");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormulaLocal(Variant lastParam) {
		Dispatch.call(this, "FormulaLocal", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormulaR1C1() {
		return Dispatch.get(this, "FormulaR1C1");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormulaR1C1(Variant lastParam) {
		Dispatch.call(this, "FormulaR1C1", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFormulaR1C1Local() {
		return Dispatch.get(this, "FormulaR1C1Local");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setFormulaR1C1Local(Variant lastParam) {
		Dispatch.call(this, "FormulaR1C1Local", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant functionWizard() {
		return Dispatch.call(this, "FunctionWizard");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param goal an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Range
	 * @return the result is of type boolean
	 */
	public boolean goalSeek(Variant goal, Range lastParam) {
		return Dispatch.call(this, "GoalSeek", goal, lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @param end an input-parameter of type Variant
	 * @param by an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant group(Variant start, Variant end, Variant by, Variant lastParam) {
		return Dispatch.call(this, "Group", start, end, by, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @param end an input-parameter of type Variant
	 * @param by an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant group(Variant start, Variant end, Variant by) {
		return Dispatch.call(this, "Group", start, end, by);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @param end an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant group(Variant start, Variant end) {
		return Dispatch.call(this, "Group", start, end);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param start an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant group(Variant start) {
		return Dispatch.call(this, "Group", start);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant group() {
		return Dispatch.call(this, "Group");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHasArray() {
		return Dispatch.get(this, "HasArray");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHasFormula() {
		return Dispatch.get(this, "HasFormula");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHeight() {
		return Dispatch.get(this, "Height");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHidden() {
		return Dispatch.get(this, "Hidden");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setHidden(Variant lastParam) {
		Dispatch.call(this, "Hidden", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHorizontalAlignment() {
		return Dispatch.get(this, "HorizontalAlignment");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setHorizontalAlignment(Variant lastParam) {
		Dispatch.call(this, "HorizontalAlignment", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getIndentLevel() {
		return Dispatch.get(this, "IndentLevel");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setIndentLevel(Variant lastParam) {
		Dispatch.call(this, "IndentLevel", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void insertIndent(int lastParam) {
		Dispatch.call(this, "InsertIndent", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant insert(Variant lastParam) {
		return Dispatch.call(this, "Insert", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant insert() {
		return Dispatch.call(this, "Insert");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Interior
	 */
	public Interior getInterior() {
		return new Interior(Dispatch.get(this, "Interior").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getItem(Variant rowIndex, Variant lastParam) {
		return Dispatch.call(this, "Item", rowIndex, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getItem(Variant rowIndex) {
		return Dispatch.call(this, "Item", rowIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 * @param columnIndex an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setItem(Variant rowIndex, Variant columnIndex, Variant lastParam) {
		Dispatch.call(this, "Item", rowIndex, columnIndex, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowIndex an input-parameter of type Variant
	 */
	public void setItem(Variant rowIndex) {
		Dispatch.call(this, "Item", rowIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant justify() {
		return Dispatch.call(this, "Justify");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getLeft() {
		return Dispatch.get(this, "Left");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getListHeaderRows() {
		return Dispatch.get(this, "ListHeaderRows").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant listNames() {
		return Dispatch.call(this, "ListNames");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getLocationInTable() {
		return Dispatch.get(this, "LocationInTable").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getLocked() {
		return Dispatch.get(this, "Locked");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setLocked(Variant lastParam) {
		Dispatch.call(this, "Locked", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void merge(Variant lastParam) {
		Dispatch.call(this, "Merge", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void merge() {
		Dispatch.call(this, "Merge");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unMerge() {
		Dispatch.call(this, "UnMerge");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getMergeArea() {
		return new Range(Dispatch.get(this, "MergeArea").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getMergeCells() {
		return Dispatch.get(this, "MergeCells");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setMergeCells(Variant lastParam) {
		Dispatch.call(this, "MergeCells", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getName() {
		return Dispatch.get(this, "Name");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setName(Variant lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param towardPrecedent an input-parameter of type Variant
	 * @param arrowNumber an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant navigateArrow(Variant towardPrecedent, Variant arrowNumber, Variant lastParam) {
		return Dispatch.call(this, "NavigateArrow", towardPrecedent, arrowNumber, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param towardPrecedent an input-parameter of type Variant
	 * @param arrowNumber an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant navigateArrow(Variant towardPrecedent, Variant arrowNumber) {
		return Dispatch.call(this, "NavigateArrow", towardPrecedent, arrowNumber);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param towardPrecedent an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant navigateArrow(Variant towardPrecedent) {
		return Dispatch.call(this, "NavigateArrow", towardPrecedent);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant navigateArrow() {
		return Dispatch.call(this, "NavigateArrow");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getNext() {
		return new Range(Dispatch.get(this, "Next").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type Variant
	 * @param start an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String noteText(Variant text, Variant start, Variant lastParam) {
		return Dispatch.call(this, "NoteText", text, start, lastParam).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type Variant
	 * @param start an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String noteText(Variant text, Variant start) {
		return Dispatch.call(this, "NoteText", text, start).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String noteText(Variant text) {
		return Dispatch.call(this, "NoteText", text).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String noteText() {
		return Dispatch.call(this, "NoteText").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getNumberFormat() {
		return Dispatch.get(this, "NumberFormat");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setNumberFormat(Variant lastParam) {
		Dispatch.call(this, "NumberFormat", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getNumberFormatLocal() {
		return Dispatch.get(this, "NumberFormatLocal");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setNumberFormatLocal(Variant lastParam) {
		Dispatch.call(this, "NumberFormatLocal", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowOffset an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getOffset(Variant rowOffset, Variant lastParam) {
		return new Range(Dispatch.call(this, "Offset", rowOffset, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowOffset an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getOffset(Variant rowOffset) {
		return new Range(Dispatch.call(this, "Offset", rowOffset).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getOffset() {
		return new Range(Dispatch.get(this, "Offset").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getOrientation() {
		return Dispatch.get(this, "Orientation");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setOrientation(Variant lastParam) {
		Dispatch.call(this, "Orientation", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getOutlineLevel() {
		return Dispatch.get(this, "OutlineLevel");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setOutlineLevel(Variant lastParam) {
		Dispatch.call(this, "OutlineLevel", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getPageBreak() {
		return Dispatch.get(this, "PageBreak").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setPageBreak(int lastParam) {
		Dispatch.call(this, "PageBreak", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param parseLine an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant parse(Variant parseLine, Variant lastParam) {
		return Dispatch.call(this, "Parse", parseLine, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param parseLine an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant parse(Variant parseLine) {
		return Dispatch.call(this, "Parse", parseLine);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant parse() {
		return Dispatch.call(this, "Parse");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param paste an input-parameter of type int
	 * @param operation an input-parameter of type int
	 * @param skipBlanks an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant pasteSpecial(int paste, int operation, Variant skipBlanks, Variant lastParam) {
		return Dispatch.call(this, "PasteSpecial", new Variant(paste), new Variant(operation), skipBlanks, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param paste an input-parameter of type int
	 * @param operation an input-parameter of type int
	 * @param skipBlanks an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant pasteSpecial(int paste, int operation, Variant skipBlanks) {
		return Dispatch.call(this, "PasteSpecial", new Variant(paste), new Variant(operation), skipBlanks);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param paste an input-parameter of type int
	 * @param operation an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant pasteSpecial(int paste, int operation) {
		return Dispatch.call(this, "PasteSpecial", new Variant(paste), new Variant(operation));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param paste an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant pasteSpecial(int paste) {
		return Dispatch.call(this, "PasteSpecial", new Variant(paste));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant pasteSpecial() {
		return Dispatch.call(this, "PasteSpecial");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotField
	 */
	public PivotField getPivotField() {
		return new PivotField(Dispatch.get(this, "PivotField").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotItem
	 */
	public PivotItem getPivotItem() {
		return new PivotItem(Dispatch.get(this, "PivotItem").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotTable
	 */
	public PivotTable getPivotTable() {
		return new PivotTable(Dispatch.get(this, "PivotTable").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getPrecedents() {
		return new Range(Dispatch.get(this, "Precedents").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getPrefixCharacter() {
		return Dispatch.get(this, "PrefixCharacter");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getPrevious() {
		return new Range(Dispatch.get(this, "Previous").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		return Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		return Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		return Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		return Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to, Variant copies) {
		return Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from, Variant to) {
		return Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut(Variant from) {
		return Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _PrintOut() {
		return Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printPreview(Variant lastParam) {
		return Dispatch.call(this, "PrintPreview", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant printPreview() {
		return Dispatch.call(this, "PrintPreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type QueryTable
	 */
	public QueryTable getQueryTable() {
		return new QueryTable(Dispatch.get(this, "QueryTable").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1, Variant lastParam) {
		return new Range(Dispatch.call(this, "Range", cell1, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1) {
		return new Range(Dispatch.call(this, "Range", cell1).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant removeSubtotal() {
		return Dispatch.call(this, "RemoveSubtotal");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param replacement an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean replace(Variant what, Variant replacement, Variant lookAt, Variant searchOrder, Variant matchCase, Variant lastParam) {
		return Dispatch.call(this, "Replace", what, replacement, lookAt, searchOrder, matchCase, lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param replacement an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean replace(Variant what, Variant replacement, Variant lookAt, Variant searchOrder, Variant matchCase) {
		return Dispatch.call(this, "Replace", what, replacement, lookAt, searchOrder, matchCase).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param replacement an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @param searchOrder an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean replace(Variant what, Variant replacement, Variant lookAt, Variant searchOrder) {
		return Dispatch.call(this, "Replace", what, replacement, lookAt, searchOrder).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param replacement an input-parameter of type Variant
	 * @param lookAt an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean replace(Variant what, Variant replacement, Variant lookAt) {
		return Dispatch.call(this, "Replace", what, replacement, lookAt).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type Variant
	 * @param replacement an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean replace(Variant what, Variant replacement) {
		return Dispatch.call(this, "Replace", what, replacement).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowSize an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getResize(Variant rowSize, Variant lastParam) {
		return new Range(Dispatch.call(this, "Resize", rowSize, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowSize an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getResize(Variant rowSize) {
		return new Range(Dispatch.call(this, "Resize", rowSize).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getResize() {
		return new Range(Dispatch.get(this, "Resize").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRow() {
		return Dispatch.get(this, "Row").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range rowDifferences(Variant lastParam) {
		return new Range(Dispatch.call(this, "RowDifferences", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getRowHeight() {
		return Dispatch.get(this, "RowHeight");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setRowHeight(Variant lastParam) {
		Dispatch.call(this, "RowHeight", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getRows() {
		return new Range(Dispatch.get(this, "Rows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "Run", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "Run", arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1, Variant arg2) {
		return Dispatch.call(this, "Run", arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant arg1) {
		return Dispatch.call(this, "Run", arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant run() {
		return Dispatch.call(this, "Run");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant select() {
		return Dispatch.call(this, "Select");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant show() {
		return Dispatch.call(this, "Show");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant showDependents(Variant lastParam) {
		return Dispatch.call(this, "ShowDependents", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant showDependents() {
		return Dispatch.call(this, "ShowDependents");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getShowDetail() {
		return Dispatch.get(this, "ShowDetail");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setShowDetail(Variant lastParam) {
		Dispatch.call(this, "ShowDetail", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant showErrors() {
		return Dispatch.call(this, "ShowErrors");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant showPrecedents(Variant lastParam) {
		return Dispatch.call(this, "ShowPrecedents", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant showPrecedents() {
		return Dispatch.call(this, "ShowPrecedents");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getShrinkToFit() {
		return Dispatch.get(this, "ShrinkToFit");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setShrinkToFit(Variant lastParam) {
		Dispatch.call(this, "ShrinkToFit", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @param orientation an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3, int header, Variant orderCustom, Variant matchCase, int orientation, int lastParam) {
		return Dispatch.callN(this, "Sort", new Object[] { key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom, matchCase, new Variant(orientation), new Variant(lastParam)});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @param orientation an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3, int header, Variant orderCustom, Variant matchCase, int orientation) {
		return Dispatch.callN(this, "Sort", new Object[] { key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom, matchCase, new Variant(orientation)});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3, int header, Variant orderCustom, Variant matchCase) {
		return Dispatch.callN(this, "Sort", new Object[] { key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom, matchCase});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3, int header, Variant orderCustom) {
		return Dispatch.callN(this, "Sort", new Object[] { key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3, int header) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3), new Variant(header));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3, int order3) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2, type, new Variant(order2), key3, new Variant(order3));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2, Variant key3) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2, type, new Variant(order2), key3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type, int order2) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2, type, new Variant(order2));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @param type an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2, Variant type) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2, type);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param key2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1, Variant key2) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1), key2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1, int order1) {
		return Dispatch.call(this, "Sort", key1, new Variant(order1));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sort(Variant key1) {
		return Dispatch.call(this, "Sort", key1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant sort() {
		return Dispatch.call(this, "Sort");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3, int order3, int header, Variant orderCustom, Variant matchCase, int lastParam) {
		return Dispatch.callN(this, "SortSpecial", new Object[] { new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom, matchCase, new Variant(lastParam)});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @param matchCase an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3, int order3, int header, Variant orderCustom, Variant matchCase) {
		return Dispatch.callN(this, "SortSpecial", new Object[] { new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom, matchCase});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @param orderCustom an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3, int order3, int header, Variant orderCustom) {
		return Dispatch.callN(this, "SortSpecial", new Object[] { new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3, new Variant(order3), new Variant(header), orderCustom});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @param header an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3, int order3, int header) {
		return Dispatch.callN(this, "SortSpecial", new Object[] { new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3, new Variant(order3), new Variant(header)});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @param order3 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3, int order3) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3, new Variant(order3));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @param key3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2, Variant key3) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2), key3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @param order2 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2, int order2) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1), type, key2, new Variant(order2));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param key2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type, Variant key2) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1), type, key2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1, Variant type) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1), type);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @param order1 an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1, int order1) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1, new Variant(order1));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @param key1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod, Variant key1) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod), key1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sortMethod an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial(int sortMethod) {
		return Dispatch.call(this, "SortSpecial", new Variant(sortMethod));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant sortSpecial() {
		return Dispatch.call(this, "SortSpecial");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type SoundNote
	 */
	public SoundNote getSoundNote() {
		return new SoundNote(Dispatch.get(this, "SoundNote").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range specialCells(int type, Variant lastParam) {
		return new Range(Dispatch.call(this, "SpecialCells", new Variant(type), lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @return the result is of type Range
	 */
	public Range specialCells(int type) {
		return new Range(Dispatch.call(this, "SpecialCells", new Variant(type)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getStyle() {
		return Dispatch.get(this, "Style");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setStyle(Variant lastParam) {
		Dispatch.call(this, "Style", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type String
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant subscribeTo(String edition, int lastParam) {
		return Dispatch.call(this, "SubscribeTo", edition, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant subscribeTo(String edition) {
		return Dispatch.call(this, "SubscribeTo", edition);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param groupBy an input-parameter of type int
	 * @param function an input-parameter of type int
	 * @param totalList an input-parameter of type Variant
	 * @param replace an input-parameter of type Variant
	 * @param pageBreaks an input-parameter of type Variant
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant subtotal(int groupBy, int function, Variant totalList, Variant replace, Variant pageBreaks, int lastParam) {
		return Dispatch.call(this, "Subtotal", new Variant(groupBy), new Variant(function), totalList, replace, pageBreaks, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param groupBy an input-parameter of type int
	 * @param function an input-parameter of type int
	 * @param totalList an input-parameter of type Variant
	 * @param replace an input-parameter of type Variant
	 * @param pageBreaks an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant subtotal(int groupBy, int function, Variant totalList, Variant replace, Variant pageBreaks) {
		return Dispatch.call(this, "Subtotal", new Variant(groupBy), new Variant(function), totalList, replace, pageBreaks);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param groupBy an input-parameter of type int
	 * @param function an input-parameter of type int
	 * @param totalList an input-parameter of type Variant
	 * @param replace an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant subtotal(int groupBy, int function, Variant totalList, Variant replace) {
		return Dispatch.call(this, "Subtotal", new Variant(groupBy), new Variant(function), totalList, replace);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param groupBy an input-parameter of type int
	 * @param function an input-parameter of type int
	 * @param totalList an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant subtotal(int groupBy, int function, Variant totalList) {
		return Dispatch.call(this, "Subtotal", new Variant(groupBy), new Variant(function), totalList);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSummary() {
		return Dispatch.get(this, "Summary");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowInput an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant table(Variant rowInput, Variant lastParam) {
		return Dispatch.call(this, "Table", rowInput, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowInput an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant table(Variant rowInput) {
		return Dispatch.call(this, "Table", rowInput);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant table() {
		return Dispatch.call(this, "Table");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getText() {
		return Dispatch.get(this, "Text");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param decimalSeparator an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant decimalSeparator, Variant lastParam) {
		return Dispatch.callN(this, "TextToColumns", new Object[] { destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, decimalSeparator, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @param decimalSeparator an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo, Variant decimalSeparator) {
		return Dispatch.callN(this, "TextToColumns", new Object[] { destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo, decimalSeparator});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @param fieldInfo an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar, Variant fieldInfo) {
		return Dispatch.callN(this, "TextToColumns", new Object[] { destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar, fieldInfo});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @param otherChar an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other, Variant otherChar) {
		return Dispatch.callN(this, "TextToColumns", new Object[] { destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other, otherChar});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @param other an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space, Variant other) {
		return Dispatch.callN(this, "TextToColumns", new Object[] { destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space, other});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @param space an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma, Variant space) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma, space);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @param comma an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon, Variant comma) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon, comma);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @param semicolon an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab, Variant semicolon) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab, semicolon);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @param tab an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter, Variant tab) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter, tab);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @param consecutiveDelimiter an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier, Variant consecutiveDelimiter) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier), consecutiveDelimiter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @param textQualifier an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType, int textQualifier) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType), new Variant(textQualifier));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param dataType an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination, int dataType) {
		return Dispatch.call(this, "TextToColumns", destination, new Variant(dataType));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant textToColumns(Variant destination) {
		return Dispatch.call(this, "TextToColumns", destination);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant textToColumns() {
		return Dispatch.call(this, "TextToColumns");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getTop() {
		return Dispatch.get(this, "Top");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant ungroup() {
		return Dispatch.call(this, "Ungroup");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getUseStandardHeight() {
		return Dispatch.get(this, "UseStandardHeight");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setUseStandardHeight(Variant lastParam) {
		Dispatch.call(this, "UseStandardHeight", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getUseStandardWidth() {
		return Dispatch.get(this, "UseStandardWidth");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setUseStandardWidth(Variant lastParam) {
		Dispatch.call(this, "UseStandardWidth", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Validation
	 */
	public Validation getValidation() {
		return new Validation(Dispatch.get(this, "Validation").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getValue() {
		return Dispatch.get(this, "Value");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setValue(Variant lastParam) {
		Dispatch.call(this, "Value", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getValue2() {
		return Dispatch.get(this, "Value2");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setValue2(Variant lastParam) {
		Dispatch.call(this, "Value2", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getVerticalAlignment() {
		return Dispatch.get(this, "VerticalAlignment");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setVerticalAlignment(Variant lastParam) {
		Dispatch.call(this, "VerticalAlignment", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getWidth() {
		return Dispatch.get(this, "Width");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Worksheet
	 */
	public Worksheet getWorksheet() {
		return new Worksheet(Dispatch.get(this, "Worksheet").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getWrapText() {
		return Dispatch.get(this, "WrapText");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setWrapText(Variant lastParam) {
		Dispatch.call(this, "WrapText", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Comment
	 */
	public Comment addComment(Variant lastParam) {
		return new Comment(Dispatch.call(this, "AddComment", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Comment
	 */
	public Comment addComment() {
		return new Comment(Dispatch.call(this, "AddComment").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Comment
	 */
	public Comment getComment() {
		return new Comment(Dispatch.get(this, "Comment").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void clearComments() {
		Dispatch.call(this, "ClearComments");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Phonetic
	 */
	public Phonetic getPhonetic() {
		return new Phonetic(Dispatch.get(this, "Phonetic").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type FormatConditions
	 */
	public FormatConditions getFormatConditions() {
		return new FormatConditions(Dispatch.get(this, "FormatConditions").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getReadingOrder() {
		return Dispatch.get(this, "ReadingOrder").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setReadingOrder(int lastParam) {
		Dispatch.call(this, "ReadingOrder", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Hyperlinks
	 */
	public Hyperlinks getHyperlinks() {
		return new Hyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Phonetics
	 */
	public Phonetics getPhonetics() {
		return new Phonetics(Dispatch.get(this, "Phonetics").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void setPhonetic() {
		Dispatch.call(this, "SetPhonetic");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getID() {
		return Dispatch.get(this, "ID").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setID(String lastParam) {
		Dispatch.call(this, "ID", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate, Variant lastParam) {
		return Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate) {
		return Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		return Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		return Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies, Variant preview) {
		return Dispatch.call(this, "PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to, Variant copies) {
		return Dispatch.call(this, "PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from, Variant to) {
		return Dispatch.call(this, "PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant printOut(Variant from) {
		return Dispatch.call(this, "PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant printOut() {
		return Dispatch.call(this, "PrintOut");
	}

}
