/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPriority {

	public static final int xlPriorityHigh = -4127;
	public static final int xlPriorityLow = -4134;
	public static final int xlPriorityNormal = -4143;
}
