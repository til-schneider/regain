/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpSlideShowPointerType {

	public static final int ppSlideShowPointerNone = 0;
	public static final int ppSlideShowPointerArrow = 1;
	public static final int ppSlideShowPointerPen = 2;
	public static final int ppSlideShowPointerAlwaysHidden = 3;
	public static final int ppSlideShowPointerAutoArrow = 4;
}
