/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpFollowColors {

	public static final int ppFollowColorsMixed = -2;
	public static final int ppFollowColorsNone = 0;
	public static final int ppFollowColorsScheme = 1;
	public static final int ppFollowColorsTextAndBackground = 2;
}
