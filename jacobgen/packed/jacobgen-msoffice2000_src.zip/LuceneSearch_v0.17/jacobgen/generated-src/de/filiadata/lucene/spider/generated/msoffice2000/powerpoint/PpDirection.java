/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpDirection {

	public static final int ppDirectionMixed = -2;
	public static final int ppDirectionLeftToRight = 1;
	public static final int ppDirectionRightToLeft = 2;
}
