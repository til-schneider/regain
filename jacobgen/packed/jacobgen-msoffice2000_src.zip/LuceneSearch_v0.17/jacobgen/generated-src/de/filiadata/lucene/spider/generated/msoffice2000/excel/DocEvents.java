/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class DocEvents extends Dispatch {

	public static final String componentName = "Excel.DocEvents";

	public DocEvents() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public DocEvents(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public DocEvents(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Range
	 */
	public void selectionChange(Range lastParam) {
		Dispatch.call(this, "SelectionChange", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeDoubleClick(Range target, boolean lastParam) {
		Dispatch.call(this, "BeforeDoubleClick", target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void beforeRightClick(Range target, boolean lastParam) {
		Dispatch.call(this, "BeforeRightClick", target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void deactivate() {
		Dispatch.call(this, "Deactivate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculate() {
		Dispatch.call(this, "Calculate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Range
	 */
	public void change(Range lastParam) {
		Dispatch.call(this, "Change", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Hyperlink
	 */
	public void followHyperlink(Hyperlink lastParam) {
		Dispatch.call(this, "FollowHyperlink", lastParam);
	}

}
