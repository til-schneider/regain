/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPivotTableSourceType {

	public static final int xlConsolidation = 3;
	public static final int xlDatabase = 1;
	public static final int xlExternal = 2;
	public static final int xlPivotTable = -4148;
}
