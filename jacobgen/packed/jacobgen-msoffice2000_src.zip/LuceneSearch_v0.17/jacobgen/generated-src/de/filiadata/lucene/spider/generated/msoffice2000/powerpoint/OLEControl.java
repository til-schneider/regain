/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class OLEControl extends OCXExtender {

	public static final String componentName = "PowerPoint.OLEControl";

	public OLEControl() {
		super(componentName);
	}

	public OLEControl(Dispatch d) {
		super(d);
	}
}
