/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlErrorBarInclude {

	public static final int xlErrorBarIncludeBoth = 1;
	public static final int xlErrorBarIncludeMinusValues = 3;
	public static final int xlErrorBarIncludeNone = -4142;
	public static final int xlErrorBarIncludePlusValues = 2;
}
