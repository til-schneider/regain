/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpSlideLayout {

	public static final int ppLayoutMixed = -2;
	public static final int ppLayoutTitle = 1;
	public static final int ppLayoutText = 2;
	public static final int ppLayoutTwoColumnText = 3;
	public static final int ppLayoutTable = 4;
	public static final int ppLayoutTextAndChart = 5;
	public static final int ppLayoutChartAndText = 6;
	public static final int ppLayoutOrgchart = 7;
	public static final int ppLayoutChart = 8;
	public static final int ppLayoutTextAndClipart = 9;
	public static final int ppLayoutClipartAndText = 10;
	public static final int ppLayoutTitleOnly = 11;
	public static final int ppLayoutBlank = 12;
	public static final int ppLayoutTextAndObject = 13;
	public static final int ppLayoutObjectAndText = 14;
	public static final int ppLayoutLargeObject = 15;
	public static final int ppLayoutObject = 16;
	public static final int ppLayoutTextAndMediaClip = 17;
	public static final int ppLayoutMediaClipAndText = 18;
	public static final int ppLayoutObjectOverText = 19;
	public static final int ppLayoutTextOverObject = 20;
	public static final int ppLayoutTextAndTwoObjects = 21;
	public static final int ppLayoutTwoObjectsAndText = 22;
	public static final int ppLayoutTwoObjectsOverText = 23;
	public static final int ppLayoutFourObjects = 24;
	public static final int ppLayoutVerticalText = 25;
	public static final int ppLayoutClipArtAndVerticalText = 26;
	public static final int ppLayoutVerticalTitleAndText = 27;
	public static final int ppLayoutVerticalTitleAndTextOverChart = 28;
}
