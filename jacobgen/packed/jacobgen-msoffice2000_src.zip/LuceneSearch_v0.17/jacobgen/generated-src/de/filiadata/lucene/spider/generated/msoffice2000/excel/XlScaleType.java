/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlScaleType {

	public static final int xlScaleLinear = -4132;
	public static final int xlScaleLogarithmic = -4133;
}
