/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpAlertIcon {

	public static final int ppAlertIconQuestionMark = 0;
	public static final int ppAlertIconNote = 1;
	public static final int ppAlertIconCaution = 2;
	public static final int ppAlertIconStop = 3;
}
