/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlTickLabelPosition {

	public static final int xlTickLabelPositionHigh = -4127;
	public static final int xlTickLabelPositionLow = -4134;
	public static final int xlTickLabelPositionNextToAxis = 4;
	public static final int xlTickLabelPositionNone = -4142;
}
