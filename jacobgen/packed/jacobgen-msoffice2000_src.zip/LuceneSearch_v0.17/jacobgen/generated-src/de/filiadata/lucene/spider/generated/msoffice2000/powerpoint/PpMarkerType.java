/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpMarkerType {

	public static final int ppBoot = 0;
	public static final int ppFileNew = 1;
	public static final int ppFileOpen = 2;
	public static final int ppFileSave = 3;
	public static final int ppPrintForeground = 4;
	public static final int ppPrintBackground = 5;
	public static final int ppOLEInsert = 6;
	public static final int ppSlideShowStart = 7;
	public static final int ppSlideShowDraw = 8;
	public static final int ppSlideViewScroll = 9;
	public static final int ppDialogStart = 10;
}
