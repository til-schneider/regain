/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Dialog extends Dispatch {

	public static final String componentName = "Excel.Dialog";

	public Dialog() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Dialog(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Dialog(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "Show", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9}).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3, arg4, arg5, arg6, arg7).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3, arg4, arg5, arg6).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3, arg4, arg5).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3, arg4).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "Show", arg1, arg2, arg3).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1, Variant arg2) {
		return Dispatch.call(this, "Show", arg1, arg2).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean show(Variant arg1) {
		return Dispatch.call(this, "Show", arg1).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean show() {
		return Dispatch.call(this, "Show").toBoolean();
	}

}
