/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLinkInfo {

	public static final int xlEditionDate = 2;
	public static final int xlUpdateState = 1;
}
