/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpArrangeStyle {

	public static final int ppArrangeTiled = 1;
	public static final int ppArrangeCascade = 2;
}
