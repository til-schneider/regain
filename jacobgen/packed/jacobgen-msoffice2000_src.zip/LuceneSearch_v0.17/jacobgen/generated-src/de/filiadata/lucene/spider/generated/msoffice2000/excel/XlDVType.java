/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDVType {

	public static final int xlValidateInputOnly = 0;
	public static final int xlValidateWholeNumber = 1;
	public static final int xlValidateDecimal = 2;
	public static final int xlValidateList = 3;
	public static final int xlValidateDate = 4;
	public static final int xlValidateTime = 5;
	public static final int xlValidateTextLength = 6;
	public static final int xlValidateCustom = 7;
}
