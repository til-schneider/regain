/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDataLabelsType {

	public static final int xlDataLabelsShowNone = -4142;
	public static final int xlDataLabelsShowValue = 2;
	public static final int xlDataLabelsShowPercent = 3;
	public static final int xlDataLabelsShowLabel = 4;
	public static final int xlDataLabelsShowLabelAndPercent = 5;
	public static final int xlDataLabelsShowBubbleSizes = 6;
}
