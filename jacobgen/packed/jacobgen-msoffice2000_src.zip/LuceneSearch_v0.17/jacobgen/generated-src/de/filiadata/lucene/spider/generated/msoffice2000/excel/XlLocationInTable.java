/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLocationInTable {

	public static final int xlColumnHeader = -4110;
	public static final int xlColumnItem = 5;
	public static final int xlDataHeader = 3;
	public static final int xlDataItem = 7;
	public static final int xlPageHeader = 2;
	public static final int xlPageItem = 6;
	public static final int xlRowHeader = -4153;
	public static final int xlRowItem = 4;
	public static final int xlTableBody = 8;
}
