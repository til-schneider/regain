/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlArrowHeadWidth {

	public static final int xlArrowHeadWidthMedium = -4138;
	public static final int xlArrowHeadWidthNarrow = 1;
	public static final int xlArrowHeadWidthWide = 3;
}
