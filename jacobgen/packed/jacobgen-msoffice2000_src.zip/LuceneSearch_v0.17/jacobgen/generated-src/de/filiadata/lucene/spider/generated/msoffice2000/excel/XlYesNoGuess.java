/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlYesNoGuess {

	public static final int xlGuess = 0;
	public static final int xlNo = 2;
	public static final int xlYes = 1;
}
