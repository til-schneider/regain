/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLineStyle {

	public static final int xlContinuous = 1;
	public static final int xlDash = -4115;
	public static final int xlDashDot = 4;
	public static final int xlDashDotDot = 5;
	public static final int xlDot = -4118;
	public static final int xlDouble = -4119;
	public static final int xlSlantDashDot = 13;
	public static final int xlLineStyleNone = -4142;
}
