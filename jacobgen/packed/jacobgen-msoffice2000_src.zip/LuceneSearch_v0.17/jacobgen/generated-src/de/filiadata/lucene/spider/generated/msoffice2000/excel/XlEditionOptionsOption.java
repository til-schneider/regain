/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlEditionOptionsOption {

	public static final int xlAutomaticUpdate = 4;
	public static final int xlCancel = 1;
	public static final int xlChangeAttributes = 6;
	public static final int xlManualUpdate = 5;
	public static final int xlOpenSource = 3;
	public static final int xlSelect = 3;
	public static final int xlSendPublisher = 2;
	public static final int xlUpdateSubscriber = 2;
}
