/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlOrientation {

	public static final int xlDownward = -4170;
	public static final int xlHorizontal = -4128;
	public static final int xlUpward = -4171;
	public static final int xlVertical = -4166;
}
