/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlTrendlineType {

	public static final int xlExponential = 5;
	public static final int xlLinear = -4132;
	public static final int xlLogarithmic = -4133;
	public static final int xlMovingAvg = 6;
	public static final int xlPolynomial = 3;
	public static final int xlPower = 4;
}
