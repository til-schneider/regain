/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlWindowState {

	public static final int xlMaximized = -4137;
	public static final int xlMinimized = -4140;
	public static final int xlNormal = -4143;
}
