/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Scenarios extends Dispatch {

	public static final String componentName = "Excel.Scenarios";

	public Scenarios() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Scenarios(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Scenarios(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param changingCells an input-parameter of type Variant
	 * @param values an input-parameter of type Variant
	 * @param comment an input-parameter of type Variant
	 * @param locked an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario add(String name, Variant changingCells, Variant values, Variant comment, Variant locked, Variant lastParam) {
		return new Scenario(Dispatch.call(this, "Add", name, changingCells, values, comment, locked, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param changingCells an input-parameter of type Variant
	 * @param values an input-parameter of type Variant
	 * @param comment an input-parameter of type Variant
	 * @param locked an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario add(String name, Variant changingCells, Variant values, Variant comment, Variant locked) {
		return new Scenario(Dispatch.call(this, "Add", name, changingCells, values, comment, locked).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param changingCells an input-parameter of type Variant
	 * @param values an input-parameter of type Variant
	 * @param comment an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario add(String name, Variant changingCells, Variant values, Variant comment) {
		return new Scenario(Dispatch.call(this, "Add", name, changingCells, values, comment).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param changingCells an input-parameter of type Variant
	 * @param values an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario add(String name, Variant changingCells, Variant values) {
		return new Scenario(Dispatch.call(this, "Add", name, changingCells, values).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param changingCells an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario add(String name, Variant changingCells) {
		return new Scenario(Dispatch.call(this, "Add", name, changingCells).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param reportType an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant createSummary(int reportType, Variant lastParam) {
		return Dispatch.call(this, "CreateSummary", new Variant(reportType), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param reportType an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant createSummary(int reportType) {
		return Dispatch.call(this, "CreateSummary", new Variant(reportType));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant createSummary() {
		return Dispatch.call(this, "CreateSummary");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Scenario
	 */
	public Scenario item(Variant lastParam) {
		return new Scenario(Dispatch.call(this, "Item", lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant merge(Variant lastParam) {
		return Dispatch.call(this, "Merge", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _NewEnum() {
		return Dispatch.call(this, "_NewEnum");
	}

}
