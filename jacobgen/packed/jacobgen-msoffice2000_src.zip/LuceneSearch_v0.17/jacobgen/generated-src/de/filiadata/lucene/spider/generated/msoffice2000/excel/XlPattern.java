/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPattern {

	public static final int xlPatternAutomatic = -4105;
	public static final int xlPatternChecker = 9;
	public static final int xlPatternCrissCross = 16;
	public static final int xlPatternDown = -4121;
	public static final int xlPatternGray16 = 17;
	public static final int xlPatternGray25 = -4124;
	public static final int xlPatternGray50 = -4125;
	public static final int xlPatternGray75 = -4126;
	public static final int xlPatternGray8 = 18;
	public static final int xlPatternGrid = 15;
	public static final int xlPatternHorizontal = -4128;
	public static final int xlPatternLightDown = 13;
	public static final int xlPatternLightHorizontal = 11;
	public static final int xlPatternLightUp = 14;
	public static final int xlPatternLightVertical = 12;
	public static final int xlPatternNone = -4142;
	public static final int xlPatternSemiGray75 = 10;
	public static final int xlPatternSolid = 1;
	public static final int xlPatternUp = -4162;
	public static final int xlPatternVertical = -4166;
}
