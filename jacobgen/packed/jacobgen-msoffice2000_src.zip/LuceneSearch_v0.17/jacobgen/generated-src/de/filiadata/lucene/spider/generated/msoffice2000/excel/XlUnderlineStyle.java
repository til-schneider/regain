/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlUnderlineStyle {

	public static final int xlUnderlineStyleDouble = -4119;
	public static final int xlUnderlineStyleDoubleAccounting = 5;
	public static final int xlUnderlineStyleNone = -4142;
	public static final int xlUnderlineStyleSingle = 2;
	public static final int xlUnderlineStyleSingleAccounting = 4;
}
