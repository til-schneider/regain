/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlArrangeStyle {

	public static final int xlArrangeStyleCascade = 7;
	public static final int xlArrangeStyleHorizontal = -4128;
	public static final int xlArrangeStyleTiled = 1;
	public static final int xlArrangeStyleVertical = -4166;
}
