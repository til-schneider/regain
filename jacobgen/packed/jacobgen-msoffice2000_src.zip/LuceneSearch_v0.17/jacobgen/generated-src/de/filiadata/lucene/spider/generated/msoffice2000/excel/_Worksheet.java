/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _Worksheet extends Dispatch {

	public static final String componentName = "Excel._Worksheet";

	public _Worksheet() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _Worksheet(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _Worksheet(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void copy(Variant before, Variant lastParam) {
		Dispatch.call(this, "Copy", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void copy(Variant before) {
		Dispatch.call(this, "Copy", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copy() {
		Dispatch.call(this, "Copy");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCodeName() {
		return Dispatch.get(this, "CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_CodeName() {
		return Dispatch.get(this, "_CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void set_CodeName(String lastParam) {
		Dispatch.call(this, "_CodeName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIndex() {
		return Dispatch.get(this, "Index").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void move(Variant before, Variant lastParam) {
		Dispatch.call(this, "Move", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void move(Variant before) {
		Dispatch.call(this, "Move", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void move() {
		Dispatch.call(this, "Move");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getNext() {
		return Dispatch.get(this, "Next");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnDoubleClick() {
		return Dispatch.get(this, "OnDoubleClick").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnDoubleClick(String lastParam) {
		Dispatch.call(this, "OnDoubleClick", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetActivate() {
		return Dispatch.get(this, "OnSheetActivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetActivate(String lastParam) {
		Dispatch.call(this, "OnSheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetDeactivate() {
		return Dispatch.get(this, "OnSheetDeactivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetDeactivate(String lastParam) {
		Dispatch.call(this, "OnSheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PageSetup
	 */
	public PageSetup getPageSetup() {
		return new PageSetup(Dispatch.get(this, "PageSetup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPrevious() {
		return Dispatch.get(this, "Previous");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to) {
		Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from) {
		Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _PrintOut() {
		Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printPreview(Variant lastParam) {
		Dispatch.call(this, "PrintPreview", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printPreview() {
		Dispatch.call(this, "PrintPreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios, Variant lastParam) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects) {
		Dispatch.call(this, "Protect", password, drawingObjects);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 */
	public void protect(Variant password) {
		Dispatch.call(this, "Protect", password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void protect() {
		Dispatch.call(this, "Protect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectContents() {
		return Dispatch.get(this, "ProtectContents").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectDrawingObjects() {
		return Dispatch.get(this, "ProtectDrawingObjects").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectionMode() {
		return Dispatch.get(this, "ProtectionMode").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectScenarios() {
		return Dispatch.get(this, "ProtectScenarios").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage, Variant lastParam) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat) {
		Dispatch.call(this, "SaveAs", filename, fileFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 */
	public void saveAs(String filename) {
		Dispatch.call(this, "SaveAs", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void select(Variant lastParam) {
		Dispatch.call(this, "Select", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void select() {
		Dispatch.call(this, "Select");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void unprotect(Variant lastParam) {
		Dispatch.call(this, "Unprotect", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unprotect() {
		Dispatch.call(this, "Unprotect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getVisible() {
		return Dispatch.get(this, "Visible").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setVisible(int lastParam) {
		Dispatch.call(this, "Visible", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Shapes
	 */
	public Shapes getShapes() {
		return new Shapes(Dispatch.get(this, "Shapes").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTransitionExpEval() {
		return Dispatch.get(this, "TransitionExpEval").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTransitionExpEval(boolean lastParam) {
		Dispatch.call(this, "TransitionExpEval", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object arcs(Variant lastParam) {
		return Dispatch.call(this, "Arcs", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object arcs() {
		return Dispatch.call(this, "Arcs");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAutoFilterMode() {
		return Dispatch.get(this, "AutoFilterMode").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAutoFilterMode(boolean lastParam) {
		Dispatch.call(this, "AutoFilterMode", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setBackgroundPicture(String lastParam) {
		Dispatch.call(this, "SetBackgroundPicture", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object buttons(Variant lastParam) {
		return Dispatch.call(this, "Buttons", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object buttons() {
		return Dispatch.call(this, "Buttons");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculate() {
		Dispatch.call(this, "Calculate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableCalculation() {
		return Dispatch.get(this, "EnableCalculation").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableCalculation(boolean lastParam) {
		Dispatch.call(this, "EnableCalculation", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCells() {
		return new Range(Dispatch.get(this, "Cells").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object chartObjects(Variant lastParam) {
		return Dispatch.call(this, "ChartObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object chartObjects() {
		return Dispatch.call(this, "ChartObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object checkBoxes(Variant lastParam) {
		return Dispatch.call(this, "CheckBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object checkBoxes() {
		return Dispatch.call(this, "CheckBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant lastParam) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary) {
		Dispatch.call(this, "CheckSpelling", customDictionary);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void checkSpelling() {
		Dispatch.call(this, "CheckSpelling");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCircularReference() {
		return new Range(Dispatch.get(this, "CircularReference").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void clearArrows() {
		Dispatch.call(this, "ClearArrows");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getColumns() {
		return new Range(Dispatch.get(this, "Columns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getConsolidationFunction() {
		return Dispatch.get(this, "ConsolidationFunction").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getConsolidationOptions() {
		return Dispatch.get(this, "ConsolidationOptions");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getConsolidationSources() {
		return Dispatch.get(this, "ConsolidationSources");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayAutomaticPageBreaks() {
		return Dispatch.get(this, "DisplayAutomaticPageBreaks").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayAutomaticPageBreaks(boolean lastParam) {
		Dispatch.call(this, "DisplayAutomaticPageBreaks", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object drawings(Variant lastParam) {
		return Dispatch.call(this, "Drawings", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object drawings() {
		return Dispatch.call(this, "Drawings");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object drawingObjects(Variant lastParam) {
		return Dispatch.call(this, "DrawingObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object drawingObjects() {
		return Dispatch.call(this, "DrawingObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object dropDowns(Variant lastParam) {
		return Dispatch.call(this, "DropDowns", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object dropDowns() {
		return Dispatch.call(this, "DropDowns");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableAutoFilter() {
		return Dispatch.get(this, "EnableAutoFilter").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableAutoFilter(boolean lastParam) {
		Dispatch.call(this, "EnableAutoFilter", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getEnableSelection() {
		return Dispatch.get(this, "EnableSelection").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setEnableSelection(int lastParam) {
		Dispatch.call(this, "EnableSelection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableOutlining() {
		return Dispatch.get(this, "EnableOutlining").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableOutlining(boolean lastParam) {
		Dispatch.call(this, "EnableOutlining", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnablePivotTable() {
		return Dispatch.get(this, "EnablePivotTable").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnablePivotTable(boolean lastParam) {
		Dispatch.call(this, "EnablePivotTable", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant evaluate(Variant lastParam) {
		return Dispatch.call(this, "Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Evaluate(Variant lastParam) {
		return Dispatch.call(this, "_Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getFilterMode() {
		return Dispatch.get(this, "FilterMode").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resetAllPageBreaks() {
		Dispatch.call(this, "ResetAllPageBreaks");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object groupBoxes(Variant lastParam) {
		return Dispatch.call(this, "GroupBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object groupBoxes() {
		return Dispatch.call(this, "GroupBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object groupObjects(Variant lastParam) {
		return Dispatch.call(this, "GroupObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object groupObjects() {
		return Dispatch.call(this, "GroupObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object labels(Variant lastParam) {
		return Dispatch.call(this, "Labels", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object labels() {
		return Dispatch.call(this, "Labels");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object lines(Variant lastParam) {
		return Dispatch.call(this, "Lines", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object lines() {
		return Dispatch.call(this, "Lines");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object listBoxes(Variant lastParam) {
		return Dispatch.call(this, "ListBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object listBoxes() {
		return Dispatch.call(this, "ListBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Names
	 */
	public Names getNames() {
		return new Names(Dispatch.get(this, "Names").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object oLEObjects(Variant lastParam) {
		return Dispatch.call(this, "OLEObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object oLEObjects() {
		return Dispatch.call(this, "OLEObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnCalculate() {
		return Dispatch.get(this, "OnCalculate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnCalculate(String lastParam) {
		Dispatch.call(this, "OnCalculate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnData() {
		return Dispatch.get(this, "OnData").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnData(String lastParam) {
		Dispatch.call(this, "OnData", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnEntry() {
		return Dispatch.get(this, "OnEntry").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnEntry(String lastParam) {
		Dispatch.call(this, "OnEntry", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object optionButtons(Variant lastParam) {
		return Dispatch.call(this, "OptionButtons", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object optionButtons() {
		return Dispatch.call(this, "OptionButtons");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Outline
	 */
	public Outline getOutline() {
		return new Outline(Dispatch.get(this, "Outline").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object ovals(Variant lastParam) {
		return Dispatch.call(this, "Ovals", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object ovals() {
		return Dispatch.call(this, "Ovals");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void paste(Variant destination, Variant lastParam) {
		Dispatch.call(this, "Paste", destination, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param destination an input-parameter of type Variant
	 */
	public void paste(Variant destination) {
		Dispatch.call(this, "Paste", destination);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void paste() {
		Dispatch.call(this, "Paste");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 * @param link an input-parameter of type Variant
	 * @param displayAsIcon an input-parameter of type Variant
	 * @param iconFileName an input-parameter of type Variant
	 * @param iconIndex an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format, Variant link, Variant displayAsIcon, Variant iconFileName, Variant iconIndex, Variant lastParam) {
		Dispatch.call(this, "PasteSpecial", format, link, displayAsIcon, iconFileName, iconIndex, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 * @param link an input-parameter of type Variant
	 * @param displayAsIcon an input-parameter of type Variant
	 * @param iconFileName an input-parameter of type Variant
	 * @param iconIndex an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format, Variant link, Variant displayAsIcon, Variant iconFileName, Variant iconIndex) {
		Dispatch.call(this, "PasteSpecial", format, link, displayAsIcon, iconFileName, iconIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 * @param link an input-parameter of type Variant
	 * @param displayAsIcon an input-parameter of type Variant
	 * @param iconFileName an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format, Variant link, Variant displayAsIcon, Variant iconFileName) {
		Dispatch.call(this, "PasteSpecial", format, link, displayAsIcon, iconFileName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 * @param link an input-parameter of type Variant
	 * @param displayAsIcon an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format, Variant link, Variant displayAsIcon) {
		Dispatch.call(this, "PasteSpecial", format, link, displayAsIcon);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 * @param link an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format, Variant link) {
		Dispatch.call(this, "PasteSpecial", format, link);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param format an input-parameter of type Variant
	 */
	public void pasteSpecial(Variant format) {
		Dispatch.call(this, "PasteSpecial", format);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void pasteSpecial() {
		Dispatch.call(this, "PasteSpecial");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object pictures(Variant lastParam) {
		return Dispatch.call(this, "Pictures", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object pictures() {
		return Dispatch.call(this, "Pictures");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object pivotTables(Variant lastParam) {
		return Dispatch.call(this, "PivotTables", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object pivotTables() {
		return Dispatch.call(this, "PivotTables");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData, Variant lastParam) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage) {
		return new PivotTable(Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType, Variant sourceData) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType, sourceData).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard(Variant sourceType) {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard", sourceType).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotTable
	 */
	public PivotTable pivotTableWizard() {
		return new PivotTable(Dispatch.call(this, "PivotTableWizard").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1, Variant lastParam) {
		return new Range(Dispatch.call(this, "Range", cell1, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1) {
		return new Range(Dispatch.call(this, "Range", cell1).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object rectangles(Variant lastParam) {
		return Dispatch.call(this, "Rectangles", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object rectangles() {
		return Dispatch.call(this, "Rectangles");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getRows() {
		return new Range(Dispatch.get(this, "Rows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object scenarios(Variant lastParam) {
		return Dispatch.call(this, "Scenarios", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object scenarios() {
		return Dispatch.call(this, "Scenarios");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getScrollArea() {
		return Dispatch.get(this, "ScrollArea").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setScrollArea(String lastParam) {
		Dispatch.call(this, "ScrollArea", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object scrollBars(Variant lastParam) {
		return Dispatch.call(this, "ScrollBars", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object scrollBars() {
		return Dispatch.call(this, "ScrollBars");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void showAllData() {
		Dispatch.call(this, "ShowAllData");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void showDataForm() {
		Dispatch.call(this, "ShowDataForm");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object spinners(Variant lastParam) {
		return Dispatch.call(this, "Spinners", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object spinners() {
		return Dispatch.call(this, "Spinners");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getStandardHeight() {
		return Dispatch.get(this, "StandardHeight").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getStandardWidth() {
		return Dispatch.get(this, "StandardWidth").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setStandardWidth(double lastParam) {
		Dispatch.call(this, "StandardWidth", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object textBoxes(Variant lastParam) {
		return Dispatch.call(this, "TextBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object textBoxes() {
		return Dispatch.call(this, "TextBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTransitionFormEntry() {
		return Dispatch.get(this, "TransitionFormEntry").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTransitionFormEntry(boolean lastParam) {
		Dispatch.call(this, "TransitionFormEntry", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getType() {
		return Dispatch.get(this, "Type").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getUsedRange() {
		return new Range(Dispatch.get(this, "UsedRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type HPageBreaks
	 */
	public HPageBreaks getHPageBreaks() {
		return new HPageBreaks(Dispatch.get(this, "HPageBreaks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type VPageBreaks
	 */
	public VPageBreaks getVPageBreaks() {
		return new VPageBreaks(Dispatch.get(this, "VPageBreaks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type QueryTables
	 */
	public QueryTables getQueryTables() {
		return new QueryTables(Dispatch.get(this, "QueryTables").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayPageBreaks() {
		return Dispatch.get(this, "DisplayPageBreaks").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayPageBreaks(boolean lastParam) {
		Dispatch.call(this, "DisplayPageBreaks", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Comments
	 */
	public Comments getComments() {
		return new Comments(Dispatch.get(this, "Comments").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Hyperlinks
	 */
	public Hyperlinks getHyperlinks() {
		return new Hyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void clearCircles() {
		Dispatch.call(this, "ClearCircles");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void circleInvalid() {
		Dispatch.call(this, "CircleInvalid");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int get_DisplayRightToLeft() {
		return Dispatch.get(this, "_DisplayRightToLeft").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void set_DisplayRightToLeft(int lastParam) {
		Dispatch.call(this, "_DisplayRightToLeft", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type AutoFilter
	 */
	public AutoFilter getAutoFilter() {
		return new AutoFilter(Dispatch.get(this, "AutoFilter").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayRightToLeft() {
		return Dispatch.get(this, "DisplayRightToLeft").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayRightToLeft(boolean lastParam) {
		Dispatch.call(this, "DisplayRightToLeft", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.Scripts
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.Scripts getScripts() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.Scripts(Dispatch.get(this, "Scripts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate, Variant lastParam) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to) {
		Dispatch.call(this, "PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void printOut(Variant from) {
		Dispatch.call(this, "PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printOut() {
		Dispatch.call(this, "PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param spellLang an input-parameter of type Variant
	 * @param ignoreFinalYaa an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant spellLang, Variant ignoreFinalYaa, Variant lastParam) {
		Dispatch.call(this, "_CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, spellLang, ignoreFinalYaa, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param spellLang an input-parameter of type Variant
	 * @param ignoreFinalYaa an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant spellLang, Variant ignoreFinalYaa) {
		Dispatch.call(this, "_CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, spellLang, ignoreFinalYaa);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param spellLang an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant spellLang) {
		Dispatch.call(this, "_CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, spellLang);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest) {
		Dispatch.call(this, "_CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary, Variant ignoreUppercase) {
		Dispatch.call(this, "_CheckSpelling", customDictionary, ignoreUppercase);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 */
	public void _CheckSpelling(Variant customDictionary) {
		Dispatch.call(this, "_CheckSpelling", customDictionary);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _CheckSpelling() {
		Dispatch.call(this, "_CheckSpelling");
	}

}
