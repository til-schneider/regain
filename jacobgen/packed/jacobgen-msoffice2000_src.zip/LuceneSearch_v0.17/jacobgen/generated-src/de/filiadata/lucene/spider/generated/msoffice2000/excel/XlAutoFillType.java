/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlAutoFillType {

	public static final int xlFillCopy = 1;
	public static final int xlFillDays = 5;
	public static final int xlFillDefault = 0;
	public static final int xlFillFormats = 3;
	public static final int xlFillMonths = 7;
	public static final int xlFillSeries = 2;
	public static final int xlFillValues = 4;
	public static final int xlFillWeekdays = 6;
	public static final int xlFillYears = 8;
	public static final int xlGrowthTrend = 10;
	public static final int xlLinearTrend = 9;
}
