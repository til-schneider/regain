/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlCVError {

	public static final int xlErrDiv0 = 2007;
	public static final int xlErrNA = 2042;
	public static final int xlErrName = 2029;
	public static final int xlErrNull = 2000;
	public static final int xlErrNum = 2036;
	public static final int xlErrRef = 2023;
	public static final int xlErrValue = 2015;
}
