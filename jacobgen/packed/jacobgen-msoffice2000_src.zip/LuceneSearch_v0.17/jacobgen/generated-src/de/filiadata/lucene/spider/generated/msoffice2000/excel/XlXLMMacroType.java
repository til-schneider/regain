/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlXLMMacroType {

	public static final int xlCommand = 2;
	public static final int xlFunction = 1;
	public static final int xlNotXLM = 3;
}
