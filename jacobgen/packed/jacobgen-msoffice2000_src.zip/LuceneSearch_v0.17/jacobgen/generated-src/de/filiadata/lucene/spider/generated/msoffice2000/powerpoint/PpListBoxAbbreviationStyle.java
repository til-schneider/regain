/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpListBoxAbbreviationStyle {

	public static final int ppListBoxAbbreviationNone = 0;
	public static final int ppListBoxAbbreviationTruncation = 1;
	public static final int ppListBoxAbbreviationTruncationWithEllipsis = 2;
	public static final int ppListBoxAbbreviationFileNames = 3;
}
