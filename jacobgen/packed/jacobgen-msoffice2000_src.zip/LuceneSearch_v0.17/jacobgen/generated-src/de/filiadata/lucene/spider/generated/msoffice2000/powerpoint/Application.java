/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class Application extends _Application {

	public static final String componentName = "PowerPoint.Application";

	public Application() {
		super(componentName);
	}

	public Application(Dispatch d) {
		super(d);
	}
}
