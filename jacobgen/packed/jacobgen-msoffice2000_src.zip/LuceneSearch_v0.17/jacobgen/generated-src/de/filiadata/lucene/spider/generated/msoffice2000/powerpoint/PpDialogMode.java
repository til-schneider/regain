/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpDialogMode {

	public static final int ppDialogModeMixed = -2;
	public static final int ppDialogModeless = 0;
	public static final int ppDialogModal = 1;
}
