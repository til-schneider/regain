/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlWindowType {

	public static final int xlChartAsWindow = 5;
	public static final int xlChartInPlace = 4;
	public static final int xlClipboard = 3;
	public static final int xlInfo = -4129;
	public static final int xlWorkbook = 1;
}
