/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface xlColumnDataType {

	public static final int xlGeneralFormat = 1;
	public static final int xlTextFormat = 2;
	public static final int xlMDYFormat = 3;
	public static final int xlDMYFormat = 4;
	public static final int xlYMDFormat = 5;
	public static final int xlMYDFormat = 6;
	public static final int xlDYMFormat = 7;
	public static final int xlYDMFormat = 8;
	public static final int xlSkipColumn = 9;
	public static final int xlEMDFormat = 10;
}
