/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlColorIndex {

	public static final int xlColorIndexAutomatic = -4105;
	public static final int xlColorIndexNone = -4142;
}
