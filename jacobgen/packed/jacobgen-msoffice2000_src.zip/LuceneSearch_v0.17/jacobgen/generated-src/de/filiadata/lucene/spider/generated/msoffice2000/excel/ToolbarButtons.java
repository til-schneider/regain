/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class ToolbarButtons extends Dispatch {

	public static final String componentName = "Excel.ToolbarButtons";

	public ToolbarButtons() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ToolbarButtons(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ToolbarButtons(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @param pushed an input-parameter of type Variant
	 * @param enabled an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction, Variant pushed, Variant enabled, Variant statusBar, Variant helpFile, Variant lastParam) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction, pushed, enabled, statusBar, helpFile, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @param pushed an input-parameter of type Variant
	 * @param enabled an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction, Variant pushed, Variant enabled, Variant statusBar, Variant helpFile) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction, pushed, enabled, statusBar, helpFile).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @param pushed an input-parameter of type Variant
	 * @param enabled an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction, Variant pushed, Variant enabled, Variant statusBar) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction, pushed, enabled, statusBar).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @param pushed an input-parameter of type Variant
	 * @param enabled an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction, Variant pushed, Variant enabled) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction, pushed, enabled).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @param pushed an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction, Variant pushed) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction, pushed).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param onAction an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before, Variant onAction) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before, onAction).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button, Variant before) {
		return new ToolbarButton(Dispatch.call(this, "Add", button, before).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param button an input-parameter of type Variant
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add(Variant button) {
		return new ToolbarButton(Dispatch.call(this, "Add", button).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton add() {
		return new ToolbarButton(Dispatch.call(this, "Add").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton getItem(int lastParam) {
		return new ToolbarButton(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type ToolbarButton
	 */
	public ToolbarButton get_Default(int lastParam) {
		return new ToolbarButton(Dispatch.call(this, "_Default", new Variant(lastParam)).toDispatch());
	}

}
