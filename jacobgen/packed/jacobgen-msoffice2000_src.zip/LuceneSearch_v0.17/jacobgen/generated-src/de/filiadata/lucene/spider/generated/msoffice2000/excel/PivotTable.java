/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class PivotTable extends Dispatch {

	public static final String componentName = "Excel.PivotTable";

	public PivotTable() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PivotTable(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PivotTable(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 * @param pageFields an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant addFields(Variant rowFields, Variant columnFields, Variant pageFields, Variant lastParam) {
		return Dispatch.call(this, "AddFields", rowFields, columnFields, pageFields, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 * @param pageFields an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant addFields(Variant rowFields, Variant columnFields, Variant pageFields) {
		return Dispatch.call(this, "AddFields", rowFields, columnFields, pageFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @param columnFields an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant addFields(Variant rowFields, Variant columnFields) {
		return Dispatch.call(this, "AddFields", rowFields, columnFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param rowFields an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant addFields(Variant rowFields) {
		return Dispatch.call(this, "AddFields", rowFields);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant addFields() {
		return Dispatch.call(this, "AddFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getColumnFields(Variant lastParam) {
		return Dispatch.call(this, "ColumnFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getColumnFields() {
		return Dispatch.get(this, "ColumnFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getColumnGrand() {
		return Dispatch.get(this, "ColumnGrand").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setColumnGrand(boolean lastParam) {
		Dispatch.call(this, "ColumnGrand", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getColumnRange() {
		return new Range(Dispatch.get(this, "ColumnRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant showPages(Variant lastParam) {
		return Dispatch.call(this, "ShowPages", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant showPages() {
		return Dispatch.call(this, "ShowPages");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDataBodyRange() {
		return new Range(Dispatch.get(this, "DataBodyRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getDataFields(Variant lastParam) {
		return Dispatch.call(this, "DataFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getDataFields() {
		return Dispatch.get(this, "DataFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getDataLabelRange() {
		return new Range(Dispatch.get(this, "DataLabelRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_Default() {
		return Dispatch.get(this, "_Default").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void set_Default(String lastParam) {
		Dispatch.call(this, "_Default", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasAutoFormat() {
		return Dispatch.get(this, "HasAutoFormat").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasAutoFormat(boolean lastParam) {
		Dispatch.call(this, "HasAutoFormat", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getHiddenFields(Variant lastParam) {
		return Dispatch.call(this, "HiddenFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getHiddenFields() {
		return Dispatch.get(this, "HiddenFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getInnerDetail() {
		return Dispatch.get(this, "InnerDetail").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setInnerDetail(String lastParam) {
		Dispatch.call(this, "InnerDetail", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getPageFields(Variant lastParam) {
		return Dispatch.call(this, "PageFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPageFields() {
		return Dispatch.get(this, "PageFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getPageRange() {
		return new Range(Dispatch.get(this, "PageRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getPageRangeCells() {
		return new Range(Dispatch.get(this, "PageRangeCells").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object pivotFields(Variant lastParam) {
		return Dispatch.call(this, "PivotFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object pivotFields() {
		return Dispatch.call(this, "PivotFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type java.util.Date
	 */
	public java.util.Date getRefreshDate() {
		return comDateToJavaDate(Dispatch.get(this, "RefreshDate").toDate());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getRefreshName() {
		return Dispatch.get(this, "RefreshName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean refreshTable() {
		return Dispatch.call(this, "RefreshTable").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getRowFields(Variant lastParam) {
		return Dispatch.call(this, "RowFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getRowFields() {
		return Dispatch.get(this, "RowFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRowGrand() {
		return Dispatch.get(this, "RowGrand").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRowGrand(boolean lastParam) {
		Dispatch.call(this, "RowGrand", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getRowRange() {
		return new Range(Dispatch.get(this, "RowRange").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSaveData() {
		return Dispatch.get(this, "SaveData").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSaveData(boolean lastParam) {
		Dispatch.call(this, "SaveData", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSourceData() {
		return Dispatch.get(this, "SourceData");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setSourceData(Variant lastParam) {
		Dispatch.call(this, "SourceData", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getTableRange1() {
		return new Range(Dispatch.get(this, "TableRange1").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getTableRange2() {
		return new Range(Dispatch.get(this, "TableRange2").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getValue() {
		return Dispatch.get(this, "Value").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setValue(String lastParam) {
		Dispatch.call(this, "Value", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getVisibleFields(Variant lastParam) {
		return Dispatch.call(this, "VisibleFields", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getVisibleFields() {
		return Dispatch.get(this, "VisibleFields");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCacheIndex() {
		return Dispatch.get(this, "CacheIndex").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCacheIndex(int lastParam) {
		Dispatch.call(this, "CacheIndex", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type CalculatedFields
	 */
	public CalculatedFields calculatedFields() {
		return new CalculatedFields(Dispatch.call(this, "CalculatedFields").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayErrorString() {
		return Dispatch.get(this, "DisplayErrorString").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayErrorString(boolean lastParam) {
		Dispatch.call(this, "DisplayErrorString", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayNullString() {
		return Dispatch.get(this, "DisplayNullString").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayNullString(boolean lastParam) {
		Dispatch.call(this, "DisplayNullString", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableDrilldown() {
		return Dispatch.get(this, "EnableDrilldown").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableDrilldown(boolean lastParam) {
		Dispatch.call(this, "EnableDrilldown", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableFieldDialog() {
		return Dispatch.get(this, "EnableFieldDialog").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableFieldDialog(boolean lastParam) {
		Dispatch.call(this, "EnableFieldDialog", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableWizard() {
		return Dispatch.get(this, "EnableWizard").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableWizard(boolean lastParam) {
		Dispatch.call(this, "EnableWizard", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getErrorString() {
		return Dispatch.get(this, "ErrorString").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setErrorString(String lastParam) {
		Dispatch.call(this, "ErrorString", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type double
	 */
	public double getData(String lastParam) {
		return Dispatch.call(this, "GetData", lastParam).toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void listFormulas() {
		Dispatch.call(this, "ListFormulas");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getManualUpdate() {
		return Dispatch.get(this, "ManualUpdate").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setManualUpdate(boolean lastParam) {
		Dispatch.call(this, "ManualUpdate", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMergeLabels() {
		return Dispatch.get(this, "MergeLabels").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setMergeLabels(boolean lastParam) {
		Dispatch.call(this, "MergeLabels", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getNullString() {
		return Dispatch.get(this, "NullString").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setNullString(String lastParam) {
		Dispatch.call(this, "NullString", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotCache
	 */
	public PivotCache pivotCache() {
		return new PivotCache(Dispatch.call(this, "PivotCache").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotFormulas
	 */
	public PivotFormulas getPivotFormulas() {
		return new PivotFormulas(Dispatch.get(this, "PivotFormulas").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData, Variant lastParam) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType) {
		Dispatch.call(this, "PivotTableWizard", sourceType);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void pivotTableWizard() {
		Dispatch.call(this, "PivotTableWizard");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSubtotalHiddenPageItems() {
		return Dispatch.get(this, "SubtotalHiddenPageItems").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSubtotalHiddenPageItems(boolean lastParam) {
		Dispatch.call(this, "SubtotalHiddenPageItems", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getPageFieldOrder() {
		return Dispatch.get(this, "PageFieldOrder").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setPageFieldOrder(int lastParam) {
		Dispatch.call(this, "PageFieldOrder", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPageFieldStyle() {
		return Dispatch.get(this, "PageFieldStyle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setPageFieldStyle(String lastParam) {
		Dispatch.call(this, "PageFieldStyle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getPageFieldWrapCount() {
		return Dispatch.get(this, "PageFieldWrapCount").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setPageFieldWrapCount(int lastParam) {
		Dispatch.call(this, "PageFieldWrapCount", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPreserveFormatting() {
		return Dispatch.get(this, "PreserveFormatting").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPreserveFormatting(boolean lastParam) {
		Dispatch.call(this, "PreserveFormatting", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param lastParam an input-parameter of type int
	 */
	public void pivotSelect(String name, int lastParam) {
		Dispatch.call(this, "PivotSelect", name, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 */
	public void pivotSelect(String name) {
		Dispatch.call(this, "PivotSelect", name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPivotSelection() {
		return Dispatch.get(this, "PivotSelection").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setPivotSelection(String lastParam) {
		Dispatch.call(this, "PivotSelection", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getSelectionMode() {
		return Dispatch.get(this, "SelectionMode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setSelectionMode(int lastParam) {
		Dispatch.call(this, "SelectionMode", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTableStyle() {
		return Dispatch.get(this, "TableStyle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTableStyle(String lastParam) {
		Dispatch.call(this, "TableStyle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTag() {
		return Dispatch.get(this, "Tag").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTag(String lastParam) {
		Dispatch.call(this, "Tag", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void update() {
		Dispatch.call(this, "Update");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getVacatedStyle() {
		return Dispatch.get(this, "VacatedStyle").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setVacatedStyle(String lastParam) {
		Dispatch.call(this, "VacatedStyle", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void format(int lastParam) {
		Dispatch.call(this, "Format", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPrintTitles() {
		return Dispatch.get(this, "PrintTitles").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPrintTitles(boolean lastParam) {
		Dispatch.call(this, "PrintTitles", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type CubeFields
	 */
	public CubeFields getCubeFields() {
		return new CubeFields(Dispatch.get(this, "CubeFields").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getGrandTotalName() {
		return Dispatch.get(this, "GrandTotalName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setGrandTotalName(String lastParam) {
		Dispatch.call(this, "GrandTotalName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSmallGrid() {
		return Dispatch.get(this, "SmallGrid").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSmallGrid(boolean lastParam) {
		Dispatch.call(this, "SmallGrid", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRepeatItemsOnEachPrintedPage() {
		return Dispatch.get(this, "RepeatItemsOnEachPrintedPage").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRepeatItemsOnEachPrintedPage(boolean lastParam) {
		Dispatch.call(this, "RepeatItemsOnEachPrintedPage", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTotalsAnnotation() {
		return Dispatch.get(this, "TotalsAnnotation").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTotalsAnnotation(boolean lastParam) {
		Dispatch.call(this, "TotalsAnnotation", new Variant(lastParam));
	}

	static long zoneOffset	= java.util.Calendar.getInstance().get(java.util.Calendar.ZONE_OFFSET);

	static java.util.Date comDateToJavaDate(double comDate) {
		comDate = comDate - 25569D;
		long millis = Math.round(86400000L * comDate) - zoneOffset;

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(new java.util.Date(millis));
		millis -= cal.get(cal.DST_OFFSET);

		return new java.util.Date(millis);
	}

	static double javaDateToComDate(java.util.Date javaDate) {

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(javaDate);
		long gmtOffset = (cal.get(cal.ZONE_OFFSET) + cal.get(cal.DST_OFFSET));

		long millis = javaDate.getTime() + gmtOffset;
		return 25569D+millis/86400000D;
	}

}
