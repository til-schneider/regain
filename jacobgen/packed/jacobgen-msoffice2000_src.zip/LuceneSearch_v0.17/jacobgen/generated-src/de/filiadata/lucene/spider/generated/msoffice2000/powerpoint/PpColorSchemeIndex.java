/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpColorSchemeIndex {

	public static final int ppSchemeColorMixed = -2;
	public static final int ppNotSchemeColor = 0;
	public static final int ppBackground = 1;
	public static final int ppForeground = 2;
	public static final int ppShadow = 3;
	public static final int ppTitle = 4;
	public static final int ppFill = 5;
	public static final int ppAccent1 = 6;
	public static final int ppAccent2 = 7;
	public static final int ppAccent3 = 8;
}
