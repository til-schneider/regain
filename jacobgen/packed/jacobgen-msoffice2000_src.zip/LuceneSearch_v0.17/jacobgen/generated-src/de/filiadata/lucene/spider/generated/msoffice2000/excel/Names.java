/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Names extends Dispatch {

	public static final String componentName = "Excel.Names";

	public Names() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Names(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Names(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param nameLocal an input-parameter of type Variant
	 * @param refersToLocal an input-parameter of type Variant
	 * @param categoryLocal an input-parameter of type Variant
	 * @param refersToR1C1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category, Variant nameLocal, Variant refersToLocal, Variant categoryLocal, Variant refersToR1C1, Variant lastParam) {
		return new Name(Dispatch.callN(this, "Add", new Object[] { name, refersTo, visible, macroType, shortcutKey, category, nameLocal, refersToLocal, categoryLocal, refersToR1C1, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param nameLocal an input-parameter of type Variant
	 * @param refersToLocal an input-parameter of type Variant
	 * @param categoryLocal an input-parameter of type Variant
	 * @param refersToR1C1 an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category, Variant nameLocal, Variant refersToLocal, Variant categoryLocal, Variant refersToR1C1) {
		return new Name(Dispatch.callN(this, "Add", new Object[] { name, refersTo, visible, macroType, shortcutKey, category, nameLocal, refersToLocal, categoryLocal, refersToR1C1}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param nameLocal an input-parameter of type Variant
	 * @param refersToLocal an input-parameter of type Variant
	 * @param categoryLocal an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category, Variant nameLocal, Variant refersToLocal, Variant categoryLocal) {
		return new Name(Dispatch.callN(this, "Add", new Object[] { name, refersTo, visible, macroType, shortcutKey, category, nameLocal, refersToLocal, categoryLocal}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param nameLocal an input-parameter of type Variant
	 * @param refersToLocal an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category, Variant nameLocal, Variant refersToLocal) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible, macroType, shortcutKey, category, nameLocal, refersToLocal).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param nameLocal an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category, Variant nameLocal) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible, macroType, shortcutKey, category, nameLocal).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey, Variant category) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible, macroType, shortcutKey, category).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType, Variant shortcutKey) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible, macroType, shortcutKey).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @param macroType an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible, Variant macroType) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible, macroType).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @param visible an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo, Variant visible) {
		return new Name(Dispatch.call(this, "Add", name, refersTo, visible).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param refersTo an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name, Variant refersTo) {
		return new Name(Dispatch.call(this, "Add", name, refersTo).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name add(Variant name) {
		return new Name(Dispatch.call(this, "Add", name).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Name
	 */
	public Name add() {
		return new Name(Dispatch.call(this, "Add").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param indexLocal an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name item(Variant index, Variant indexLocal, Variant lastParam) {
		return new Name(Dispatch.call(this, "Item", index, indexLocal, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param indexLocal an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name item(Variant index, Variant indexLocal) {
		return new Name(Dispatch.call(this, "Item", index, indexLocal).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name item(Variant index) {
		return new Name(Dispatch.call(this, "Item", index).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Name
	 */
	public Name item() {
		return new Name(Dispatch.call(this, "Item").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param indexLocal an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name _Default(Variant index, Variant indexLocal, Variant lastParam) {
		return new Name(Dispatch.call(this, "_Default", index, indexLocal, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param indexLocal an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name _Default(Variant index, Variant indexLocal) {
		return new Name(Dispatch.call(this, "_Default", index, indexLocal).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @return the result is of type Name
	 */
	public Name _Default(Variant index) {
		return new Name(Dispatch.call(this, "_Default", index).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Name
	 */
	public Name _Default() {
		return new Name(Dispatch.call(this, "_Default").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

}
