/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFindLookIn {

	public static final int xlFormulas = -4123;
	public static final int xlComments = -4144;
	public static final int xlValues = -4163;
}
