/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpMediaType {

	public static final int ppMediaTypeMixed = -2;
	public static final int ppMediaTypeOther = 1;
	public static final int ppMediaTypeSound = 2;
	public static final int ppMediaTypeMovie = 3;
}
