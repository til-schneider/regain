/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFileAccess {

	public static final int xlReadOnly = 3;
	public static final int xlReadWrite = 2;
}
