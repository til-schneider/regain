/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFillWith {

	public static final int xlFillWithAll = -4104;
	public static final int xlFillWithContents = 2;
	public static final int xlFillWithFormats = -4122;
}
