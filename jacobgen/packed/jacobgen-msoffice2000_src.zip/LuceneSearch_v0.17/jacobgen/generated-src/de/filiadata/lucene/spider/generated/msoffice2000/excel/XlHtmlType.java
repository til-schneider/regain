/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlHtmlType {

	public static final int xlHtmlStatic = 0;
	public static final int xlHtmlCalc = 1;
	public static final int xlHtmlList = 2;
	public static final int xlHtmlChart = 3;
}
