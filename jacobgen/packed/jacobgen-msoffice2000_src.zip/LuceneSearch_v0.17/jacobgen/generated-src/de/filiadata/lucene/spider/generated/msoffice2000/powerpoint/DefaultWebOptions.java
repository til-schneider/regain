/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class DefaultWebOptions extends Dispatch {

	public static final String componentName = "PowerPoint.DefaultWebOptions";

	public DefaultWebOptions() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public DefaultWebOptions(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public DefaultWebOptions(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIncludeNavigation() {
		return Dispatch.get(this, "IncludeNavigation").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setIncludeNavigation(int lastParam) {
		Dispatch.call(this, "IncludeNavigation", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getFrameColors() {
		return Dispatch.get(this, "FrameColors").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setFrameColors(int lastParam) {
		Dispatch.call(this, "FrameColors", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getResizeGraphics() {
		return Dispatch.get(this, "ResizeGraphics").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setResizeGraphics(int lastParam) {
		Dispatch.call(this, "ResizeGraphics", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getShowSlideAnimation() {
		return Dispatch.get(this, "ShowSlideAnimation").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setShowSlideAnimation(int lastParam) {
		Dispatch.call(this, "ShowSlideAnimation", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getOrganizeInFolder() {
		return Dispatch.get(this, "OrganizeInFolder").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setOrganizeInFolder(int lastParam) {
		Dispatch.call(this, "OrganizeInFolder", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getUseLongFileNames() {
		return Dispatch.get(this, "UseLongFileNames").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setUseLongFileNames(int lastParam) {
		Dispatch.call(this, "UseLongFileNames", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRelyOnVML() {
		return Dispatch.get(this, "RelyOnVML").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setRelyOnVML(int lastParam) {
		Dispatch.call(this, "RelyOnVML", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getAllowPNG() {
		return Dispatch.get(this, "AllowPNG").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setAllowPNG(int lastParam) {
		Dispatch.call(this, "AllowPNG", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getScreenSize() {
		return Dispatch.get(this, "ScreenSize").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setScreenSize(int lastParam) {
		Dispatch.call(this, "ScreenSize", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getEncoding() {
		return Dispatch.get(this, "Encoding").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setEncoding(int lastParam) {
		Dispatch.call(this, "Encoding", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getUpdateLinksOnSave() {
		return Dispatch.get(this, "UpdateLinksOnSave").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setUpdateLinksOnSave(int lastParam) {
		Dispatch.call(this, "UpdateLinksOnSave", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCheckIfOfficeIsHTMLEditor() {
		return Dispatch.get(this, "CheckIfOfficeIsHTMLEditor").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCheckIfOfficeIsHTMLEditor(int lastParam) {
		Dispatch.call(this, "CheckIfOfficeIsHTMLEditor", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getAlwaysSaveInDefaultEncoding() {
		return Dispatch.get(this, "AlwaysSaveInDefaultEncoding").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setAlwaysSaveInDefaultEncoding(int lastParam) {
		Dispatch.call(this, "AlwaysSaveInDefaultEncoding", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.WebPageFonts
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.WebPageFonts getFonts() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.WebPageFonts(Dispatch.get(this, "Fonts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getFolderSuffix() {
		return Dispatch.get(this, "FolderSuffix").toString();
	}

}
