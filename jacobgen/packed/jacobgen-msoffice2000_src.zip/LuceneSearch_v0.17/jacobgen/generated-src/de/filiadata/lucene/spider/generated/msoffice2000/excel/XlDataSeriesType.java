/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDataSeriesType {

	public static final int xlAutoFill = 4;
	public static final int xlChronological = 3;
	public static final int xlGrowth = 2;
	public static final int xlDataSeriesLinear = -4132;
}
