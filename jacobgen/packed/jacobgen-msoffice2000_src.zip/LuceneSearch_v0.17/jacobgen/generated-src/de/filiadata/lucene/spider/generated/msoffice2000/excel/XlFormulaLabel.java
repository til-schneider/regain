/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFormulaLabel {

	public static final int xlNoLabels = -4142;
	public static final int xlRowLabels = 1;
	public static final int xlColumnLabels = 2;
	public static final int xlMixedLabels = 3;
}
