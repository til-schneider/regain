/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class PivotCache extends Dispatch {

	public static final String componentName = "Excel.PivotCache";

	public PivotCache() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public PivotCache(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public PivotCache(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getBackgroundQuery() {
		return Dispatch.get(this, "BackgroundQuery").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setBackgroundQuery(boolean lastParam) {
		Dispatch.call(this, "BackgroundQuery", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getConnection() {
		return Dispatch.get(this, "Connection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setConnection(Variant lastParam) {
		Dispatch.call(this, "Connection", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableRefresh() {
		return Dispatch.get(this, "EnableRefresh").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableRefresh(boolean lastParam) {
		Dispatch.call(this, "EnableRefresh", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIndex() {
		return Dispatch.get(this, "Index").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMemoryUsed() {
		return Dispatch.get(this, "MemoryUsed").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getOptimizeCache() {
		return Dispatch.get(this, "OptimizeCache").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setOptimizeCache(boolean lastParam) {
		Dispatch.call(this, "OptimizeCache", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRecordCount() {
		return Dispatch.get(this, "RecordCount").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void refresh() {
		Dispatch.call(this, "Refresh");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type java.util.Date
	 */
	public java.util.Date getRefreshDate() {
		return comDateToJavaDate(Dispatch.get(this, "RefreshDate").toDate());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getRefreshName() {
		return Dispatch.get(this, "RefreshName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRefreshOnFileOpen() {
		return Dispatch.get(this, "RefreshOnFileOpen").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRefreshOnFileOpen(boolean lastParam) {
		Dispatch.call(this, "RefreshOnFileOpen", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSql() {
		return Dispatch.get(this, "Sql");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setSql(Variant lastParam) {
		Dispatch.call(this, "Sql", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSavePassword() {
		return Dispatch.get(this, "SavePassword").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSavePassword(boolean lastParam) {
		Dispatch.call(this, "SavePassword", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSourceData() {
		return Dispatch.get(this, "SourceData");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setSourceData(Variant lastParam) {
		Dispatch.call(this, "SourceData", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getCommandText() {
		return Dispatch.get(this, "CommandText");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setCommandText(Variant lastParam) {
		Dispatch.call(this, "CommandText", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCommandType() {
		return Dispatch.get(this, "CommandType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCommandType(int lastParam) {
		Dispatch.call(this, "CommandType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getQueryType() {
		return Dispatch.get(this, "QueryType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMaintainConnection() {
		return Dispatch.get(this, "MaintainConnection").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setMaintainConnection(boolean lastParam) {
		Dispatch.call(this, "MaintainConnection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRefreshPeriod() {
		return Dispatch.get(this, "RefreshPeriod").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setRefreshPeriod(int lastParam) {
		Dispatch.call(this, "RefreshPeriod", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getRecordset() {
		return Dispatch.get(this, "Recordset");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void setRecordset(Object lastParam) {
		Dispatch.call(this, "Recordset", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resetTimer() {
		Dispatch.call(this, "ResetTimer");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getLocalConnection() {
		return Dispatch.get(this, "LocalConnection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setLocalConnection(Variant lastParam) {
		Dispatch.call(this, "LocalConnection", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable createPivotTable(Variant tableDestination, Variant tableName, Variant lastParam) {
		return new PivotTable(Dispatch.call(this, "CreatePivotTable", tableDestination, tableName, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable createPivotTable(Variant tableDestination, Variant tableName) {
		return new PivotTable(Dispatch.call(this, "CreatePivotTable", tableDestination, tableName).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param tableDestination an input-parameter of type Variant
	 * @return the result is of type PivotTable
	 */
	public PivotTable createPivotTable(Variant tableDestination) {
		return new PivotTable(Dispatch.call(this, "CreatePivotTable", tableDestination).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getUseLocalConnection() {
		return Dispatch.get(this, "UseLocalConnection").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setUseLocalConnection(boolean lastParam) {
		Dispatch.call(this, "UseLocalConnection", new Variant(lastParam));
	}

	static long zoneOffset	= java.util.Calendar.getInstance().get(java.util.Calendar.ZONE_OFFSET);

	static java.util.Date comDateToJavaDate(double comDate) {
		comDate = comDate - 25569D;
		long millis = Math.round(86400000L * comDate) - zoneOffset;

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(new java.util.Date(millis));
		millis -= cal.get(cal.DST_OFFSET);

		return new java.util.Date(millis);
	}

	static double javaDateToComDate(java.util.Date javaDate) {

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(javaDate);
		long gmtOffset = (cal.get(cal.ZONE_OFFSET) + cal.get(cal.DST_OFFSET));

		long millis = javaDate.getTime() + gmtOffset;
		return 25569D+millis/86400000D;
	}

}
