/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlRunAutoMacro {

	public static final int xlAutoActivate = 3;
	public static final int xlAutoClose = 2;
	public static final int xlAutoDeactivate = 4;
	public static final int xlAutoOpen = 1;
}
