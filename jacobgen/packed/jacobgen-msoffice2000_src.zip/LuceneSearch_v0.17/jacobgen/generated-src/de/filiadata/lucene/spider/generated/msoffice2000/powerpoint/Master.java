/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public class Master extends _Master {

	public static final String componentName = "PowerPoint.Master";

	public Master() {
		super(componentName);
	}

	public Master(Dispatch d) {
		super(d);
	}
}
