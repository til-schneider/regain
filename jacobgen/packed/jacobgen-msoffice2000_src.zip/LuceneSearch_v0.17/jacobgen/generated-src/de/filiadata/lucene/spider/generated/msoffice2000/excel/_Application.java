/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _Application extends Dispatch {

	public static final String componentName = "Excel._Application";

	public _Application() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _Application(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _Application(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getParent() {
		return new Application(Dispatch.get(this, "Parent").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getActiveCell() {
		return new Range(Dispatch.get(this, "ActiveCell").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Chart
	 */
	public Chart getActiveChart() {
		return new Chart(Dispatch.get(this, "ActiveChart").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type DialogSheet
	 */
	public DialogSheet getActiveDialog() {
		return new DialogSheet(Dispatch.get(this, "ActiveDialog").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type MenuBar
	 */
	public MenuBar getActiveMenuBar() {
		return new MenuBar(Dispatch.get(this, "ActiveMenuBar").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getActivePrinter() {
		return Dispatch.get(this, "ActivePrinter").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setActivePrinter(String lastParam) {
		Dispatch.call(this, "ActivePrinter", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getActiveSheet() {
		return Dispatch.get(this, "ActiveSheet");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Window
	 */
	public Window getActiveWindow() {
		return new Window(Dispatch.get(this, "ActiveWindow").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook getActiveWorkbook() {
		return new Workbook(Dispatch.get(this, "ActiveWorkbook").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type AddIns
	 */
	public AddIns getAddIns() {
		return new AddIns(Dispatch.get(this, "AddIns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.Assistant
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.Assistant getAssistant() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.Assistant(Dispatch.get(this, "Assistant").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculate() {
		Dispatch.call(this, "Calculate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getCells() {
		return new Range(Dispatch.get(this, "Cells").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getCharts() {
		return new Sheets(Dispatch.get(this, "Charts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getColumns() {
		return new Range(Dispatch.get(this, "Columns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.CommandBars
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.CommandBars getCommandBars() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.CommandBars(Dispatch.get(this, "CommandBars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDDEAppReturnCode() {
		return Dispatch.get(this, "DDEAppReturnCode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param lastParam an input-parameter of type String
	 */
	public void dDEExecute(int channel, String lastParam) {
		Dispatch.call(this, "DDEExecute", new Variant(channel), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param app an input-parameter of type String
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type int
	 */
	public int dDEInitiate(String app, String lastParam) {
		return Dispatch.call(this, "DDEInitiate", app, lastParam).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param item an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void dDEPoke(int channel, Variant item, Variant lastParam) {
		Dispatch.call(this, "DDEPoke", new Variant(channel), item, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param channel an input-parameter of type int
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant dDERequest(int channel, String lastParam) {
		return Dispatch.call(this, "DDERequest", new Variant(channel), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void dDETerminate(int lastParam) {
		Dispatch.call(this, "DDETerminate", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getDialogSheets() {
		return new Sheets(Dispatch.get(this, "DialogSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant evaluate(Variant lastParam) {
		return Dispatch.call(this, "Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Evaluate(Variant lastParam) {
		return Dispatch.call(this, "_Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant executeExcel4Macro(String lastParam) {
		return Dispatch.call(this, "ExecuteExcel4Macro", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return new Range(Dispatch.callN(this, "Intersect", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6, arg7).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5, arg6).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4, arg5).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3, Variant arg4) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3, arg4).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2, Variant arg3) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2, arg3).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @return the result is of type Range
	 */
	public Range intersect(Range arg1, Range arg2) {
		return new Range(Dispatch.call(this, "Intersect", arg1, arg2).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type MenuBars
	 */
	public MenuBars getMenuBars() {
		return new MenuBars(Dispatch.get(this, "MenuBars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Modules
	 */
	public Modules getModules() {
		return new Modules(Dispatch.get(this, "Modules").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Names
	 */
	public Names getNames() {
		return new Names(Dispatch.get(this, "Names").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1, Variant lastParam) {
		return new Range(Dispatch.call(this, "Range", cell1, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param cell1 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range getRange(Variant cell1) {
		return new Range(Dispatch.call(this, "Range", cell1).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Range
	 */
	public Range getRows() {
		return new Range(Dispatch.get(this, "Rows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.callN(this, "Run", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "Run", macro, arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1, Variant arg2) {
		return Dispatch.call(this, "Run", macro, arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro, Variant arg1) {
		return Dispatch.call(this, "Run", macro, arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant run(Variant macro) {
		return Dispatch.call(this, "Run", macro);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant run() {
		return Dispatch.call(this, "Run");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.callN(this, "_Run2", new Object[] { macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1, Variant arg2) {
		return Dispatch.call(this, "_Run2", macro, arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro, Variant arg1) {
		return Dispatch.call(this, "_Run2", macro, arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Run2(Variant macro) {
		return Dispatch.call(this, "_Run2", macro);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _Run2() {
		return Dispatch.call(this, "_Run2");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getSelection() {
		return Dispatch.get(this, "Selection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param keys an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void sendKeys(Variant keys, Variant lastParam) {
		Dispatch.call(this, "SendKeys", keys, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param keys an input-parameter of type Variant
	 */
	public void sendKeys(Variant keys) {
		Dispatch.call(this, "SendKeys", keys);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getSheets() {
		return new Sheets(Dispatch.get(this, "Sheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Menu
	 */
	public Menu getShortcutMenus(int lastParam) {
		return new Menu(Dispatch.call(this, "ShortcutMenus", new Variant(lastParam)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook getThisWorkbook() {
		return new Workbook(Dispatch.get(this, "ThisWorkbook").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Toolbars
	 */
	public Toolbars getToolbars() {
		return new Toolbars(Dispatch.get(this, "Toolbars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return new Range(Dispatch.callN(this, "Union", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9}).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6, arg7).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5, arg6).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4, Variant arg5) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4, arg5).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3, Variant arg4) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3, arg4).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2, Variant arg3) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2, arg3).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Range
	 * @param arg2 an input-parameter of type Range
	 * @return the result is of type Range
	 */
	public Range union(Range arg1, Range arg2) {
		return new Range(Dispatch.call(this, "Union", arg1, arg2).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Windows
	 */
	public Windows getWindows() {
		return new Windows(Dispatch.get(this, "Windows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbooks
	 */
	public Workbooks getWorkbooks() {
		return new Workbooks(Dispatch.get(this, "Workbooks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type WorksheetFunction
	 */
	public WorksheetFunction getWorksheetFunction() {
		return new WorksheetFunction(Dispatch.get(this, "WorksheetFunction").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getWorksheets() {
		return new Sheets(Dispatch.get(this, "Worksheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4IntlMacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4IntlMacroSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4MacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4MacroSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void activateMicrosoftApp(int lastParam) {
		Dispatch.call(this, "ActivateMicrosoftApp", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param chart an input-parameter of type Variant
	 * @param name an input-parameter of type String
	 * @param lastParam an input-parameter of type Variant
	 */
	public void addChartAutoFormat(Variant chart, String name, Variant lastParam) {
		Dispatch.call(this, "AddChartAutoFormat", chart, name, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param chart an input-parameter of type Variant
	 * @param name an input-parameter of type String
	 */
	public void addChartAutoFormat(Variant chart, String name) {
		Dispatch.call(this, "AddChartAutoFormat", chart, name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param listArray an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void addCustomList(Variant listArray, Variant lastParam) {
		Dispatch.call(this, "AddCustomList", listArray, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param listArray an input-parameter of type Variant
	 */
	public void addCustomList(Variant listArray) {
		Dispatch.call(this, "AddCustomList", listArray);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAlertBeforeOverwriting() {
		return Dispatch.get(this, "AlertBeforeOverwriting").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAlertBeforeOverwriting(boolean lastParam) {
		Dispatch.call(this, "AlertBeforeOverwriting", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getAltStartupPath() {
		return Dispatch.get(this, "AltStartupPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setAltStartupPath(String lastParam) {
		Dispatch.call(this, "AltStartupPath", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAskToUpdateLinks() {
		return Dispatch.get(this, "AskToUpdateLinks").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAskToUpdateLinks(boolean lastParam) {
		Dispatch.call(this, "AskToUpdateLinks", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableAnimations() {
		return Dispatch.get(this, "EnableAnimations").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableAnimations(boolean lastParam) {
		Dispatch.call(this, "EnableAnimations", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type AutoCorrect
	 */
	public AutoCorrect getAutoCorrect() {
		return new AutoCorrect(Dispatch.get(this, "AutoCorrect").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getBuild() {
		return Dispatch.get(this, "Build").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCalculateBeforeSave() {
		return Dispatch.get(this, "CalculateBeforeSave").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCalculateBeforeSave(boolean lastParam) {
		Dispatch.call(this, "CalculateBeforeSave", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCalculation() {
		return Dispatch.get(this, "Calculation").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCalculation(int lastParam) {
		Dispatch.call(this, "Calculation", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getCaller(Variant lastParam) {
		return Dispatch.call(this, "Caller", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getCaller() {
		return Dispatch.get(this, "Caller");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCanPlaySounds() {
		return Dispatch.get(this, "CanPlaySounds").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCanRecordSounds() {
		return Dispatch.get(this, "CanRecordSounds").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCaption() {
		return Dispatch.get(this, "Caption").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setCaption(String lastParam) {
		Dispatch.call(this, "Caption", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCellDragAndDrop() {
		return Dispatch.get(this, "CellDragAndDrop").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCellDragAndDrop(boolean lastParam) {
		Dispatch.call(this, "CellDragAndDrop", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 * @return the result is of type double
	 */
	public double centimetersToPoints(double lastParam) {
		return Dispatch.call(this, "CentimetersToPoints", new Variant(lastParam)).toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param word an input-parameter of type String
	 * @param customDictionary an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean checkSpelling(String word, Variant customDictionary, Variant lastParam) {
		return Dispatch.call(this, "CheckSpelling", word, customDictionary, lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param word an input-parameter of type String
	 * @param customDictionary an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean checkSpelling(String word, Variant customDictionary) {
		return Dispatch.call(this, "CheckSpelling", word, customDictionary).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param word an input-parameter of type String
	 * @return the result is of type boolean
	 */
	public boolean checkSpelling(String word) {
		return Dispatch.call(this, "CheckSpelling", word).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getClipboardFormats(Variant lastParam) {
		return Dispatch.call(this, "ClipboardFormats", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getClipboardFormats() {
		return Dispatch.get(this, "ClipboardFormats");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayClipboardWindow() {
		return Dispatch.get(this, "DisplayClipboardWindow").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayClipboardWindow(boolean lastParam) {
		Dispatch.call(this, "DisplayClipboardWindow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getColorButtons() {
		return Dispatch.get(this, "ColorButtons").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setColorButtons(boolean lastParam) {
		Dispatch.call(this, "ColorButtons", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCommandUnderlines() {
		return Dispatch.get(this, "CommandUnderlines").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCommandUnderlines(int lastParam) {
		Dispatch.call(this, "CommandUnderlines", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getConstrainNumeric() {
		return Dispatch.get(this, "ConstrainNumeric").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setConstrainNumeric(boolean lastParam) {
		Dispatch.call(this, "ConstrainNumeric", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formula an input-parameter of type Variant
	 * @param fromReferenceStyle an input-parameter of type int
	 * @param toReferenceStyle an input-parameter of type Variant
	 * @param toAbsolute an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant convertFormula(Variant formula, int fromReferenceStyle, Variant toReferenceStyle, Variant toAbsolute, Variant lastParam) {
		return Dispatch.call(this, "ConvertFormula", formula, new Variant(fromReferenceStyle), toReferenceStyle, toAbsolute, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formula an input-parameter of type Variant
	 * @param fromReferenceStyle an input-parameter of type int
	 * @param toReferenceStyle an input-parameter of type Variant
	 * @param toAbsolute an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant convertFormula(Variant formula, int fromReferenceStyle, Variant toReferenceStyle, Variant toAbsolute) {
		return Dispatch.call(this, "ConvertFormula", formula, new Variant(fromReferenceStyle), toReferenceStyle, toAbsolute);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formula an input-parameter of type Variant
	 * @param fromReferenceStyle an input-parameter of type int
	 * @param toReferenceStyle an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant convertFormula(Variant formula, int fromReferenceStyle, Variant toReferenceStyle) {
		return Dispatch.call(this, "ConvertFormula", formula, new Variant(fromReferenceStyle), toReferenceStyle);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formula an input-parameter of type Variant
	 * @param fromReferenceStyle an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant convertFormula(Variant formula, int fromReferenceStyle) {
		return Dispatch.call(this, "ConvertFormula", formula, new Variant(fromReferenceStyle));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCopyObjectsWithCells() {
		return Dispatch.get(this, "CopyObjectsWithCells").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCopyObjectsWithCells(boolean lastParam) {
		Dispatch.call(this, "CopyObjectsWithCells", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCursor() {
		return Dispatch.get(this, "Cursor").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCursor(int lastParam) {
		Dispatch.call(this, "Cursor", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCustomListCount() {
		return Dispatch.get(this, "CustomListCount").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCutCopyMode() {
		return Dispatch.get(this, "CutCopyMode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCutCopyMode(int lastParam) {
		Dispatch.call(this, "CutCopyMode", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDataEntryMode() {
		return Dispatch.get(this, "DataEntryMode").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDataEntryMode(int lastParam) {
		Dispatch.call(this, "DataEntryMode", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy1() {
		Dispatch.call(this, "Dummy1");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy2() {
		Dispatch.call(this, "Dummy2");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy3() {
		Dispatch.call(this, "Dummy3");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy4() {
		Dispatch.call(this, "Dummy4");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy5() {
		Dispatch.call(this, "Dummy5");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy6() {
		Dispatch.call(this, "Dummy6");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy7() {
		Dispatch.call(this, "Dummy7");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy8() {
		Dispatch.call(this, "Dummy8");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy9() {
		Dispatch.call(this, "Dummy9");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy10() {
		Dispatch.call(this, "Dummy10");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy11() {
		Dispatch.call(this, "Dummy11");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_Default() {
		return Dispatch.get(this, "_Default").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getDefaultFilePath() {
		return Dispatch.get(this, "DefaultFilePath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setDefaultFilePath(String lastParam) {
		Dispatch.call(this, "DefaultFilePath", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void deleteChartAutoFormat(String lastParam) {
		Dispatch.call(this, "DeleteChartAutoFormat", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void deleteCustomList(int lastParam) {
		Dispatch.call(this, "DeleteCustomList", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Dialogs
	 */
	public Dialogs getDialogs() {
		return new Dialogs(Dispatch.get(this, "Dialogs").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayAlerts() {
		return Dispatch.get(this, "DisplayAlerts").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayAlerts(boolean lastParam) {
		Dispatch.call(this, "DisplayAlerts", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayFormulaBar() {
		return Dispatch.get(this, "DisplayFormulaBar").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayFormulaBar(boolean lastParam) {
		Dispatch.call(this, "DisplayFormulaBar", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayFullScreen() {
		return Dispatch.get(this, "DisplayFullScreen").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayFullScreen(boolean lastParam) {
		Dispatch.call(this, "DisplayFullScreen", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayNoteIndicator() {
		return Dispatch.get(this, "DisplayNoteIndicator").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayNoteIndicator(boolean lastParam) {
		Dispatch.call(this, "DisplayNoteIndicator", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDisplayCommentIndicator() {
		return Dispatch.get(this, "DisplayCommentIndicator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDisplayCommentIndicator(int lastParam) {
		Dispatch.call(this, "DisplayCommentIndicator", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayExcel4Menus() {
		return Dispatch.get(this, "DisplayExcel4Menus").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayExcel4Menus(boolean lastParam) {
		Dispatch.call(this, "DisplayExcel4Menus", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayRecentFiles() {
		return Dispatch.get(this, "DisplayRecentFiles").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayRecentFiles(boolean lastParam) {
		Dispatch.call(this, "DisplayRecentFiles", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayScrollBars() {
		return Dispatch.get(this, "DisplayScrollBars").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayScrollBars(boolean lastParam) {
		Dispatch.call(this, "DisplayScrollBars", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayStatusBar() {
		return Dispatch.get(this, "DisplayStatusBar").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayStatusBar(boolean lastParam) {
		Dispatch.call(this, "DisplayStatusBar", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void doubleClick() {
		Dispatch.call(this, "DoubleClick");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEditDirectlyInCell() {
		return Dispatch.get(this, "EditDirectlyInCell").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEditDirectlyInCell(boolean lastParam) {
		Dispatch.call(this, "EditDirectlyInCell", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableAutoComplete() {
		return Dispatch.get(this, "EnableAutoComplete").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableAutoComplete(boolean lastParam) {
		Dispatch.call(this, "EnableAutoComplete", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getEnableCancelKey() {
		return Dispatch.get(this, "EnableCancelKey").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setEnableCancelKey(int lastParam) {
		Dispatch.call(this, "EnableCancelKey", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableSound() {
		return Dispatch.get(this, "EnableSound").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableSound(boolean lastParam) {
		Dispatch.call(this, "EnableSound", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableTipWizard() {
		return Dispatch.get(this, "EnableTipWizard").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableTipWizard(boolean lastParam) {
		Dispatch.call(this, "EnableTipWizard", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getFileConverters(Variant index1, Variant lastParam) {
		return Dispatch.call(this, "FileConverters", index1, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getFileConverters(Variant index1) {
		return Dispatch.call(this, "FileConverters", index1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getFileConverters() {
		return Dispatch.get(this, "FileConverters");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.FileSearch
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.FileSearch getFileSearch() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.FileSearch(Dispatch.get(this, "FileSearch").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.IFind
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.IFind getFileFind() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.IFind(Dispatch.get(this, "FileFind").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _FindFile() {
		Dispatch.call(this, "_FindFile");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getFixedDecimal() {
		return Dispatch.get(this, "FixedDecimal").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setFixedDecimal(boolean lastParam) {
		Dispatch.call(this, "FixedDecimal", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getFixedDecimalPlaces() {
		return Dispatch.get(this, "FixedDecimalPlaces").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setFixedDecimalPlaces(int lastParam) {
		Dispatch.call(this, "FixedDecimalPlaces", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant getCustomListContents(int lastParam) {
		return Dispatch.call(this, "GetCustomListContents", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type int
	 */
	public int getCustomListNum(Variant lastParam) {
		return Dispatch.call(this, "GetCustomListNum", lastParam).toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param buttonText an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename(Variant fileFilter, Variant filterIndex, Variant title, Variant buttonText, Variant lastParam) {
		return Dispatch.call(this, "GetOpenFilename", fileFilter, filterIndex, title, buttonText, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param buttonText an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename(Variant fileFilter, Variant filterIndex, Variant title, Variant buttonText) {
		return Dispatch.call(this, "GetOpenFilename", fileFilter, filterIndex, title, buttonText);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename(Variant fileFilter, Variant filterIndex, Variant title) {
		return Dispatch.call(this, "GetOpenFilename", fileFilter, filterIndex, title);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename(Variant fileFilter, Variant filterIndex) {
		return Dispatch.call(this, "GetOpenFilename", fileFilter, filterIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFilter an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename(Variant fileFilter) {
		return Dispatch.call(this, "GetOpenFilename", fileFilter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getOpenFilename() {
		return Dispatch.call(this, "GetOpenFilename");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param initialFilename an input-parameter of type Variant
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename(Variant initialFilename, Variant fileFilter, Variant filterIndex, Variant title, Variant lastParam) {
		return Dispatch.call(this, "GetSaveAsFilename", initialFilename, fileFilter, filterIndex, title, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param initialFilename an input-parameter of type Variant
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename(Variant initialFilename, Variant fileFilter, Variant filterIndex, Variant title) {
		return Dispatch.call(this, "GetSaveAsFilename", initialFilename, fileFilter, filterIndex, title);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param initialFilename an input-parameter of type Variant
	 * @param fileFilter an input-parameter of type Variant
	 * @param filterIndex an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename(Variant initialFilename, Variant fileFilter, Variant filterIndex) {
		return Dispatch.call(this, "GetSaveAsFilename", initialFilename, fileFilter, filterIndex);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param initialFilename an input-parameter of type Variant
	 * @param fileFilter an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename(Variant initialFilename, Variant fileFilter) {
		return Dispatch.call(this, "GetSaveAsFilename", initialFilename, fileFilter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param initialFilename an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename(Variant initialFilename) {
		return Dispatch.call(this, "GetSaveAsFilename", initialFilename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getSaveAsFilename() {
		return Dispatch.call(this, "GetSaveAsFilename");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param reference an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void m_goto(Variant reference, Variant lastParam) {
		Dispatch.call(this, "Goto", reference, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param reference an input-parameter of type Variant
	 */
	public void m_goto(Variant reference) {
		Dispatch.call(this, "Goto", reference);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void m_goto() {
		Dispatch.call(this, "Goto");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getHeight() {
		return Dispatch.get(this, "Height").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setHeight(double lastParam) {
		Dispatch.call(this, "Height", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param helpFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void help(Variant helpFile, Variant lastParam) {
		Dispatch.call(this, "Help", helpFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param helpFile an input-parameter of type Variant
	 */
	public void help(Variant helpFile) {
		Dispatch.call(this, "Help", helpFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void help() {
		Dispatch.call(this, "Help");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getIgnoreRemoteRequests() {
		return Dispatch.get(this, "IgnoreRemoteRequests").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setIgnoreRemoteRequests(boolean lastParam) {
		Dispatch.call(this, "IgnoreRemoteRequests", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 * @return the result is of type double
	 */
	public double inchesToPoints(double lastParam) {
		return Dispatch.call(this, "InchesToPoints", new Variant(lastParam)).toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param top an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @param helpContextID an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default, Variant left, Variant top, Variant helpFile, Variant helpContextID, Variant lastParam) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default, left, top, helpFile, helpContextID, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param top an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @param helpContextID an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default, Variant left, Variant top, Variant helpFile, Variant helpContextID) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default, left, top, helpFile, helpContextID);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param top an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default, Variant left, Variant top, Variant helpFile) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default, left, top, helpFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @param top an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default, Variant left, Variant top) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default, left, top);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @param left an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default, Variant left) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default, left);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @param p_default an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title, Variant p_default) {
		return Dispatch.call(this, "InputBox", prompt, title, p_default);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @param title an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt, Variant title) {
		return Dispatch.call(this, "InputBox", prompt, title);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param prompt an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant inputBox(String prompt) {
		return Dispatch.call(this, "InputBox", prompt);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getInteractive() {
		return Dispatch.get(this, "Interactive").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setInteractive(boolean lastParam) {
		Dispatch.call(this, "Interactive", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getInternational(Variant lastParam) {
		return Dispatch.call(this, "International", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getInternational() {
		return Dispatch.get(this, "International");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getIteration() {
		return Dispatch.get(this, "Iteration").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setIteration(boolean lastParam) {
		Dispatch.call(this, "Iteration", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getLargeButtons() {
		return Dispatch.get(this, "LargeButtons").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setLargeButtons(boolean lastParam) {
		Dispatch.call(this, "LargeButtons", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getLeft() {
		return Dispatch.get(this, "Left").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setLeft(double lastParam) {
		Dispatch.call(this, "Left", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getLibraryPath() {
		return Dispatch.get(this, "LibraryPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpContextID an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey, Variant shortcutKey, Variant category, Variant statusBar, Variant helpContextID, Variant lastParam) {
		Dispatch.callN(this, "MacroOptions", new Object[] { macro, description, hasMenu, menuText, hasShortcutKey, shortcutKey, category, statusBar, helpContextID, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpContextID an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey, Variant shortcutKey, Variant category, Variant statusBar, Variant helpContextID) {
		Dispatch.callN(this, "MacroOptions", new Object[] { macro, description, hasMenu, menuText, hasShortcutKey, shortcutKey, category, statusBar, helpContextID});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey, Variant shortcutKey, Variant category, Variant statusBar) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu, menuText, hasShortcutKey, shortcutKey, category, statusBar);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param category an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey, Variant shortcutKey, Variant category) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu, menuText, hasShortcutKey, shortcutKey, category);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey, Variant shortcutKey) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu, menuText, hasShortcutKey, shortcutKey);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 * @param hasShortcutKey an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText, Variant hasShortcutKey) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu, menuText, hasShortcutKey);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 * @param menuText an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu, Variant menuText) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu, menuText);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 * @param hasMenu an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description, Variant hasMenu) {
		Dispatch.call(this, "MacroOptions", macro, description, hasMenu);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 * @param description an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro, Variant description) {
		Dispatch.call(this, "MacroOptions", macro, description);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param macro an input-parameter of type Variant
	 */
	public void macroOptions(Variant macro) {
		Dispatch.call(this, "MacroOptions", macro);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void macroOptions() {
		Dispatch.call(this, "MacroOptions");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void mailLogoff() {
		Dispatch.call(this, "MailLogoff");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void mailLogon(Variant name, Variant password, Variant lastParam) {
		Dispatch.call(this, "MailLogon", name, password, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void mailLogon(Variant name, Variant password) {
		Dispatch.call(this, "MailLogon", name, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 */
	public void mailLogon(Variant name) {
		Dispatch.call(this, "MailLogon", name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void mailLogon() {
		Dispatch.call(this, "MailLogon");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getMailSession() {
		return Dispatch.get(this, "MailSession");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMailSystem() {
		return Dispatch.get(this, "MailSystem").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMathCoprocessorAvailable() {
		return Dispatch.get(this, "MathCoprocessorAvailable").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getMaxChange() {
		return Dispatch.get(this, "MaxChange").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setMaxChange(double lastParam) {
		Dispatch.call(this, "MaxChange", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMaxIterations() {
		return Dispatch.get(this, "MaxIterations").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setMaxIterations(int lastParam) {
		Dispatch.call(this, "MaxIterations", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMemoryFree() {
		return Dispatch.get(this, "MemoryFree").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMemoryTotal() {
		return Dispatch.get(this, "MemoryTotal").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMemoryUsed() {
		return Dispatch.get(this, "MemoryUsed").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMouseAvailable() {
		return Dispatch.get(this, "MouseAvailable").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMoveAfterReturn() {
		return Dispatch.get(this, "MoveAfterReturn").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setMoveAfterReturn(boolean lastParam) {
		Dispatch.call(this, "MoveAfterReturn", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getMoveAfterReturnDirection() {
		return Dispatch.get(this, "MoveAfterReturnDirection").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setMoveAfterReturnDirection(int lastParam) {
		Dispatch.call(this, "MoveAfterReturnDirection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type RecentFiles
	 */
	public RecentFiles getRecentFiles() {
		return new RecentFiles(Dispatch.get(this, "RecentFiles").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Workbook
	 */
	public Workbook nextLetter() {
		return new Workbook(Dispatch.call(this, "NextLetter").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getNetworkTemplatesPath() {
		return Dispatch.get(this, "NetworkTemplatesPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ODBCErrors
	 */
	public ODBCErrors getODBCErrors() {
		return new ODBCErrors(Dispatch.get(this, "ODBCErrors").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getODBCTimeout() {
		return Dispatch.get(this, "ODBCTimeout").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setODBCTimeout(int lastParam) {
		Dispatch.call(this, "ODBCTimeout", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnCalculate() {
		return Dispatch.get(this, "OnCalculate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnCalculate(String lastParam) {
		Dispatch.call(this, "OnCalculate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnData() {
		return Dispatch.get(this, "OnData").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnData(String lastParam) {
		Dispatch.call(this, "OnData", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnDoubleClick() {
		return Dispatch.get(this, "OnDoubleClick").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnDoubleClick(String lastParam) {
		Dispatch.call(this, "OnDoubleClick", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnEntry() {
		return Dispatch.get(this, "OnEntry").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnEntry(String lastParam) {
		Dispatch.call(this, "OnEntry", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key an input-parameter of type String
	 * @param lastParam an input-parameter of type Variant
	 */
	public void onKey(String key, Variant lastParam) {
		Dispatch.call(this, "OnKey", key, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param key an input-parameter of type String
	 */
	public void onKey(String key) {
		Dispatch.call(this, "OnKey", key);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type String
	 * @param lastParam an input-parameter of type String
	 */
	public void onRepeat(String text, String lastParam) {
		Dispatch.call(this, "OnRepeat", text, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetActivate() {
		return Dispatch.get(this, "OnSheetActivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetActivate(String lastParam) {
		Dispatch.call(this, "OnSheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetDeactivate() {
		return Dispatch.get(this, "OnSheetDeactivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetDeactivate(String lastParam) {
		Dispatch.call(this, "OnSheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param earliestTime an input-parameter of type Variant
	 * @param procedure an input-parameter of type String
	 * @param latestTime an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void onTime(Variant earliestTime, String procedure, Variant latestTime, Variant lastParam) {
		Dispatch.call(this, "OnTime", earliestTime, procedure, latestTime, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param earliestTime an input-parameter of type Variant
	 * @param procedure an input-parameter of type String
	 * @param latestTime an input-parameter of type Variant
	 */
	public void onTime(Variant earliestTime, String procedure, Variant latestTime) {
		Dispatch.call(this, "OnTime", earliestTime, procedure, latestTime);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param earliestTime an input-parameter of type Variant
	 * @param procedure an input-parameter of type String
	 */
	public void onTime(Variant earliestTime, String procedure) {
		Dispatch.call(this, "OnTime", earliestTime, procedure);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param text an input-parameter of type String
	 * @param lastParam an input-parameter of type String
	 */
	public void onUndo(String text, String lastParam) {
		Dispatch.call(this, "OnUndo", text, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnWindow() {
		return Dispatch.get(this, "OnWindow").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnWindow(String lastParam) {
		Dispatch.call(this, "OnWindow", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOperatingSystem() {
		return Dispatch.get(this, "OperatingSystem").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOrganizationName() {
		return Dispatch.get(this, "OrganizationName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPath() {
		return Dispatch.get(this, "Path").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPathSeparator() {
		return Dispatch.get(this, "PathSeparator").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getPreviousSelections(Variant lastParam) {
		return Dispatch.call(this, "PreviousSelections", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getPreviousSelections() {
		return Dispatch.get(this, "PreviousSelections");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPivotTableSelection() {
		return Dispatch.get(this, "PivotTableSelection").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPivotTableSelection(boolean lastParam) {
		Dispatch.call(this, "PivotTableSelection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPromptForSummaryInfo() {
		return Dispatch.get(this, "PromptForSummaryInfo").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPromptForSummaryInfo(boolean lastParam) {
		Dispatch.call(this, "PromptForSummaryInfo", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void quit() {
		Dispatch.call(this, "Quit");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param basicCode an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void recordMacro(Variant basicCode, Variant lastParam) {
		Dispatch.call(this, "RecordMacro", basicCode, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param basicCode an input-parameter of type Variant
	 */
	public void recordMacro(Variant basicCode) {
		Dispatch.call(this, "RecordMacro", basicCode);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void recordMacro() {
		Dispatch.call(this, "RecordMacro");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRecordRelative() {
		return Dispatch.get(this, "RecordRelative").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getReferenceStyle() {
		return Dispatch.get(this, "ReferenceStyle").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setReferenceStyle(int lastParam) {
		Dispatch.call(this, "ReferenceStyle", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getRegisteredFunctions(Variant index1, Variant lastParam) {
		return Dispatch.call(this, "RegisteredFunctions", index1, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getRegisteredFunctions(Variant index1) {
		return Dispatch.call(this, "RegisteredFunctions", index1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getRegisteredFunctions() {
		return Dispatch.get(this, "RegisteredFunctions");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type boolean
	 */
	public boolean registerXLL(String lastParam) {
		return Dispatch.call(this, "RegisterXLL", lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void repeat() {
		Dispatch.call(this, "Repeat");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resetTipWizard() {
		Dispatch.call(this, "ResetTipWizard");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRollZoom() {
		return Dispatch.get(this, "RollZoom").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setRollZoom(boolean lastParam) {
		Dispatch.call(this, "RollZoom", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void save(Variant lastParam) {
		Dispatch.call(this, "Save", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void save() {
		Dispatch.call(this, "Save");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveWorkspace(Variant lastParam) {
		Dispatch.call(this, "SaveWorkspace", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void saveWorkspace() {
		Dispatch.call(this, "SaveWorkspace");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getScreenUpdating() {
		return Dispatch.get(this, "ScreenUpdating").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setScreenUpdating(boolean lastParam) {
		Dispatch.call(this, "ScreenUpdating", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formatName an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setDefaultChart(Variant formatName, Variant lastParam) {
		Dispatch.call(this, "SetDefaultChart", formatName, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param formatName an input-parameter of type Variant
	 */
	public void setDefaultChart(Variant formatName) {
		Dispatch.call(this, "SetDefaultChart", formatName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void setDefaultChart() {
		Dispatch.call(this, "SetDefaultChart");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getSheetsInNewWorkbook() {
		return Dispatch.get(this, "SheetsInNewWorkbook").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setSheetsInNewWorkbook(int lastParam) {
		Dispatch.call(this, "SheetsInNewWorkbook", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowChartTipNames() {
		return Dispatch.get(this, "ShowChartTipNames").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowChartTipNames(boolean lastParam) {
		Dispatch.call(this, "ShowChartTipNames", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowChartTipValues() {
		return Dispatch.get(this, "ShowChartTipValues").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowChartTipValues(boolean lastParam) {
		Dispatch.call(this, "ShowChartTipValues", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getStandardFont() {
		return Dispatch.get(this, "StandardFont").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setStandardFont(String lastParam) {
		Dispatch.call(this, "StandardFont", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getStandardFontSize() {
		return Dispatch.get(this, "StandardFontSize").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setStandardFontSize(double lastParam) {
		Dispatch.call(this, "StandardFontSize", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getStartupPath() {
		return Dispatch.get(this, "StartupPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getStatusBar() {
		return Dispatch.get(this, "StatusBar");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setStatusBar(Variant lastParam) {
		Dispatch.call(this, "StatusBar", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTemplatesPath() {
		return Dispatch.get(this, "TemplatesPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowToolTips() {
		return Dispatch.get(this, "ShowToolTips").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowToolTips(boolean lastParam) {
		Dispatch.call(this, "ShowToolTips", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getTop() {
		return Dispatch.get(this, "Top").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setTop(double lastParam) {
		Dispatch.call(this, "Top", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDefaultSaveFormat() {
		return Dispatch.get(this, "DefaultSaveFormat").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDefaultSaveFormat(int lastParam) {
		Dispatch.call(this, "DefaultSaveFormat", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTransitionMenuKey() {
		return Dispatch.get(this, "TransitionMenuKey").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTransitionMenuKey(String lastParam) {
		Dispatch.call(this, "TransitionMenuKey", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getTransitionMenuKeyAction() {
		return Dispatch.get(this, "TransitionMenuKeyAction").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setTransitionMenuKeyAction(int lastParam) {
		Dispatch.call(this, "TransitionMenuKeyAction", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTransitionNavigKeys() {
		return Dispatch.get(this, "TransitionNavigKeys").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTransitionNavigKeys(boolean lastParam) {
		Dispatch.call(this, "TransitionNavigKeys", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void undo() {
		Dispatch.call(this, "Undo");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getUsableHeight() {
		return Dispatch.get(this, "UsableHeight").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getUsableWidth() {
		return Dispatch.get(this, "UsableWidth").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getUserControl() {
		return Dispatch.get(this, "UserControl").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setUserControl(boolean lastParam) {
		Dispatch.call(this, "UserControl", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getUserName() {
		return Dispatch.get(this, "UserName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setUserName(String lastParam) {
		Dispatch.call(this, "UserName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getValue() {
		return Dispatch.get(this, "Value").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getVBE() {
		return Dispatch.get(this, "VBE");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getVersion() {
		return Dispatch.get(this, "Version").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getVisible() {
		return Dispatch.get(this, "Visible").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setVisible(boolean lastParam) {
		Dispatch.call(this, "Visible", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void m_volatile(Variant lastParam) {
		Dispatch.call(this, "Volatile", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void m_volatile() {
		Dispatch.call(this, "Volatile");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _Wait(Variant lastParam) {
		Dispatch.call(this, "_Wait", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type double
	 */
	public double getWidth() {
		return Dispatch.get(this, "Width").toDouble();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type double
	 */
	public void setWidth(double lastParam) {
		Dispatch.call(this, "Width", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWindowsForPens() {
		return Dispatch.get(this, "WindowsForPens").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getWindowState() {
		return Dispatch.get(this, "WindowState").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setWindowState(int lastParam) {
		Dispatch.call(this, "WindowState", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getUILanguage() {
		return Dispatch.get(this, "UILanguage").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setUILanguage(int lastParam) {
		Dispatch.call(this, "UILanguage", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDefaultSheetDirection() {
		return Dispatch.get(this, "DefaultSheetDirection").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDefaultSheetDirection(int lastParam) {
		Dispatch.call(this, "DefaultSheetDirection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCursorMovement() {
		return Dispatch.get(this, "CursorMovement").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setCursorMovement(int lastParam) {
		Dispatch.call(this, "CursorMovement", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getControlCharacters() {
		return Dispatch.get(this, "ControlCharacters").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setControlCharacters(boolean lastParam) {
		Dispatch.call(this, "ControlCharacters", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29, Variant lastParam) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @param arg29 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28, Variant arg29) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28, arg29});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @param arg28 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27, Variant arg28) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27, arg28});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @param arg27 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26, Variant arg27) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26, arg27});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @param arg26 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25, Variant arg26) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25, arg26});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @param arg25 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24, Variant arg25) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24, arg25});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @param arg24 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23, Variant arg24) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23, arg24});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @param arg23 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22, Variant arg23) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22, arg23});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @param arg22 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21, Variant arg22) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21, arg22});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @param arg21 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20, Variant arg21) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, arg21});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @param arg20 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19, Variant arg20) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @param arg19 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18, Variant arg19) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @param arg18 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17, Variant arg18) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @param arg17 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16, Variant arg17) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @param arg16 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15, Variant arg16) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @param arg15 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14, Variant arg15) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @param arg14 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13, Variant arg14) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @param arg13 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12, Variant arg13) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @param arg12 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11, Variant arg12) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @param arg11 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10, Variant arg11) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @param arg10 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9, Variant arg10) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @param arg9 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8, Variant arg9) {
		return Dispatch.callN(this, "_WSFunction", new Object[] { arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @param arg8 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7, Variant arg8) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @param arg7 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6, Variant arg7) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3, arg4, arg5, arg6, arg7);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @param arg6 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5, Variant arg6) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3, arg4, arg5, arg6);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @param arg5 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4, Variant arg5) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3, arg4, arg5);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @param arg4 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3, Variant arg4) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3, arg4);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @param arg3 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2, Variant arg3) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2, arg3);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @param arg2 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1, Variant arg2) {
		return Dispatch.call(this, "_WSFunction", arg1, arg2);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param arg1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction(Variant arg1) {
		return Dispatch.call(this, "_WSFunction", arg1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant _WSFunction() {
		return Dispatch.call(this, "_WSFunction");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnableEvents() {
		return Dispatch.get(this, "EnableEvents").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnableEvents(boolean lastParam) {
		Dispatch.call(this, "EnableEvents", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDisplayInfoWindow() {
		return Dispatch.get(this, "DisplayInfoWindow").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDisplayInfoWindow(boolean lastParam) {
		Dispatch.call(this, "DisplayInfoWindow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean wait1(Variant lastParam) {
		return Dispatch.call(this, "Wait", lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getExtendList() {
		return Dispatch.get(this, "ExtendList").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setExtendList(boolean lastParam) {
		Dispatch.call(this, "ExtendList", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type OLEDBErrors
	 */
	public OLEDBErrors getOLEDBErrors() {
		return new OLEDBErrors(Dispatch.get(this, "OLEDBErrors").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type String
	 */
	public String getPhonetic(Variant lastParam) {
		return Dispatch.call(this, "GetPhonetic", lastParam).toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPhonetic() {
		return Dispatch.call(this, "GetPhonetic").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.COMAddIns
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.COMAddIns getCOMAddIns() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.COMAddIns(Dispatch.get(this, "COMAddIns").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type DefaultWebOptions
	 */
	public DefaultWebOptions getDefaultWebOptions() {
		return new DefaultWebOptions(Dispatch.get(this, "DefaultWebOptions").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getProductCode() {
		return Dispatch.get(this, "ProductCode").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getUserLibraryPath() {
		return Dispatch.get(this, "UserLibraryPath").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAutoPercentEntry() {
		return Dispatch.get(this, "AutoPercentEntry").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAutoPercentEntry(boolean lastParam) {
		Dispatch.call(this, "AutoPercentEntry", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.LanguageSettings
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.LanguageSettings getLanguageSettings() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.LanguageSettings(Dispatch.get(this, "LanguageSettings").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDummy101() {
		return Dispatch.get(this, "Dummy101").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void dummy12() {
		Dispatch.call(this, "Dummy12");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.AnswerWizard
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.AnswerWizard getAnswerWizard() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.AnswerWizard(Dispatch.get(this, "AnswerWizard").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void calculateFull() {
		Dispatch.call(this, "CalculateFull");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean findFile() {
		return Dispatch.call(this, "FindFile").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCalculationVersion() {
		return Dispatch.get(this, "CalculationVersion").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowWindowsInTaskbar() {
		return Dispatch.get(this, "ShowWindowsInTaskbar").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowWindowsInTaskbar(boolean lastParam) {
		Dispatch.call(this, "ShowWindowsInTaskbar", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getFeatureInstall() {
		return Dispatch.get(this, "FeatureInstall").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setFeatureInstall(int lastParam) {
		Dispatch.call(this, "FeatureInstall", new Variant(lastParam));
	}

}
