/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlEditionFormat {

	public static final int xlBIFF = 2;
	public static final int xlPICT = 1;
	public static final int xlRTF = 4;
	public static final int xlVALU = 8;
}
