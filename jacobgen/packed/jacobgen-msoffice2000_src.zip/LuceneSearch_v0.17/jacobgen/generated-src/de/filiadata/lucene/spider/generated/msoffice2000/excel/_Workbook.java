/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _Workbook extends Dispatch {

	public static final String componentName = "Excel._Workbook";

	public _Workbook() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _Workbook(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _Workbook(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAcceptLabelsInFormulas() {
		return Dispatch.get(this, "AcceptLabelsInFormulas").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAcceptLabelsInFormulas(boolean lastParam) {
		Dispatch.call(this, "AcceptLabelsInFormulas", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Chart
	 */
	public Chart getActiveChart() {
		return new Chart(Dispatch.get(this, "ActiveChart").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getActiveSheet() {
		return Dispatch.get(this, "ActiveSheet");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getAuthor() {
		return Dispatch.get(this, "Author").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setAuthor(String lastParam) {
		Dispatch.call(this, "Author", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getAutoUpdateFrequency() {
		return Dispatch.get(this, "AutoUpdateFrequency").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setAutoUpdateFrequency(int lastParam) {
		Dispatch.call(this, "AutoUpdateFrequency", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAutoUpdateSaveChanges() {
		return Dispatch.get(this, "AutoUpdateSaveChanges").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAutoUpdateSaveChanges(boolean lastParam) {
		Dispatch.call(this, "AutoUpdateSaveChanges", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getChangeHistoryDuration() {
		return Dispatch.get(this, "ChangeHistoryDuration").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setChangeHistoryDuration(int lastParam) {
		Dispatch.call(this, "ChangeHistoryDuration", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getBuiltinDocumentProperties() {
		return Dispatch.get(this, "BuiltinDocumentProperties");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param mode an input-parameter of type int
	 * @param writePassword an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void changeFileAccess(int mode, Variant writePassword, Variant lastParam) {
		Dispatch.call(this, "ChangeFileAccess", new Variant(mode), writePassword, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param mode an input-parameter of type int
	 * @param writePassword an input-parameter of type Variant
	 */
	public void changeFileAccess(int mode, Variant writePassword) {
		Dispatch.call(this, "ChangeFileAccess", new Variant(mode), writePassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param mode an input-parameter of type int
	 */
	public void changeFileAccess(int mode) {
		Dispatch.call(this, "ChangeFileAccess", new Variant(mode));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param newName an input-parameter of type String
	 * @param lastParam an input-parameter of type int
	 */
	public void changeLink(String name, String newName, int lastParam) {
		Dispatch.call(this, "ChangeLink", name, newName, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param newName an input-parameter of type String
	 */
	public void changeLink(String name, String newName) {
		Dispatch.call(this, "ChangeLink", name, newName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getCharts() {
		return new Sheets(Dispatch.get(this, "Charts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param saveChanges an input-parameter of type Variant
	 * @param filename an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void close(Variant saveChanges, Variant filename, Variant lastParam) {
		Dispatch.call(this, "Close", saveChanges, filename, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param saveChanges an input-parameter of type Variant
	 * @param filename an input-parameter of type Variant
	 */
	public void close(Variant saveChanges, Variant filename) {
		Dispatch.call(this, "Close", saveChanges, filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param saveChanges an input-parameter of type Variant
	 */
	public void close(Variant saveChanges) {
		Dispatch.call(this, "Close", saveChanges);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void close() {
		Dispatch.call(this, "Close");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCodeName() {
		return Dispatch.get(this, "CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_CodeName() {
		return Dispatch.get(this, "_CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void set_CodeName(String lastParam) {
		Dispatch.call(this, "_CodeName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getColors(Variant lastParam) {
		return Dispatch.call(this, "Colors", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getColors() {
		return Dispatch.get(this, "Colors");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setColors(Variant index, Variant lastParam) {
		Dispatch.call(this, "Colors", index, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void setColors() {
		Dispatch.call(this, "Colors");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.CommandBars
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.CommandBars getCommandBars() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.CommandBars(Dispatch.get(this, "CommandBars").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getComments() {
		return Dispatch.get(this, "Comments").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setComments(String lastParam) {
		Dispatch.call(this, "Comments", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getConflictResolution() {
		return Dispatch.get(this, "ConflictResolution").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setConflictResolution(int lastParam) {
		Dispatch.call(this, "ConflictResolution", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getContainer() {
		return Dispatch.get(this, "Container");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCreateBackup() {
		return Dispatch.get(this, "CreateBackup").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getCustomDocumentProperties() {
		return Dispatch.get(this, "CustomDocumentProperties");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getDate1904() {
		return Dispatch.get(this, "Date1904").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setDate1904(boolean lastParam) {
		Dispatch.call(this, "Date1904", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void deleteNumberFormat(String lastParam) {
		Dispatch.call(this, "DeleteNumberFormat", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getDialogSheets() {
		return new Sheets(Dispatch.get(this, "DialogSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDisplayDrawingObjects() {
		return Dispatch.get(this, "DisplayDrawingObjects").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDisplayDrawingObjects(int lastParam) {
		Dispatch.call(this, "DisplayDrawingObjects", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean exclusiveAccess() {
		return Dispatch.call(this, "ExclusiveAccess").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getFileFormat() {
		return Dispatch.get(this, "FileFormat").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void forwardMailer() {
		Dispatch.call(this, "ForwardMailer");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getFullName() {
		return Dispatch.get(this, "FullName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasMailer() {
		return Dispatch.get(this, "HasMailer").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasMailer(boolean lastParam) {
		Dispatch.call(this, "HasMailer", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasPassword() {
		return Dispatch.get(this, "HasPassword").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasRoutingSlip() {
		return Dispatch.get(this, "HasRoutingSlip").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasRoutingSlip(boolean lastParam) {
		Dispatch.call(this, "HasRoutingSlip", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getIsAddin() {
		return Dispatch.get(this, "IsAddin").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setIsAddin(boolean lastParam) {
		Dispatch.call(this, "IsAddin", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getKeywords() {
		return Dispatch.get(this, "Keywords").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setKeywords(String lastParam) {
		Dispatch.call(this, "Keywords", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param linkInfo an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant linkInfo(String name, int linkInfo, Variant type, Variant lastParam) {
		return Dispatch.call(this, "LinkInfo", name, new Variant(linkInfo), type, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param linkInfo an input-parameter of type int
	 * @param type an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant linkInfo(String name, int linkInfo, Variant type) {
		return Dispatch.call(this, "LinkInfo", name, new Variant(linkInfo), type);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param linkInfo an input-parameter of type int
	 * @return the result is of type Variant
	 */
	public Variant linkInfo(String name, int linkInfo) {
		return Dispatch.call(this, "LinkInfo", name, new Variant(linkInfo));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant linkSources(Variant lastParam) {
		return Dispatch.call(this, "LinkSources", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant linkSources() {
		return Dispatch.call(this, "LinkSources");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Mailer
	 */
	public Mailer getMailer() {
		return new Mailer(Dispatch.get(this, "Mailer").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void mergeWorkbook(Variant lastParam) {
		Dispatch.call(this, "MergeWorkbook", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getModules() {
		return new Sheets(Dispatch.get(this, "Modules").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getMultiUserEditing() {
		return Dispatch.get(this, "MultiUserEditing").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Names
	 */
	public Names getNames() {
		return new Names(Dispatch.get(this, "Names").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Window
	 */
	public Window newWindow() {
		return new Window(Dispatch.call(this, "NewWindow").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSave() {
		return Dispatch.get(this, "OnSave").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSave(String lastParam) {
		Dispatch.call(this, "OnSave", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetActivate() {
		return Dispatch.get(this, "OnSheetActivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetActivate(String lastParam) {
		Dispatch.call(this, "OnSheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetDeactivate() {
		return Dispatch.get(this, "OnSheetDeactivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetDeactivate(String lastParam) {
		Dispatch.call(this, "OnSheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param readOnly an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void openLinks(String name, Variant readOnly, Variant lastParam) {
		Dispatch.call(this, "OpenLinks", name, readOnly, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param readOnly an input-parameter of type Variant
	 */
	public void openLinks(String name, Variant readOnly) {
		Dispatch.call(this, "OpenLinks", name, readOnly);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 */
	public void openLinks(String name) {
		Dispatch.call(this, "OpenLinks", name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getPath() {
		return Dispatch.get(this, "Path").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPersonalViewListSettings() {
		return Dispatch.get(this, "PersonalViewListSettings").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPersonalViewListSettings(boolean lastParam) {
		Dispatch.call(this, "PersonalViewListSettings", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPersonalViewPrintSettings() {
		return Dispatch.get(this, "PersonalViewPrintSettings").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPersonalViewPrintSettings(boolean lastParam) {
		Dispatch.call(this, "PersonalViewPrintSettings", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotCaches
	 */
	public PivotCaches pivotCaches() {
		return new PivotCaches(Dispatch.call(this, "PivotCaches").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void post(Variant lastParam) {
		Dispatch.call(this, "Post", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void post() {
		Dispatch.call(this, "Post");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPrecisionAsDisplayed() {
		return Dispatch.get(this, "PrecisionAsDisplayed").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPrecisionAsDisplayed(boolean lastParam) {
		Dispatch.call(this, "PrecisionAsDisplayed", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to) {
		Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from) {
		Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _PrintOut() {
		Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printPreview(Variant lastParam) {
		Dispatch.call(this, "PrintPreview", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printPreview() {
		Dispatch.call(this, "PrintPreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param structure an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant structure, Variant lastParam) {
		Dispatch.call(this, "Protect", password, structure, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param structure an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant structure) {
		Dispatch.call(this, "Protect", password, structure);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 */
	public void protect(Variant password) {
		Dispatch.call(this, "Protect", password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void protect() {
		Dispatch.call(this, "Protect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant lastParam) {
		Dispatch.call(this, "ProtectSharing", filename, password, writeResPassword, readOnlyRecommended, createBackup, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup) {
		Dispatch.call(this, "ProtectSharing", filename, password, writeResPassword, readOnlyRecommended, createBackup);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename, Variant password, Variant writeResPassword, Variant readOnlyRecommended) {
		Dispatch.call(this, "ProtectSharing", filename, password, writeResPassword, readOnlyRecommended);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename, Variant password, Variant writeResPassword) {
		Dispatch.call(this, "ProtectSharing", filename, password, writeResPassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename, Variant password) {
		Dispatch.call(this, "ProtectSharing", filename, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 */
	public void protectSharing(Variant filename) {
		Dispatch.call(this, "ProtectSharing", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void protectSharing() {
		Dispatch.call(this, "ProtectSharing");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectStructure() {
		return Dispatch.get(this, "ProtectStructure").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectWindows() {
		return Dispatch.get(this, "ProtectWindows").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getReadOnly() {
		return Dispatch.get(this, "ReadOnly").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getReadOnlyRecommended() {
		return Dispatch.get(this, "ReadOnlyRecommended").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void refreshAll() {
		Dispatch.call(this, "RefreshAll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void reply() {
		Dispatch.call(this, "Reply");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void replyAll() {
		Dispatch.call(this, "ReplyAll");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void removeUser(int lastParam) {
		Dispatch.call(this, "RemoveUser", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getRevisionNumber() {
		return Dispatch.get(this, "RevisionNumber").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void route() {
		Dispatch.call(this, "Route");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getRouted() {
		return Dispatch.get(this, "Routed").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type RoutingSlip
	 */
	public RoutingSlip getRoutingSlip() {
		return new RoutingSlip(Dispatch.get(this, "RoutingSlip").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void runAutoMacros(int lastParam) {
		Dispatch.call(this, "RunAutoMacros", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void save() {
		Dispatch.call(this, "Save");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param accessMode an input-parameter of type int
	 * @param conflictResolution an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, int accessMode, Variant conflictResolution, Variant addToMru, Variant textCodepage, Variant lastParam) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, new Variant(accessMode), conflictResolution, addToMru, textCodepage, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param accessMode an input-parameter of type int
	 * @param conflictResolution an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, int accessMode, Variant conflictResolution, Variant addToMru, Variant textCodepage) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, new Variant(accessMode), conflictResolution, addToMru, textCodepage});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param accessMode an input-parameter of type int
	 * @param conflictResolution an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, int accessMode, Variant conflictResolution, Variant addToMru) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, new Variant(accessMode), conflictResolution, addToMru});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param accessMode an input-parameter of type int
	 * @param conflictResolution an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, int accessMode, Variant conflictResolution) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, new Variant(accessMode), conflictResolution);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param accessMode an input-parameter of type int
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, int accessMode) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, new Variant(accessMode));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password, Variant writeResPassword) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat, Variant password) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param fileFormat an input-parameter of type Variant
	 */
	public void saveAs(Variant filename, Variant fileFormat) {
		Dispatch.call(this, "SaveAs", filename, fileFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 */
	public void saveAs(Variant filename) {
		Dispatch.call(this, "SaveAs", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void saveAs() {
		Dispatch.call(this, "SaveAs");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveCopyAs(Variant lastParam) {
		Dispatch.call(this, "SaveCopyAs", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void saveCopyAs() {
		Dispatch.call(this, "SaveCopyAs");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSaved() {
		return Dispatch.get(this, "Saved").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSaved(boolean lastParam) {
		Dispatch.call(this, "Saved", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSaveLinkValues() {
		return Dispatch.get(this, "SaveLinkValues").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSaveLinkValues(boolean lastParam) {
		Dispatch.call(this, "SaveLinkValues", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param recipients an input-parameter of type Variant
	 * @param subject an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void sendMail(Variant recipients, Variant subject, Variant lastParam) {
		Dispatch.call(this, "SendMail", recipients, subject, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param recipients an input-parameter of type Variant
	 * @param subject an input-parameter of type Variant
	 */
	public void sendMail(Variant recipients, Variant subject) {
		Dispatch.call(this, "SendMail", recipients, subject);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param recipients an input-parameter of type Variant
	 */
	public void sendMail(Variant recipients) {
		Dispatch.call(this, "SendMail", recipients);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFormat an input-parameter of type Variant
	 * @param lastParam an input-parameter of type int
	 */
	public void sendMailer(Variant fileFormat, int lastParam) {
		Dispatch.call(this, "SendMailer", fileFormat, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param fileFormat an input-parameter of type Variant
	 */
	public void sendMailer(Variant fileFormat) {
		Dispatch.call(this, "SendMailer", fileFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void sendMailer() {
		Dispatch.call(this, "SendMailer");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setLinkOnData(String name, Variant lastParam) {
		Dispatch.call(this, "SetLinkOnData", name, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type String
	 */
	public void setLinkOnData(String name) {
		Dispatch.call(this, "SetLinkOnData", name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getSheets() {
		return new Sheets(Dispatch.get(this, "Sheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowConflictHistory() {
		return Dispatch.get(this, "ShowConflictHistory").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowConflictHistory(boolean lastParam) {
		Dispatch.call(this, "ShowConflictHistory", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Styles
	 */
	public Styles getStyles() {
		return new Styles(Dispatch.get(this, "Styles").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getSubject() {
		return Dispatch.get(this, "Subject").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setSubject(String lastParam) {
		Dispatch.call(this, "Subject", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getTitle() {
		return Dispatch.get(this, "Title").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setTitle(String lastParam) {
		Dispatch.call(this, "Title", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void unprotect(Variant lastParam) {
		Dispatch.call(this, "Unprotect", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unprotect() {
		Dispatch.call(this, "Unprotect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void unprotectSharing(Variant lastParam) {
		Dispatch.call(this, "UnprotectSharing", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unprotectSharing() {
		Dispatch.call(this, "UnprotectSharing");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void updateFromFile() {
		Dispatch.call(this, "UpdateFromFile");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void updateLink(Variant name, Variant lastParam) {
		Dispatch.call(this, "UpdateLink", name, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param name an input-parameter of type Variant
	 */
	public void updateLink(Variant name) {
		Dispatch.call(this, "UpdateLink", name);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void updateLink() {
		Dispatch.call(this, "UpdateLink");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getUpdateRemoteReferences() {
		return Dispatch.get(this, "UpdateRemoteReferences").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setUpdateRemoteReferences(boolean lastParam) {
		Dispatch.call(this, "UpdateRemoteReferences", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getUserControl() {
		return Dispatch.get(this, "UserControl").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setUserControl(boolean lastParam) {
		Dispatch.call(this, "UserControl", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getUserStatus() {
		return Dispatch.get(this, "UserStatus");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type CustomViews
	 */
	public CustomViews getCustomViews() {
		return new CustomViews(Dispatch.get(this, "CustomViews").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Windows
	 */
	public Windows getWindows() {
		return new Windows(Dispatch.get(this, "Windows").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getWorksheets() {
		return new Sheets(Dispatch.get(this, "Worksheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWriteReserved() {
		return Dispatch.get(this, "WriteReserved").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getWriteReservedBy() {
		return Dispatch.get(this, "WriteReservedBy").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4IntlMacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4IntlMacroSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Sheets
	 */
	public Sheets getExcel4MacroSheets() {
		return new Sheets(Dispatch.get(this, "Excel4MacroSheets").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTemplateRemoveExtData() {
		return Dispatch.get(this, "TemplateRemoveExtData").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTemplateRemoveExtData(boolean lastParam) {
		Dispatch.call(this, "TemplateRemoveExtData", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void highlightChangesOptions(Variant when, Variant who, Variant lastParam) {
		Dispatch.call(this, "HighlightChangesOptions", when, who, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 */
	public void highlightChangesOptions(Variant when, Variant who) {
		Dispatch.call(this, "HighlightChangesOptions", when, who);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 */
	public void highlightChangesOptions(Variant when) {
		Dispatch.call(this, "HighlightChangesOptions", when);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void highlightChangesOptions() {
		Dispatch.call(this, "HighlightChangesOptions");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHighlightChangesOnScreen() {
		return Dispatch.get(this, "HighlightChangesOnScreen").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHighlightChangesOnScreen(boolean lastParam) {
		Dispatch.call(this, "HighlightChangesOnScreen", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getKeepChangeHistory() {
		return Dispatch.get(this, "KeepChangeHistory").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setKeepChangeHistory(boolean lastParam) {
		Dispatch.call(this, "KeepChangeHistory", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getListChangesOnNewSheet() {
		return Dispatch.get(this, "ListChangesOnNewSheet").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setListChangesOnNewSheet(boolean lastParam) {
		Dispatch.call(this, "ListChangesOnNewSheet", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param days an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 */
	public void purgeChangeHistoryNow(int days, Variant lastParam) {
		Dispatch.call(this, "PurgeChangeHistoryNow", new Variant(days), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param days an input-parameter of type int
	 */
	public void purgeChangeHistoryNow(int days) {
		Dispatch.call(this, "PurgeChangeHistoryNow", new Variant(days));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void acceptAllChanges(Variant when, Variant who, Variant lastParam) {
		Dispatch.call(this, "AcceptAllChanges", when, who, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 */
	public void acceptAllChanges(Variant when, Variant who) {
		Dispatch.call(this, "AcceptAllChanges", when, who);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 */
	public void acceptAllChanges(Variant when) {
		Dispatch.call(this, "AcceptAllChanges", when);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void acceptAllChanges() {
		Dispatch.call(this, "AcceptAllChanges");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void rejectAllChanges(Variant when, Variant who, Variant lastParam) {
		Dispatch.call(this, "RejectAllChanges", when, who, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 * @param who an input-parameter of type Variant
	 */
	public void rejectAllChanges(Variant when, Variant who) {
		Dispatch.call(this, "RejectAllChanges", when, who);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param when an input-parameter of type Variant
	 */
	public void rejectAllChanges(Variant when) {
		Dispatch.call(this, "RejectAllChanges", when);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void rejectAllChanges() {
		Dispatch.call(this, "RejectAllChanges");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData, Variant lastParam) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 * @param readData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount, Variant readData) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount, readData});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 * @param pageFieldWrapCount an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder, Variant pageFieldWrapCount) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder, pageFieldWrapCount});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 * @param pageFieldOrder an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache, Variant pageFieldOrder) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache, pageFieldOrder});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 * @param optimizeCache an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery, Variant optimizeCache) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery, optimizeCache});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 * @param backgroundQuery an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved, Variant backgroundQuery) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved, backgroundQuery});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 * @param reserved an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage, Variant reserved) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage, reserved});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 * @param autoPage an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat, Variant autoPage) {
		Dispatch.callN(this, "PivotTableWizard", new Object[] { sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat, autoPage});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 * @param hasAutoFormat an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData, Variant hasAutoFormat) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData, hasAutoFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 * @param saveData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand, Variant saveData) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand, saveData);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 * @param columnGrand an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand, Variant columnGrand) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand, columnGrand);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 * @param rowGrand an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName, Variant rowGrand) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName, rowGrand);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 * @param tableName an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination, Variant tableName) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination, tableName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 * @param tableDestination an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData, Variant tableDestination) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData, tableDestination);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 * @param sourceData an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType, Variant sourceData) {
		Dispatch.call(this, "PivotTableWizard", sourceType, sourceData);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sourceType an input-parameter of type Variant
	 */
	public void pivotTableWizard(Variant sourceType) {
		Dispatch.call(this, "PivotTableWizard", sourceType);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void pivotTableWizard() {
		Dispatch.call(this, "PivotTableWizard");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void resetColors() {
		Dispatch.call(this, "ResetColors");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getVBProject() {
		return Dispatch.get(this, "VBProject");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 * @param newWindow an input-parameter of type Variant
	 * @param addHistory an input-parameter of type Variant
	 * @param extraInfo an input-parameter of type Variant
	 * @param method an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress, Variant newWindow, Variant addHistory, Variant extraInfo, Variant method, Variant lastParam) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress, newWindow, addHistory, extraInfo, method, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 * @param newWindow an input-parameter of type Variant
	 * @param addHistory an input-parameter of type Variant
	 * @param extraInfo an input-parameter of type Variant
	 * @param method an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress, Variant newWindow, Variant addHistory, Variant extraInfo, Variant method) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress, newWindow, addHistory, extraInfo, method);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 * @param newWindow an input-parameter of type Variant
	 * @param addHistory an input-parameter of type Variant
	 * @param extraInfo an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress, Variant newWindow, Variant addHistory, Variant extraInfo) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress, newWindow, addHistory, extraInfo);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 * @param newWindow an input-parameter of type Variant
	 * @param addHistory an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress, Variant newWindow, Variant addHistory) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress, newWindow, addHistory);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 * @param newWindow an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress, Variant newWindow) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress, newWindow);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 * @param subAddress an input-parameter of type Variant
	 */
	public void followHyperlink(String address, Variant subAddress) {
		Dispatch.call(this, "FollowHyperlink", address, subAddress);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param address an input-parameter of type String
	 */
	public void followHyperlink(String address) {
		Dispatch.call(this, "FollowHyperlink", address);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void addToFavorites() {
		Dispatch.call(this, "AddToFavorites");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getIsInplace() {
		return Dispatch.get(this, "IsInplace").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate, Variant lastParam) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to) {
		Dispatch.call(this, "PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void printOut(Variant from) {
		Dispatch.call(this, "PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printOut() {
		Dispatch.call(this, "PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void webPagePreview() {
		Dispatch.call(this, "WebPagePreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PublishObjects
	 */
	public PublishObjects getPublishObjects() {
		return new PublishObjects(Dispatch.get(this, "PublishObjects").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type WebOptions
	 */
	public WebOptions getWebOptions() {
		return new WebOptions(Dispatch.get(this, "WebOptions").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void reloadAs(int lastParam) {
		Dispatch.call(this, "ReloadAs", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.HTMLProject
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.HTMLProject getHTMLProject() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.HTMLProject(Dispatch.get(this, "HTMLProject").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getEnvelopeVisible() {
		return Dispatch.get(this, "EnvelopeVisible").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setEnvelopeVisible(boolean lastParam) {
		Dispatch.call(this, "EnvelopeVisible", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCalculationVersion() {
		return Dispatch.get(this, "CalculationVersion").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void dummy1(int lastParam) {
		Dispatch.call(this, "Dummy1", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void sblt(String lastParam) {
		Dispatch.call(this, "sblt", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getVBASigned() {
		return Dispatch.get(this, "VBASigned").toBoolean();
	}

}
