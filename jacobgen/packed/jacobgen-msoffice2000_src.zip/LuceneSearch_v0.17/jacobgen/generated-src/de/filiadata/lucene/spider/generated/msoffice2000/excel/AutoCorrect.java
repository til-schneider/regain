/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class AutoCorrect extends Dispatch {

	public static final String componentName = "Excel.AutoCorrect";

	public AutoCorrect() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public AutoCorrect(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public AutoCorrect(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param what an input-parameter of type String
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant addReplacement(String what, String lastParam) {
		return Dispatch.call(this, "AddReplacement", what, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCapitalizeNamesOfDays() {
		return Dispatch.get(this, "CapitalizeNamesOfDays").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCapitalizeNamesOfDays(boolean lastParam) {
		Dispatch.call(this, "CapitalizeNamesOfDays", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 * @return the result is of type Variant
	 */
	public Variant deleteReplacement(String lastParam) {
		return Dispatch.call(this, "DeleteReplacement", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getReplacementList(Variant lastParam) {
		return Dispatch.call(this, "ReplacementList", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getReplacementList() {
		return Dispatch.get(this, "ReplacementList");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setReplacementList(Variant index, Variant lastParam) {
		Dispatch.call(this, "ReplacementList", index, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void setReplacementList() {
		Dispatch.call(this, "ReplacementList");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getReplaceText() {
		return Dispatch.get(this, "ReplaceText").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setReplaceText(boolean lastParam) {
		Dispatch.call(this, "ReplaceText", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getTwoInitialCapitals() {
		return Dispatch.get(this, "TwoInitialCapitals").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setTwoInitialCapitals(boolean lastParam) {
		Dispatch.call(this, "TwoInitialCapitals", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCorrectSentenceCap() {
		return Dispatch.get(this, "CorrectSentenceCap").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCorrectSentenceCap(boolean lastParam) {
		Dispatch.call(this, "CorrectSentenceCap", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getCorrectCapsLock() {
		return Dispatch.get(this, "CorrectCapsLock").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setCorrectCapsLock(boolean lastParam) {
		Dispatch.call(this, "CorrectCapsLock", new Variant(lastParam));
	}

}
