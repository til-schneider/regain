/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpDialogFontStyle {

	public static final int ppDialogFontStyleMixed = -2;
	public static final int ppDialogSmall = -1;
	public static final int ppDialogItalic = 0;
}
