/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlLegendPosition {

	public static final int xlLegendPositionBottom = -4107;
	public static final int xlLegendPositionCorner = 2;
	public static final int xlLegendPositionLeft = -4131;
	public static final int xlLegendPositionRight = -4152;
	public static final int xlLegendPositionTop = -4160;
}
