/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlAxisCrosses {

	public static final int xlAxisCrossesAutomatic = -4105;
	public static final int xlAxisCrossesCustom = -4114;
	public static final int xlAxisCrossesMaximum = 2;
	public static final int xlAxisCrossesMinimum = 4;
}
