/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class QueryTable extends _QueryTable {

	public static final String componentName = "Excel.QueryTable";

	public QueryTable() {
		super(componentName);
	}

	public QueryTable(Dispatch d) {
		super(d);
	}
}
