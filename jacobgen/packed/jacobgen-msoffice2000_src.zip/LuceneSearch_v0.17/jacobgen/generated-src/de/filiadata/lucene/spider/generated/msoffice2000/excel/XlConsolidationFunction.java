/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlConsolidationFunction {

	public static final int xlAverage = -4106;
	public static final int xlCount = -4112;
	public static final int xlCountNums = -4113;
	public static final int xlMax = -4136;
	public static final int xlMin = -4139;
	public static final int xlProduct = -4149;
	public static final int xlStDev = -4155;
	public static final int xlStDevP = -4156;
	public static final int xlSum = -4157;
	public static final int xlVar = -4164;
	public static final int xlVarP = -4165;
	public static final int xlUnknown = 1000;
}
