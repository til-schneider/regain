/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPasteSpecialOperation {

	public static final int xlPasteSpecialOperationAdd = 2;
	public static final int xlPasteSpecialOperationDivide = 5;
	public static final int xlPasteSpecialOperationMultiply = 4;
	public static final int xlPasteSpecialOperationNone = -4142;
	public static final int xlPasteSpecialOperationSubtract = 3;
}
