/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlReferenceType {

	public static final int xlAbsolute = 1;
	public static final int xlAbsRowRelColumn = 2;
	public static final int xlRelative = 4;
	public static final int xlRelRowAbsColumn = 3;
}
