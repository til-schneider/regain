/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class _Chart extends Dispatch {

	public static final String componentName = "Excel._Chart";

	public _Chart() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public _Chart(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public _Chart(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void copy(Variant before, Variant lastParam) {
		Dispatch.call(this, "Copy", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void copy(Variant before) {
		Dispatch.call(this, "Copy", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copy() {
		Dispatch.call(this, "Copy");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCodeName() {
		return Dispatch.get(this, "CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_CodeName() {
		return Dispatch.get(this, "_CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void set_CodeName(String lastParam) {
		Dispatch.call(this, "_CodeName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIndex() {
		return Dispatch.get(this, "Index").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void move(Variant before, Variant lastParam) {
		Dispatch.call(this, "Move", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void move(Variant before) {
		Dispatch.call(this, "Move", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void move() {
		Dispatch.call(this, "Move");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getNext() {
		return Dispatch.get(this, "Next");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnDoubleClick() {
		return Dispatch.get(this, "OnDoubleClick").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnDoubleClick(String lastParam) {
		Dispatch.call(this, "OnDoubleClick", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetActivate() {
		return Dispatch.get(this, "OnSheetActivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetActivate(String lastParam) {
		Dispatch.call(this, "OnSheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetDeactivate() {
		return Dispatch.get(this, "OnSheetDeactivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetDeactivate(String lastParam) {
		Dispatch.call(this, "OnSheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PageSetup
	 */
	public PageSetup getPageSetup() {
		return new PageSetup(Dispatch.get(this, "PageSetup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPrevious() {
		return Dispatch.get(this, "Previous");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to) {
		Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from) {
		Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _PrintOut() {
		Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printPreview(Variant lastParam) {
		Dispatch.call(this, "PrintPreview", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printPreview() {
		Dispatch.call(this, "PrintPreview");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios, Variant lastParam) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects) {
		Dispatch.call(this, "Protect", password, drawingObjects);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 */
	public void protect(Variant password) {
		Dispatch.call(this, "Protect", password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void protect() {
		Dispatch.call(this, "Protect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectContents() {
		return Dispatch.get(this, "ProtectContents").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectDrawingObjects() {
		return Dispatch.get(this, "ProtectDrawingObjects").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectionMode() {
		return Dispatch.get(this, "ProtectionMode").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _Dummy23() {
		Dispatch.call(this, "_Dummy23");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage, Variant lastParam) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat) {
		Dispatch.call(this, "SaveAs", filename, fileFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 */
	public void saveAs(String filename) {
		Dispatch.call(this, "SaveAs", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void select(Variant lastParam) {
		Dispatch.call(this, "Select", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void select() {
		Dispatch.call(this, "Select");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void unprotect(Variant lastParam) {
		Dispatch.call(this, "Unprotect", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unprotect() {
		Dispatch.call(this, "Unprotect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getVisible() {
		return Dispatch.get(this, "Visible").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setVisible(int lastParam) {
		Dispatch.call(this, "Visible", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Shapes
	 */
	public Shapes getShapes() {
		return new Shapes(Dispatch.get(this, "Shapes").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param legendKey an input-parameter of type Variant
	 * @param autoText an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void applyDataLabels(int type, Variant legendKey, Variant autoText, Variant lastParam) {
		Dispatch.call(this, "ApplyDataLabels", new Variant(type), legendKey, autoText, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param legendKey an input-parameter of type Variant
	 * @param autoText an input-parameter of type Variant
	 */
	public void applyDataLabels(int type, Variant legendKey, Variant autoText) {
		Dispatch.call(this, "ApplyDataLabels", new Variant(type), legendKey, autoText);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 * @param legendKey an input-parameter of type Variant
	 */
	public void applyDataLabels(int type, Variant legendKey) {
		Dispatch.call(this, "ApplyDataLabels", new Variant(type), legendKey);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type int
	 */
	public void applyDataLabels(int type) {
		Dispatch.call(this, "ApplyDataLabels", new Variant(type));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void applyDataLabels() {
		Dispatch.call(this, "ApplyDataLabels");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object arcs(Variant lastParam) {
		return Dispatch.call(this, "Arcs", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object arcs() {
		return Dispatch.call(this, "Arcs");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getArea3DGroup() {
		return new ChartGroup(Dispatch.get(this, "Area3DGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object areaGroups(Variant lastParam) {
		return Dispatch.call(this, "AreaGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object areaGroups() {
		return Dispatch.call(this, "AreaGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param gallery an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 */
	public void autoFormat(int gallery, Variant lastParam) {
		Dispatch.call(this, "AutoFormat", new Variant(gallery), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param gallery an input-parameter of type int
	 */
	public void autoFormat(int gallery) {
		Dispatch.call(this, "AutoFormat", new Variant(gallery));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getAutoScaling() {
		return Dispatch.get(this, "AutoScaling").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setAutoScaling(boolean lastParam) {
		Dispatch.call(this, "AutoScaling", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @param lastParam an input-parameter of type int
	 * @return the result is of type Object
	 */
	public Object axes(Variant type, int lastParam) {
		return Dispatch.call(this, "Axes", type, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param type an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object axes(Variant type) {
		return Dispatch.call(this, "Axes", type);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object axes() {
		return Dispatch.call(this, "Axes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setBackgroundPicture(String lastParam) {
		Dispatch.call(this, "SetBackgroundPicture", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getBar3DGroup() {
		return new ChartGroup(Dispatch.get(this, "Bar3DGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object barGroups(Variant lastParam) {
		return Dispatch.call(this, "BarGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object barGroups() {
		return Dispatch.call(this, "BarGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object buttons(Variant lastParam) {
		return Dispatch.call(this, "Buttons", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object buttons() {
		return Dispatch.call(this, "Buttons");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartArea
	 */
	public ChartArea getChartArea() {
		return new ChartArea(Dispatch.get(this, "ChartArea").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object chartGroups(Variant lastParam) {
		return Dispatch.call(this, "ChartGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object chartGroups() {
		return Dispatch.call(this, "ChartGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object chartObjects(Variant lastParam) {
		return Dispatch.call(this, "ChartObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object chartObjects() {
		return Dispatch.call(this, "ChartObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartTitle
	 */
	public ChartTitle getChartTitle() {
		return new ChartTitle(Dispatch.get(this, "ChartTitle").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 * @param hasLegend an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param categoryTitle an input-parameter of type Variant
	 * @param valueTitle an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels, Variant hasLegend, Variant title, Variant categoryTitle, Variant valueTitle, Variant lastParam) {
		Dispatch.callN(this, "ChartWizard", new Object[] { source, gallery, format, plotBy, categoryLabels, seriesLabels, hasLegend, title, categoryTitle, valueTitle, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 * @param hasLegend an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param categoryTitle an input-parameter of type Variant
	 * @param valueTitle an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels, Variant hasLegend, Variant title, Variant categoryTitle, Variant valueTitle) {
		Dispatch.callN(this, "ChartWizard", new Object[] { source, gallery, format, plotBy, categoryLabels, seriesLabels, hasLegend, title, categoryTitle, valueTitle});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 * @param hasLegend an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 * @param categoryTitle an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels, Variant hasLegend, Variant title, Variant categoryTitle) {
		Dispatch.callN(this, "ChartWizard", new Object[] { source, gallery, format, plotBy, categoryLabels, seriesLabels, hasLegend, title, categoryTitle});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 * @param hasLegend an input-parameter of type Variant
	 * @param title an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels, Variant hasLegend, Variant title) {
		Dispatch.call(this, "ChartWizard", source, gallery, format, plotBy, categoryLabels, seriesLabels, hasLegend, title);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 * @param hasLegend an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels, Variant hasLegend) {
		Dispatch.call(this, "ChartWizard", source, gallery, format, plotBy, categoryLabels, seriesLabels, hasLegend);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 * @param seriesLabels an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels, Variant seriesLabels) {
		Dispatch.call(this, "ChartWizard", source, gallery, format, plotBy, categoryLabels, seriesLabels);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 * @param categoryLabels an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy, Variant categoryLabels) {
		Dispatch.call(this, "ChartWizard", source, gallery, format, plotBy, categoryLabels);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 * @param plotBy an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format, Variant plotBy) {
		Dispatch.call(this, "ChartWizard", source, gallery, format, plotBy);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 * @param format an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery, Variant format) {
		Dispatch.call(this, "ChartWizard", source, gallery, format);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 * @param gallery an input-parameter of type Variant
	 */
	public void chartWizard(Variant source, Variant gallery) {
		Dispatch.call(this, "ChartWizard", source, gallery);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Variant
	 */
	public void chartWizard(Variant source) {
		Dispatch.call(this, "ChartWizard", source);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void chartWizard() {
		Dispatch.call(this, "ChartWizard");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object checkBoxes(Variant lastParam) {
		return Dispatch.call(this, "CheckBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object checkBoxes() {
		return Dispatch.call(this, "CheckBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest, Variant lastParam) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 * @param alwaysSuggest an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase, Variant alwaysSuggest) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase, alwaysSuggest);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 * @param ignoreUppercase an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary, Variant ignoreUppercase) {
		Dispatch.call(this, "CheckSpelling", customDictionary, ignoreUppercase);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param customDictionary an input-parameter of type Variant
	 */
	public void checkSpelling(Variant customDictionary) {
		Dispatch.call(this, "CheckSpelling", customDictionary);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void checkSpelling() {
		Dispatch.call(this, "CheckSpelling");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getColumn3DGroup() {
		return new ChartGroup(Dispatch.get(this, "Column3DGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object columnGroups(Variant lastParam) {
		return Dispatch.call(this, "ColumnGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object columnGroups() {
		return Dispatch.call(this, "ColumnGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param appearance an input-parameter of type int
	 * @param format an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void copyPicture(int appearance, int format, int lastParam) {
		Dispatch.call(this, "CopyPicture", new Variant(appearance), new Variant(format), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param appearance an input-parameter of type int
	 * @param format an input-parameter of type int
	 */
	public void copyPicture(int appearance, int format) {
		Dispatch.call(this, "CopyPicture", new Variant(appearance), new Variant(format));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param appearance an input-parameter of type int
	 */
	public void copyPicture(int appearance) {
		Dispatch.call(this, "CopyPicture", new Variant(appearance));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copyPicture() {
		Dispatch.call(this, "CopyPicture");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Corners
	 */
	public Corners getCorners() {
		return new Corners(Dispatch.get(this, "Corners").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param size an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 * @param containsRTF an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void createPublisher(Variant edition, int appearance, int size, Variant containsPICT, Variant containsBIFF, Variant containsRTF, Variant lastParam) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), new Variant(size), containsPICT, containsBIFF, containsRTF, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param size an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 * @param containsRTF an input-parameter of type Variant
	 */
	public void createPublisher(Variant edition, int appearance, int size, Variant containsPICT, Variant containsBIFF, Variant containsRTF) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), new Variant(size), containsPICT, containsBIFF, containsRTF);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param size an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 * @param containsBIFF an input-parameter of type Variant
	 */
	public void createPublisher(Variant edition, int appearance, int size, Variant containsPICT, Variant containsBIFF) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), new Variant(size), containsPICT, containsBIFF);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param size an input-parameter of type int
	 * @param containsPICT an input-parameter of type Variant
	 */
	public void createPublisher(Variant edition, int appearance, int size, Variant containsPICT) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), new Variant(size), containsPICT);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 * @param size an input-parameter of type int
	 */
	public void createPublisher(Variant edition, int appearance, int size) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance), new Variant(size));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 * @param appearance an input-parameter of type int
	 */
	public void createPublisher(Variant edition, int appearance) {
		Dispatch.call(this, "CreatePublisher", edition, new Variant(appearance));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param edition an input-parameter of type Variant
	 */
	public void createPublisher(Variant edition) {
		Dispatch.call(this, "CreatePublisher", edition);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void createPublisher() {
		Dispatch.call(this, "CreatePublisher");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type DataTable
	 */
	public DataTable getDataTable() {
		return new DataTable(Dispatch.get(this, "DataTable").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDepthPercent() {
		return Dispatch.get(this, "DepthPercent").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDepthPercent(int lastParam) {
		Dispatch.call(this, "DepthPercent", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void deselect() {
		Dispatch.call(this, "Deselect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getDisplayBlanksAs() {
		return Dispatch.get(this, "DisplayBlanksAs").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setDisplayBlanksAs(int lastParam) {
		Dispatch.call(this, "DisplayBlanksAs", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object doughnutGroups(Variant lastParam) {
		return Dispatch.call(this, "DoughnutGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object doughnutGroups() {
		return Dispatch.call(this, "DoughnutGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object drawings(Variant lastParam) {
		return Dispatch.call(this, "Drawings", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object drawings() {
		return Dispatch.call(this, "Drawings");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object drawingObjects(Variant lastParam) {
		return Dispatch.call(this, "DrawingObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object drawingObjects() {
		return Dispatch.call(this, "DrawingObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object dropDowns(Variant lastParam) {
		return Dispatch.call(this, "DropDowns", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object dropDowns() {
		return Dispatch.call(this, "DropDowns");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getElevation() {
		return Dispatch.get(this, "Elevation").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setElevation(int lastParam) {
		Dispatch.call(this, "Elevation", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant evaluate(Variant lastParam) {
		return Dispatch.call(this, "Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant _Evaluate(Variant lastParam) {
		return Dispatch.call(this, "_Evaluate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Floor
	 */
	public Floor getFloor() {
		return new Floor(Dispatch.get(this, "Floor").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getGapDepth() {
		return Dispatch.get(this, "GapDepth").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setGapDepth(int lastParam) {
		Dispatch.call(this, "GapDepth", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object groupBoxes(Variant lastParam) {
		return Dispatch.call(this, "GroupBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object groupBoxes() {
		return Dispatch.call(this, "GroupBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object groupObjects(Variant lastParam) {
		return Dispatch.call(this, "GroupObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object groupObjects() {
		return Dispatch.call(this, "GroupObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getHasAxis(Variant index1, Variant lastParam) {
		return Dispatch.call(this, "HasAxis", index1, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant getHasAxis(Variant index1) {
		return Dispatch.call(this, "HasAxis", index1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getHasAxis() {
		return Dispatch.get(this, "HasAxis");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 * @param index2 an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setHasAxis(Variant index1, Variant index2, Variant lastParam) {
		Dispatch.call(this, "HasAxis", index1, index2, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param index1 an input-parameter of type Variant
	 */
	public void setHasAxis(Variant index1) {
		Dispatch.call(this, "HasAxis", index1);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void setHasAxis() {
		Dispatch.call(this, "HasAxis");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasDataTable() {
		return Dispatch.get(this, "HasDataTable").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasDataTable(boolean lastParam) {
		Dispatch.call(this, "HasDataTable", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasLegend() {
		return Dispatch.get(this, "HasLegend").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasLegend(boolean lastParam) {
		Dispatch.call(this, "HasLegend", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasTitle() {
		return Dispatch.get(this, "HasTitle").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasTitle(boolean lastParam) {
		Dispatch.call(this, "HasTitle", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getHeightPercent() {
		return Dispatch.get(this, "HeightPercent").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setHeightPercent(int lastParam) {
		Dispatch.call(this, "HeightPercent", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Hyperlinks
	 */
	public Hyperlinks getHyperlinks() {
		return new Hyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object labels(Variant lastParam) {
		return Dispatch.call(this, "Labels", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object labels() {
		return Dispatch.call(this, "Labels");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Legend
	 */
	public Legend getLegend() {
		return new Legend(Dispatch.get(this, "Legend").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getLine3DGroup() {
		return new ChartGroup(Dispatch.get(this, "Line3DGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object lineGroups(Variant lastParam) {
		return Dispatch.call(this, "LineGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object lineGroups() {
		return Dispatch.call(this, "LineGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object lines(Variant lastParam) {
		return Dispatch.call(this, "Lines", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object lines() {
		return Dispatch.call(this, "Lines");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object listBoxes(Variant lastParam) {
		return Dispatch.call(this, "ListBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object listBoxes() {
		return Dispatch.call(this, "ListBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param where an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Chart
	 */
	public Chart location(int where, Variant lastParam) {
		return new Chart(Dispatch.call(this, "Location", new Variant(where), lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param where an input-parameter of type int
	 * @return the result is of type Chart
	 */
	public Chart location(int where) {
		return new Chart(Dispatch.call(this, "Location", new Variant(where)).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object oLEObjects(Variant lastParam) {
		return Dispatch.call(this, "OLEObjects", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object oLEObjects() {
		return Dispatch.call(this, "OLEObjects");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object optionButtons(Variant lastParam) {
		return Dispatch.call(this, "OptionButtons", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object optionButtons() {
		return Dispatch.call(this, "OptionButtons");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object ovals(Variant lastParam) {
		return Dispatch.call(this, "Ovals", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object ovals() {
		return Dispatch.call(this, "Ovals");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void paste(Variant lastParam) {
		Dispatch.call(this, "Paste", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void paste() {
		Dispatch.call(this, "Paste");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getPerspective() {
		return Dispatch.get(this, "Perspective").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setPerspective(int lastParam) {
		Dispatch.call(this, "Perspective", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object pictures(Variant lastParam) {
		return Dispatch.call(this, "Pictures", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object pictures() {
		return Dispatch.call(this, "Pictures");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getPie3DGroup() {
		return new ChartGroup(Dispatch.get(this, "Pie3DGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object pieGroups(Variant lastParam) {
		return Dispatch.call(this, "PieGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object pieGroups() {
		return Dispatch.call(this, "PieGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PlotArea
	 */
	public PlotArea getPlotArea() {
		return new PlotArea(Dispatch.get(this, "PlotArea").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getPlotVisibleOnly() {
		return Dispatch.get(this, "PlotVisibleOnly").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setPlotVisibleOnly(boolean lastParam) {
		Dispatch.call(this, "PlotVisibleOnly", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object radarGroups(Variant lastParam) {
		return Dispatch.call(this, "RadarGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object radarGroups() {
		return Dispatch.call(this, "RadarGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object rectangles(Variant lastParam) {
		return Dispatch.call(this, "Rectangles", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object rectangles() {
		return Dispatch.call(this, "Rectangles");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getRightAngleAxes() {
		return Dispatch.get(this, "RightAngleAxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setRightAngleAxes(Variant lastParam) {
		Dispatch.call(this, "RightAngleAxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant getRotation() {
		return Dispatch.get(this, "Rotation");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setRotation(Variant lastParam) {
		Dispatch.call(this, "Rotation", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object scrollBars(Variant lastParam) {
		return Dispatch.call(this, "ScrollBars", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object scrollBars() {
		return Dispatch.call(this, "ScrollBars");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object seriesCollection(Variant lastParam) {
		return Dispatch.call(this, "SeriesCollection", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object seriesCollection() {
		return Dispatch.call(this, "SeriesCollection");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getSizeWithWindow() {
		return Dispatch.get(this, "SizeWithWindow").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setSizeWithWindow(boolean lastParam) {
		Dispatch.call(this, "SizeWithWindow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getShowWindow() {
		return Dispatch.get(this, "ShowWindow").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setShowWindow(boolean lastParam) {
		Dispatch.call(this, "ShowWindow", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object spinners(Variant lastParam) {
		return Dispatch.call(this, "Spinners", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object spinners() {
		return Dispatch.call(this, "Spinners");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getSubType() {
		return Dispatch.get(this, "SubType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setSubType(int lastParam) {
		Dispatch.call(this, "SubType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type ChartGroup
	 */
	public ChartGroup getSurfaceGroup() {
		return new ChartGroup(Dispatch.get(this, "SurfaceGroup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object textBoxes(Variant lastParam) {
		return Dispatch.call(this, "TextBoxes", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object textBoxes() {
		return Dispatch.call(this, "TextBoxes");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getType() {
		return Dispatch.get(this, "Type").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setType(int lastParam) {
		Dispatch.call(this, "Type", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getChartType() {
		return Dispatch.get(this, "ChartType").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setChartType(int lastParam) {
		Dispatch.call(this, "ChartType", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param chartType an input-parameter of type int
	 * @param lastParam an input-parameter of type Variant
	 */
	public void applyCustomType(int chartType, Variant lastParam) {
		Dispatch.call(this, "ApplyCustomType", new Variant(chartType), lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param chartType an input-parameter of type int
	 */
	public void applyCustomType(int chartType) {
		Dispatch.call(this, "ApplyCustomType", new Variant(chartType));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Walls
	 */
	public Walls getWalls() {
		return new Walls(Dispatch.get(this, "Walls").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getWallsAndGridlines2D() {
		return Dispatch.get(this, "WallsAndGridlines2D").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setWallsAndGridlines2D(boolean lastParam) {
		Dispatch.call(this, "WallsAndGridlines2D", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object xYGroups(Variant lastParam) {
		return Dispatch.call(this, "XYGroups", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object xYGroups() {
		return Dispatch.call(this, "XYGroups");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getBarShape() {
		return Dispatch.get(this, "BarShape").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setBarShape(int lastParam) {
		Dispatch.call(this, "BarShape", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getPlotBy() {
		return Dispatch.get(this, "PlotBy").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setPlotBy(int lastParam) {
		Dispatch.call(this, "PlotBy", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copyChartBuild() {
		Dispatch.call(this, "CopyChartBuild");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectFormatting() {
		return Dispatch.get(this, "ProtectFormatting").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setProtectFormatting(boolean lastParam) {
		Dispatch.call(this, "ProtectFormatting", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectData() {
		return Dispatch.get(this, "ProtectData").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setProtectData(boolean lastParam) {
		Dispatch.call(this, "ProtectData", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectGoalSeek() {
		return Dispatch.get(this, "ProtectGoalSeek").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setProtectGoalSeek(boolean lastParam) {
		Dispatch.call(this, "ProtectGoalSeek", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectSelection() {
		return Dispatch.get(this, "ProtectSelection").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setProtectSelection(boolean lastParam) {
		Dispatch.call(this, "ProtectSelection", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param x an input-parameter of type int
	 * @param y an input-parameter of type int
	 * @param elementID an input-parameter of type int
	 * @param arg1 an input-parameter of type int
	 * @param lastParam an input-parameter of type int
	 */
	public void getChartElement(int x, int y, int elementID, int arg1, int lastParam) {
		Dispatch.call(this, "GetChartElement", new Variant(x), new Variant(y), new Variant(elementID), new Variant(arg1), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Range
	 * @param lastParam an input-parameter of type Variant
	 */
	public void setSourceData(Range source, Variant lastParam) {
		Dispatch.call(this, "SetSourceData", source, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param source an input-parameter of type Range
	 */
	public void setSourceData(Range source) {
		Dispatch.call(this, "SetSourceData", source);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param filterName an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean export(String filename, Variant filterName, Variant lastParam) {
		return Dispatch.call(this, "Export", filename, filterName, lastParam).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param filterName an input-parameter of type Variant
	 * @return the result is of type boolean
	 */
	public boolean export(String filename, Variant filterName) {
		return Dispatch.call(this, "Export", filename, filterName).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @return the result is of type boolean
	 */
	public boolean export(String filename) {
		return Dispatch.call(this, "Export", filename).toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void refresh() {
		Dispatch.call(this, "Refresh");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PivotLayout
	 */
	public PivotLayout getPivotLayout() {
		return new PivotLayout(Dispatch.get(this, "PivotLayout").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getHasPivotFields() {
		return Dispatch.get(this, "HasPivotFields").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type boolean
	 */
	public void setHasPivotFields(boolean lastParam) {
		Dispatch.call(this, "HasPivotFields", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type de.filiadata.lucene.spider.generated.msofficeshared.Scripts
	 */
	public de.filiadata.lucene.spider.generated.msofficeshared.Scripts getScripts() {
		return new de.filiadata.lucene.spider.generated.msofficeshared.Scripts(Dispatch.get(this, "Scripts").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate, Variant lastParam) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param collate an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant collate) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile, collate);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void printOut(Variant from, Variant to) {
		Dispatch.call(this, "PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void printOut(Variant from) {
		Dispatch.call(this, "PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void printOut() {
		Dispatch.call(this, "PrintOut");
	}

}
