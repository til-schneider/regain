/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPictureAppearance {

	public static final int xlPrinter = 2;
	public static final int xlScreen = 1;
}
