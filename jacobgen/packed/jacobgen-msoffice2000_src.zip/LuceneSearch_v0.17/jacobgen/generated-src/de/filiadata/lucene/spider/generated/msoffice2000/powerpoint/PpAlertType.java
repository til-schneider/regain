/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpAlertType {

	public static final int ppAlertTypeOK = 0;
	public static final int ppAlertTypeOKCANCEL = 1;
	public static final int ppAlertTypeYESNO = 2;
	public static final int ppAlertTypeYESNOCANCEL = 3;
	public static final int ppAlertTypeBACKNEXTCLOSE = 4;
	public static final int ppAlertTypeRETRYCANCEL = 5;
	public static final int ppAlertTypeABORTRETRYIGNORE = 6;
}
