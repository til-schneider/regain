/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlFormControl {

	public static final int xlButtonControl = 0;
	public static final int xlCheckBox = 1;
	public static final int xlDropDown = 2;
	public static final int xlEditBox = 3;
	public static final int xlGroupBox = 4;
	public static final int xlLabel = 5;
	public static final int xlListBox = 6;
	public static final int xlOptionButton = 7;
	public static final int xlScrollBar = 8;
	public static final int xlSpinner = 9;
}
