/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpBaselineAlignment {

	public static final int ppBaselineAlignMixed = -2;
	public static final int ppBaselineAlignBaseline = 1;
	public static final int ppBaselineAlignTop = 2;
	public static final int ppBaselineAlignCenter = 3;
	public static final int ppBaselineAlignFarEast50 = 4;
}
