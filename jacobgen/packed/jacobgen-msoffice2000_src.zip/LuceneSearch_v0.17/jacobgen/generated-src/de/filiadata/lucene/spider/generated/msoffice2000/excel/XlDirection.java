/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDirection {

	public static final int xlDown = -4121;
	public static final int xlToLeft = -4159;
	public static final int xlToRight = -4161;
	public static final int xlUp = -4162;
}
