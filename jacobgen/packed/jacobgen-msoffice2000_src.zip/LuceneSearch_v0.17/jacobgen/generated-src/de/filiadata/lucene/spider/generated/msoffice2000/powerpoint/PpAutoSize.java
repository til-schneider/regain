/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpAutoSize {

	public static final int ppAutoSizeMixed = -2;
	public static final int ppAutoSizeNone = 0;
	public static final int ppAutoSizeShapeToFitText = 1;
}
