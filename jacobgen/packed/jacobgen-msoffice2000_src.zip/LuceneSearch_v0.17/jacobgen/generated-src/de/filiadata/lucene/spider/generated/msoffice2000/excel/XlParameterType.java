/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlParameterType {

	public static final int xlPrompt = 0;
	public static final int xlConstant = 1;
	public static final int xlRange = 2;
}
