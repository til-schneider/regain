/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class AppEvents extends Dispatch {

	public static final String componentName = "Excel.AppEvents";

	public AppEvents() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public AppEvents(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public AppEvents(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void newWorkbook(Workbook lastParam) {
		Dispatch.call(this, "NewWorkbook", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Range
	 */
	public void sheetSelectionChange(Object sh, Range lastParam) {
		Dispatch.call(this, "SheetSelectionChange", sh, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void sheetBeforeDoubleClick(Object sh, Range target, boolean lastParam) {
		Dispatch.call(this, "SheetBeforeDoubleClick", sh, target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param target an input-parameter of type Range
	 * @param lastParam an input-parameter of type boolean
	 */
	public void sheetBeforeRightClick(Object sh, Range target, boolean lastParam) {
		Dispatch.call(this, "SheetBeforeRightClick", sh, target, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetActivate(Object lastParam) {
		Dispatch.call(this, "SheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetDeactivate(Object lastParam) {
		Dispatch.call(this, "SheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Object
	 */
	public void sheetCalculate(Object lastParam) {
		Dispatch.call(this, "SheetCalculate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Range
	 */
	public void sheetChange(Object sh, Range lastParam) {
		Dispatch.call(this, "SheetChange", sh, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void workbookOpen(Workbook lastParam) {
		Dispatch.call(this, "WorkbookOpen", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void workbookActivate(Workbook lastParam) {
		Dispatch.call(this, "WorkbookActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void workbookDeactivate(Workbook lastParam) {
		Dispatch.call(this, "WorkbookDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type boolean
	 */
	public void workbookBeforeClose(Workbook wb, boolean lastParam) {
		Dispatch.call(this, "WorkbookBeforeClose", wb, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param saveAsUI an input-parameter of type boolean
	 * @param lastParam an input-parameter of type boolean
	 */
	public void workbookBeforeSave(Workbook wb, boolean saveAsUI, boolean lastParam) {
		Dispatch.call(this, "WorkbookBeforeSave", wb, new Variant(saveAsUI), new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type boolean
	 */
	public void workbookBeforePrint(Workbook wb, boolean lastParam) {
		Dispatch.call(this, "WorkbookBeforePrint", wb, new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type Object
	 */
	public void workbookNewSheet(Workbook wb, Object lastParam) {
		Dispatch.call(this, "WorkbookNewSheet", wb, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void workbookAddinInstall(Workbook lastParam) {
		Dispatch.call(this, "WorkbookAddinInstall", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Workbook
	 */
	public void workbookAddinUninstall(Workbook lastParam) {
		Dispatch.call(this, "WorkbookAddinUninstall", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowResize(Workbook wb, Window lastParam) {
		Dispatch.call(this, "WindowResize", wb, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowActivate(Workbook wb, Window lastParam) {
		Dispatch.call(this, "WindowActivate", wb, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param wb an input-parameter of type Workbook
	 * @param lastParam an input-parameter of type Window
	 */
	public void windowDeactivate(Workbook wb, Window lastParam) {
		Dispatch.call(this, "WindowDeactivate", wb, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param sh an input-parameter of type Object
	 * @param lastParam an input-parameter of type Hyperlink
	 */
	public void sheetFollowHyperlink(Object sh, Hyperlink lastParam) {
		Dispatch.call(this, "SheetFollowHyperlink", sh, lastParam);
	}

}
