/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpScrollBarStyle {

	public static final int ppScrollBarVertical = 0;
	public static final int ppScrollBarHorizontal = 1;
}
