/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class Module extends Dispatch {

	public static final String componentName = "Excel.Module";

	public Module() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public Module(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public Module(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void activate() {
		Dispatch.call(this, "Activate");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void copy(Variant before, Variant lastParam) {
		Dispatch.call(this, "Copy", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void copy(Variant before) {
		Dispatch.call(this, "Copy", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void copy() {
		Dispatch.call(this, "Copy");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void delete() {
		Dispatch.call(this, "Delete");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getCodeName() {
		return Dispatch.get(this, "CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String get_CodeName() {
		return Dispatch.get(this, "_CodeName").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void set_CodeName(String lastParam) {
		Dispatch.call(this, "_CodeName", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getIndex() {
		return Dispatch.get(this, "Index").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void move(Variant before, Variant lastParam) {
		Dispatch.call(this, "Move", before, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param before an input-parameter of type Variant
	 */
	public void move(Variant before) {
		Dispatch.call(this, "Move", before);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void move() {
		Dispatch.call(this, "Move");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setName(String lastParam) {
		Dispatch.call(this, "Name", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getNext() {
		return Dispatch.get(this, "Next");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnDoubleClick() {
		return Dispatch.get(this, "OnDoubleClick").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnDoubleClick(String lastParam) {
		Dispatch.call(this, "OnDoubleClick", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetActivate() {
		return Dispatch.get(this, "OnSheetActivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetActivate(String lastParam) {
		Dispatch.call(this, "OnSheetActivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type String
	 */
	public String getOnSheetDeactivate() {
		return Dispatch.get(this, "OnSheetDeactivate").toString();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type String
	 */
	public void setOnSheetDeactivate(String lastParam) {
		Dispatch.call(this, "OnSheetDeactivate", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type PageSetup
	 */
	public PageSetup getPageSetup() {
		return new PageSetup(Dispatch.get(this, "PageSetup").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getPrevious() {
		return Dispatch.get(this, "Previous");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile, Variant lastParam) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 * @param printToFile an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter, Variant printToFile) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter, printToFile);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 * @param activePrinter an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview, Variant activePrinter) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview, activePrinter);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 * @param preview an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies, Variant preview) {
		Dispatch.call(this, "_PrintOut", from, to, copies, preview);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 * @param copies an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to, Variant copies) {
		Dispatch.call(this, "_PrintOut", from, to, copies);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 * @param to an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from, Variant to) {
		Dispatch.call(this, "_PrintOut", from, to);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param from an input-parameter of type Variant
	 */
	public void _PrintOut(Variant from) {
		Dispatch.call(this, "_PrintOut", from);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _PrintOut() {
		Dispatch.call(this, "_PrintOut");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _Dummy18() {
		Dispatch.call(this, "_Dummy18");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios, Variant lastParam) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 * @param scenarios an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents, Variant scenarios) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents, scenarios);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 * @param contents an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects, Variant contents) {
		Dispatch.call(this, "Protect", password, drawingObjects, contents);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 * @param drawingObjects an input-parameter of type Variant
	 */
	public void protect(Variant password, Variant drawingObjects) {
		Dispatch.call(this, "Protect", password, drawingObjects);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param password an input-parameter of type Variant
	 */
	public void protect(Variant password) {
		Dispatch.call(this, "Protect", password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void protect() {
		Dispatch.call(this, "Protect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectContents() {
		return Dispatch.get(this, "ProtectContents").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _Dummy21() {
		Dispatch.call(this, "_Dummy21");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type boolean
	 */
	public boolean getProtectionMode() {
		return Dispatch.get(this, "ProtectionMode").toBoolean();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void _Dummy23() {
		Dispatch.call(this, "_Dummy23");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage, Variant lastParam) {
		Dispatch.callN(this, "SaveAs", new Object[] { filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage, lastParam});
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 * @param textCodepage an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru, Variant textCodepage) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru, textCodepage);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 * @param addToMru an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup, Variant addToMru) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup, addToMru);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 * @param createBackup an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended, Variant createBackup) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended, createBackup);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 * @param readOnlyRecommended an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword, Variant readOnlyRecommended) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword, readOnlyRecommended);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 * @param writeResPassword an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password, Variant writeResPassword) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password, writeResPassword);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 * @param password an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat, Variant password) {
		Dispatch.call(this, "SaveAs", filename, fileFormat, password);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 * @param fileFormat an input-parameter of type Variant
	 */
	public void saveAs(String filename, Variant fileFormat) {
		Dispatch.call(this, "SaveAs", filename, fileFormat);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type String
	 */
	public void saveAs(String filename) {
		Dispatch.call(this, "SaveAs", filename);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void select(Variant lastParam) {
		Dispatch.call(this, "Select", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void select() {
		Dispatch.call(this, "Select");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 */
	public void unprotect(Variant lastParam) {
		Dispatch.call(this, "Unprotect", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 */
	public void unprotect() {
		Dispatch.call(this, "Unprotect");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getVisible() {
		return Dispatch.get(this, "Visible").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type int
	 */
	public void setVisible(int lastParam) {
		Dispatch.call(this, "Visible", new Variant(lastParam));
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Shapes
	 */
	public Shapes getShapes() {
		return new Shapes(Dispatch.get(this, "Shapes").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant insertFile(Variant filename, Variant lastParam) {
		return Dispatch.call(this, "InsertFile", filename, lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param filename an input-parameter of type Variant
	 * @return the result is of type Variant
	 */
	public Variant insertFile(Variant filename) {
		return Dispatch.call(this, "InsertFile", filename);
	}

}
