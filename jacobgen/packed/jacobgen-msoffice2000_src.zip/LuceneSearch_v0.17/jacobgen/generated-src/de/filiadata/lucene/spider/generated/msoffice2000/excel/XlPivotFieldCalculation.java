/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlPivotFieldCalculation {

	public static final int xlDifferenceFrom = 2;
	public static final int xlIndex = 9;
	public static final int xlNoAdditionalCalculation = -4143;
	public static final int xlPercentDifferenceFrom = 4;
	public static final int xlPercentOf = 3;
	public static final int xlPercentOfColumn = 7;
	public static final int xlPercentOfRow = 6;
	public static final int xlPercentOfTotal = 8;
	public static final int xlRunningTotal = 5;
}
