/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public class MenuItems extends Dispatch {

	public static final String componentName = "Excel.MenuItems";

	public MenuItems() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public MenuItems(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public MenuItems(String compName) {
		super(compName);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Application
	 */
	public Application getApplication() {
		return new Application(Dispatch.get(this, "Application").toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCreator() {
		return Dispatch.get(this, "Creator").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Object
	 */
	public Object getParent() {
		return Dispatch.get(this, "Parent");
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param restore an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey, Variant before, Variant restore, Variant statusBar, Variant helpFile, Variant lastParam) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey, before, restore, statusBar, helpFile, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param restore an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @param helpFile an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey, Variant before, Variant restore, Variant statusBar, Variant helpFile) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey, before, restore, statusBar, helpFile).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param restore an input-parameter of type Variant
	 * @param statusBar an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey, Variant before, Variant restore, Variant statusBar) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey, before, restore, statusBar).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @param restore an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey, Variant before, Variant restore) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey, before, restore).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @param before an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey, Variant before) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey, before).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @param shortcutKey an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction, Variant shortcutKey) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction, shortcutKey).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param onAction an input-parameter of type Variant
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption, Variant onAction) {
		return new MenuItem(Dispatch.call(this, "Add", caption, onAction).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @return the result is of type MenuItem
	 */
	public MenuItem add(String caption) {
		return new MenuItem(Dispatch.call(this, "Add", caption).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param before an input-parameter of type Variant
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Menu
	 */
	public Menu addMenu(String caption, Variant before, Variant lastParam) {
		return new Menu(Dispatch.call(this, "AddMenu", caption, before, lastParam).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @param before an input-parameter of type Variant
	 * @return the result is of type Menu
	 */
	public Menu addMenu(String caption, Variant before) {
		return new Menu(Dispatch.call(this, "AddMenu", caption, before).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param caption an input-parameter of type String
	 * @return the result is of type Menu
	 */
	public Menu addMenu(String caption) {
		return new Menu(Dispatch.call(this, "AddMenu", caption).toDispatch());
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type int
	 */
	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object get_Default(Variant lastParam) {
		return Dispatch.call(this, "_Default", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @param lastParam an input-parameter of type Variant
	 * @return the result is of type Object
	 */
	public Object getItem(Variant lastParam) {
		return Dispatch.call(this, "Item", lastParam);
	}

	/**
	 * Wrapper for calling the ActiveX-Method with input-parameter(s).
	 * @return the result is of type Variant
	 */
	public Variant get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

}
