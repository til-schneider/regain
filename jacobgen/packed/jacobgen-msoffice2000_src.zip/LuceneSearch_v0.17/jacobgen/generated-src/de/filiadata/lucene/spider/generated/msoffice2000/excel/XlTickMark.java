/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlTickMark {

	public static final int xlTickMarkCross = 4;
	public static final int xlTickMarkInside = 2;
	public static final int xlTickMarkNone = -4142;
	public static final int xlTickMarkOutside = 3;
}
