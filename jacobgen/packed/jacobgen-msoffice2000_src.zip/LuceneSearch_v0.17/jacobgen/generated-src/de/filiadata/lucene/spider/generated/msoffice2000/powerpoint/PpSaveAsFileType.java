/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpSaveAsFileType {

	public static final int ppSaveAsPresentation = 1;
	public static final int ppSaveAsPowerPoint7 = 2;
	public static final int ppSaveAsPowerPoint4 = 3;
	public static final int ppSaveAsPowerPoint3 = 4;
	public static final int ppSaveAsTemplate = 5;
	public static final int ppSaveAsRTF = 6;
	public static final int ppSaveAsShow = 7;
	public static final int ppSaveAsAddIn = 8;
	public static final int ppSaveAsPowerPoint4FarEast = 10;
	public static final int ppSaveAsDefault = 11;
	public static final int ppSaveAsHTML = 12;
	public static final int ppSaveAsHTMLv3 = 13;
	public static final int ppSaveAsHTMLDual = 14;
	public static final int ppSaveAsMetaFile = 15;
	public static final int ppSaveAsGIF = 16;
	public static final int ppSaveAsJPG = 17;
	public static final int ppSaveAsPNG = 18;
	public static final int ppSaveAsBMP = 19;
}
