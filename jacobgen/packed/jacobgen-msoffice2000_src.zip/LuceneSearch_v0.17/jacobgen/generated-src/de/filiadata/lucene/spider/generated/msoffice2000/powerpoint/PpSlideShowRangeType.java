/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpSlideShowRangeType {

	public static final int ppShowAll = 1;
	public static final int ppShowSlideRange = 2;
	public static final int ppShowNamedSlideShow = 3;
}
