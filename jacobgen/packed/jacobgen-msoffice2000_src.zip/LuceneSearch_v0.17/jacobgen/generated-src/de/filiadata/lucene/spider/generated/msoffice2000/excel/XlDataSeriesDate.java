/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlDataSeriesDate {

	public static final int xlDay = 1;
	public static final int xlMonth = 3;
	public static final int xlWeekday = 2;
	public static final int xlYear = 4;
}
