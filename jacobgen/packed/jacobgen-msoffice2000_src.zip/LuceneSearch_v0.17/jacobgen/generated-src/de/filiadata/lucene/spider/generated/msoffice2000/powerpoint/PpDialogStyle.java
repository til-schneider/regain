/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.powerpoint;

import com.jacob.com.*;

public interface PpDialogStyle {

	public static final int ppDialogStyleMixed = -2;
	public static final int ppDialogStandard = 1;
	public static final int ppDialogTabbed = 2;
}
