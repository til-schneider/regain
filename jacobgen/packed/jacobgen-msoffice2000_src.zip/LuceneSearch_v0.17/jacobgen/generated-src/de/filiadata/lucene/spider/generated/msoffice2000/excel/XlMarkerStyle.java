/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlMarkerStyle {

	public static final int xlMarkerStyleAutomatic = -4105;
	public static final int xlMarkerStyleCircle = 8;
	public static final int xlMarkerStyleDash = -4115;
	public static final int xlMarkerStyleDiamond = 2;
	public static final int xlMarkerStyleDot = -4118;
	public static final int xlMarkerStyleNone = -4142;
	public static final int xlMarkerStylePicture = -4147;
	public static final int xlMarkerStylePlus = 9;
	public static final int xlMarkerStyleSquare = 1;
	public static final int xlMarkerStyleStar = 5;
	public static final int xlMarkerStyleTriangle = 3;
	public static final int xlMarkerStyleX = -4168;
}
