/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package de.filiadata.lucene.spider.generated.msoffice2000.excel;

import com.jacob.com.*;

public interface XlHAlign {

	public static final int xlHAlignCenter = -4108;
	public static final int xlHAlignCenterAcrossSelection = 7;
	public static final int xlHAlignDistributed = -4117;
	public static final int xlHAlignFill = 5;
	public static final int xlHAlignGeneral = 1;
	public static final int xlHAlignJustify = -4130;
	public static final int xlHAlignLeft = -4131;
	public static final int xlHAlignRight = -4152;
}
